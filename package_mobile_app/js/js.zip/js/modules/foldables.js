define(['jquery', 'modules/util','player.ext'],function($, util, player_ext){
    'use strict';
    util.log("foldables loaded");
    var handle = function($fc){
        $fc.each(function(idx,item){
            var $header = $(item).children(".foldable-header");
            var $content = $(item).children(".foldable-contents");
            $header.on("click",function(){
                var $this = $(this);
                if($this.hasClass("foldable-header-expanded")){
                    $this.removeClass("foldable-header-expanded");
                    $content.removeClass("foldable-contents-shown");
                    $content.find('div[name="jplayer"]').each(function(idx,item){
                        $(item).jPlayer("pause");
                    });
                }else{
                    $this.addClass("foldable-header-expanded");
                    $content.addClass("foldable-contents-shown");
                    player_ext.updatePlayerSize();
                }
            });
        });
    };
    return {
        handle:handle
    };

});
