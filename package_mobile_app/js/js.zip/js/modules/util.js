define(['jquery', 'base64'],function($, base64){
    'use strict';
    
    var logEnabled = true;
    
    var log = function () {
    	if (logEnabled && window.console) {
    		try {
    			console.log.apply(console, arguments);
    		}
    		catch (err) {
    			console.log(err);
    		}
    	}
    };
    
    var _loadJSON = function (jquery, url, callback) {
		_loadFile(jquery, url, function(data) {
			if (data !== undefined) {
				callback(JSON.parse(data));
			}
			else {
				callback();
			}
		});
	};
    
    var loadJSON = function(url, callback){
		try {
			if (isWP8()) {
				require(['jquery-wp8'], function(jqueryWP8) {
        			_loadJSON(jqueryWP8, url, callback);
        		});
        	}
        	else {
        		_loadJSON($, url, callback);
        	}
        } catch (e) {
        	alert("loadJSON:" + e);
        	log("loadJSON:" + e);
        }
    };
    
    var _loadFile = function (jquery, url, callback) {
		jquery.ajax({
			async:isWin8(),
			url:url,
			type:"GET",
			isLocal:true,
			success:function(data){
				log("loading file: " + url);
				callback(data);
			},
			error:function(jqXHR,textStatus,err){
				log("error occurred " + textStatus);
				callback();
			}
		});
	};
    
    var loadFile = function(file, callback) {
    	try {
			if (isWP8()) {
				require(['jquery-wp8'], function(jqueryWP8) {
        			_loadFile(jqueryWP8, file, callback);
        		});
        	}
        	else {
        		_loadFile($, file, callback);
        	}
        } catch (e) {
        	alert("loadFile:" + e);
        	log("loadFile:" + e);
        }
    };

    var isAndroid = function(){
        return window.devType==="ANDROID";
    };

    var isIOS = function(){
        return window.devType==="IOS";
    };

    var isWin8 = function(){
        return window.devType==="WIN8";
    };

    var isWP8 = function(){
        return window.devType==="WP8";
    };

    var isTeacher = function(){
		
		log('isTeacher');
		
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.isTeacher !== undefined) {
    			return window.Android.isTeacher();
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.isTeacher !== undefined) {
    			return window.iosProxy.isTeacher();
    		}
    	}
    	else if (isWin8()) {
    		if (window.isTeacherWin8 !== undefined) {
    			return window.isTeacherWin8();
        	}
    	}
    	else if (isWP8()) {
    		if (window.isTeacherWP8 !== undefined) {
    			return parseBool(window.isTeacherWP8());
    		}
    	}
    	return false;
    };
    
   
    var fullScreenCallback = function (container, full) {
        log('fullScreenCallback');

        if (isWin8()) {
        try {
        	var payload = "notifyPlayerFullScreen;"+(full?"true":"false");
        	window.external.notify(payload);
        }
        catch (e) {
        	log("error notifyPlayerFullScreen");
        }
        }
    };

    var canPlayVideo = function (url, container, playermodule) {
		
		log('canPlayVideo');
		
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.canPlayVideo !== undefined) {
    			return window.Android.canPlayVideo(url);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.canPlayVideo !== undefined) {
    			return window.iosProxy.canPlayVideo(url, container);
    		}
    	}
    	else if (isWin8()) {
    		if (window.canPlayVideoWin8 !== undefined) {
    		    return window.canPlayVideoWin8(container, playermodule);
        	}
    	}
    	else if (isWP8()) {
    		if (window.canPlayVideoWP8 !== undefined) {
    		    return parseBool(window.canPlayVideoWP8(container, playermodule));
    		}
    	}
    	return false;
    };        

    var parseBool = function(str) {
    	str = str.toLowerCase();
    	if (str.toLowerCase() == "false") {
			return false;
		}
		if (str.toLowerCase() == "true") {
			return true;
		}
		return false;
    };

    var notifyFontButtonsEnabled = function(aminus,aplus){
		
        log('notifyFontButtonsEnabled');
        if(isAndroid()){
            if(window.Android !== undefined && window.Android.notifyEverythingWasLoaded !== undefined){
                window.Android.notifyFontButtonsEnabled(aminus,aplus);
            }
        }
        else if(isIOS()){
            if(window.iosProxy !== undefined && window.iosProxy.notifyEverythingWasLoaded !== undefined){
                window.iosProxy.notifyFontButtonsEnabled(aminus,aplus);
            }
        }
        else if(isWin8()){
            try {
	            var payload = "notifyFontButtonsEnabled;"+(aminus?"true":"false")+";"+(aplus?"true":"false");
				window.external.notify(payload);
			}
			catch (e) {
				log("error notifyFontButtonsEnabled");
			}
        }
        else if(isWP8()){
            try {
	            var payload = "notifyFontButtonsEnabled;"+(aminus?"true":"false")+";"+(aplus?"true":"false");
				window.external.notify(payload);
			}
			catch (e) {
				log("error notifyFontButtonsEnabled");
			}
        }
    };
    
	var notifyEverythingWillBeLoaded = function() {
    	
    	log('notifyEverythingWillBeLoaded');
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.notifyEverythingWillBeLoaded !== undefined) {
    			window.Android.notifyEverythingWillBeLoaded();
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.notifyEverythingWillBeLoaded !== undefined) {
    			window.iosProxy.notifyEverythingWillBeLoaded();
    		}
    	}
    	else if (isWin8()) {
            try {
	    		var payload = "notifyEverythingWillBeLoaded";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyEverythingWillBeLoaded");
			}
    	}
    	else if (isWP8()) {
            try {
	    		var payload = "notifyEverythingWillBeLoaded";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyEverythingWillBeLoaded");
			}
    	}
	};
	
    var notifyEverythingWasLoaded = function() {
    	
    	log('notifyEverythingWasLoaded');
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.notifyEverythingWasLoaded !== undefined) {
    			window.Android.notifyEverythingWasLoaded();
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.notifyEverythingWasLoaded !== undefined) {
    			window.iosProxy.notifyEverythingWasLoaded();
    		}
    	}
    	else if (isWin8()) {
            try {
	    		var payload = "notifyEverythingWasLoaded";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyEverythingWasLoaded");
			}
    	}
    	else if (isWP8()) {
            try {
	    		var payload = "notifyEverythingWasLoaded";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyEverythingWasLoaded");
			}
    	}
    };
    
    var notifyModalWindowVisible = function () {
    	
    	log('notifyModalWindowVisible');
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.notifyModalWindowVisible !== undefined) {
    			window.Android.notifyModalWindowVisible();
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.notifyModalWindowVisible !== undefined) {
    			window.iosProxy.notifyModalWindowVisible();
    		}
    	}
    	else if (isWin8()) {
            try {
	    		var payload = "notifyModalWindowVisible";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyModalWindowVisible");
			}
    	}
    	else if (isWP8()) {
            try {
	    		var payload = "notifyModalWindowVisible";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyModalWindowVisible");
			}
    	}
    };
    
    var notifyModalWindowHidden = function () {
    	
    	log('notifyModalWindowHidden');
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.notifyModalWindowHidden !== undefined) {
    			window.Android.notifyModalWindowHidden();
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.notifyModalWindowHidden !== undefined) {
    			window.iosProxy.notifyModalWindowHidden();
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "notifyModalWindowHidden";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyModalWindowHidden");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "notifyModalWindowHidden";
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error notifyModalWindowHidden");
			}
    	}
    };
    
    var openPageLink = function (file, anchor) {
    	
    	log('openPageLink ' + file);
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.openPageLink !== undefined) {
    			window.Android.openPageLink(file, anchor);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.openPageLink !== undefined) {
    			window.iosProxy.openPageLink(file, anchor);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "openPageLink;" + file;
	    		if (anchor) {
	    			payload += ";" + anchor;
	    		}
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error openPageLink");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "openPageLink;" + file;
	    		if (anchor) {
	    			payload += ";" + anchor;
	    		}
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error openPageLink");
			}
    	}
    };
	
	var openExternalWindow = function(url, overlay) {
		
    	log('openExternalWindow ' + url + ', overlay ' + overlay);
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.openExternalWindow !== undefined) {
    			window.Android.openExternalWindow(url, overlay);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.openExternalWindow !== undefined) {
    			window.iosProxy.openExternalWindow(url, overlay);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "openExternalWindow;" + url + ";" + overlay;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error openExternalWindow");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "openExternalWindow;" + url + ";" + overlay;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error openExternalWindow");
			}
    	}
	};

	var getStateForWomi = function(womiId, callback) {
		
		log('getStateForWomi: ' + womiId);
    	
    	// this needs to be called by app
    	if (callback !== undefined) {
			window.updateWomiState = function(base64str) {
				var jsonObj;
				if (base64str !== '' && base64str !== null && base64str !== undefined) {
					jsonObj = JSON.parse(base64.decode(base64str));
				}
				callback(jsonObj);
				window.updateWomiState = null;
			};
    	}
    	
		if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.getStateForWomi !== undefined) {
    			window.Android.getStateForWomi(womiId);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.getStateForWomi !== undefined) {
    			window.iosProxy.getStateForWomi(womiId);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "getStateForWomi;" + womiId;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error getStateForWomi");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "getStateForWomi;" + womiId;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error getStateForWomi");
			}
    	}
	};

	var setStateForWomi = function(womiId, jsonObj) {
		
		log('setStateForWomi: ' + womiId);
		
		var base64str = '';
		if (jsonObj !== undefined && jsonObj !== null) {
			base64str = base64.encode(JSON.stringify(jsonObj));
		}
		
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.setStateForWomi !== undefined) {
    			window.Android.setStateForWomi(womiId, base64str);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.setStateForWomi !== undefined) {
    			window.iosProxy.setStateForWomi(womiId, base64str);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "setStateForWomi;" + womiId + ";" + base64str;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error setStateForWomi");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "setStateForWomi;" + womiId + ";" + base64str;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error getStateForWomi");
			}
    	}
	};
	
	var callParent = function(name) {
		try {
			if (name && window.parent && window.parent[name] && Object.prototype.toString.call(window.parent[name]) == '[object Function]') {
				window.parent[name]();
			}
		}
		catch (e) {
			console.log(e);
		}
	};
    
	var getStateForOpenQuestions = function(idsArray) {
    	
		log('getStateForOpenQuestions: ' + idsArray.length);
		
		var stringArray = JSON.stringify(idsArray);
		if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.getStateForOpenQuestions !== undefined) {
    			window.Android.getStateForOpenQuestions(stringArray);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.getStateForOpenQuestions !== undefined) {
    			window.iosProxy.getStateForOpenQuestions(stringArray);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "getStateForOpenQuestions;" + stringArray;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error getStateForOpenQuestions");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "getStateForOpenQuestions;" + stringArray;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error getStateForOpenQuestions");
			}
    	}
	};
	
	var setStateForOpenQuestion = function(openQuestionID, base64str) {
		
		log('setStateForOpenQuestion: ' + openQuestionID);
		
    	if (isAndroid()) {
    		if (window.Android !== undefined && window.Android.setStateForOpenQuestion !== undefined) {
    			window.Android.setStateForOpenQuestion(openQuestionID, base64str);
    		}
    	}
    	else if (isIOS()) {
    		if (window.iosProxy !== undefined && window.iosProxy.setStateForOpenQuestion !== undefined) {
    			window.iosProxy.setStateForOpenQuestion(openQuestionID, base64str);
    		}
    	}
    	else if (isWin8()) {
    		try {
	    		var payload = "setStateForOpenQuestion;" + openQuestionID + ";" + base64str;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error setStateForOpenQuestion");
			}
    	}
    	else if (isWP8()) {
    		try {
	    		var payload = "setStateForOpenQuestion;" + openQuestionID + ";" + base64str;
	    		window.external.notify(payload);
			}
			catch (e) {
				log("error setStateForOpenQuestion");
			}
    	}
	};
	
	window.updateOpenQuestionsStates = function(base64str) {
		
		var jsonObj;
		if (base64str !== '' && base64str !== null && base64str !== undefined) {
			var objectString = base64.decode(base64str);
			objectString = objectString.replace('\"', '"');
			jsonObj = JSON.parse(objectString);
			
			for (var openQuestionID in jsonObj) {
				
				var str = base64.decode(jsonObj[openQuestionID]);
				if (str != null && str != "") {
					$("#" + openQuestionID).find(".work-area").val(str);
				}
			}
		}
	};
	
    return {
    	log:log,
        loadJSON:loadJSON,
        loadFile:loadFile,
        isAndroid:isAndroid,
        isIOS:isIOS,
        isWin8:isWin8,
        isWP8:isWP8,
        isTeacher:isTeacher,
        canPlayVideo: canPlayVideo,
        fullScreenCallback:fullScreenCallback,
        notifyModalWindowVisible:notifyModalWindowVisible,
        notifyModalWindowHidden:notifyModalWindowHidden,
		notifyEverythingWillBeLoaded:notifyEverythingWillBeLoaded,
        notifyEverythingWasLoaded:notifyEverythingWasLoaded,
        notifyFontButtonsEnabled:notifyFontButtonsEnabled,
        openPageLink:openPageLink,
		openExternalWindow:openExternalWindow,
		callParent:callParent,
		getStateForWomi:getStateForWomi,
		setStateForWomi:setStateForWomi,
		getStateForOpenQuestions:getStateForOpenQuestions,
		setStateForOpenQuestion:setStateForOpenQuestion
    }

});
