define(['jquery', 'modules/util','modules/windowutil'],function($,util,windowutil){
    'use strict';
    util.log("cw-1 loaded");

    var handle = function(obj,div,womiId,stateObj){
        var scrollPos;
        var clearFeedback = function(){
            $table.find(".cw-letter").removeClass("cw-wrong");
            //$correct.removeAttr("style");
            //$wrong.removeAttr("style");
            $correct.css("display","none");
            $wrong.css("display","none");
        };
        var checkAnswer = function(){
            clearFeedback();
            var somethingWrong = false;
            $table.find("tr").each(function(idx,item){
                var _it = item;
                var _idx = idx;
                var rowWrong = false;
                var $spans = $(_it).find("span");
                $spans.each(function(sidx,sitem){
                    if(obj.body[_idx].correct[sidx].toUpperCase()!==$(sitem).html().toUpperCase()){
                        rowWrong=true;
                        somethingWrong=true;
                    }
                });
                if(rowWrong){
                    $spans.parent().addClass("cw-wrong");
                }
            });
            if(somethingWrong){                
                $wrong.css("display","block");
                if(!!obj.description.hint){
                    $showHint.css("display","inline-block");
                }
            }else{
                $correct.css("display","block");
            }
        };
        var copyLetters = function($targetTr,value){
            $targetTr.find("span").each(function(idx,item){
                var c = value.charAt(idx);
                c=c===undefined?"":c;
                $(this).html(c);
            });            
        };
        var highlightLetter = function($targetTr,value){
            var $tds = $targetTr.find("td.cw-letter").removeClass("cw-current");            
            var pos = Math.min(value.length,$tds.length-1);
            $($tds.get(pos)).addClass("cw-current");
        };
        var saveState = function(){
                var stateTab = [];
                $table.find("span").each(function(idx,item){
                        var character = $(item).html()===""?null:$(item).html();
                        stateTab.push(character);
                });
                util.setStateForWomi(womiId, stateTab);
        };
        var showOverlay = function($origTr,idx){
            scrollPos = Math.max($("body, html").scrollTop(),$("body").scrollTop());
            util.log("pos: "+scrollPos);
            clearFeedback();
            windowutil.addCloseWindowCallback(function(){
                hideOverlay();
            });
            var $overlay = $("<div></div>").addClass("cw-overlay");
            $overlay.on("click",function(){
                $input.focus();
            });
            //add hidden input and focus
            var $input = $("<input type='text' autocapitalize='off' autocorrect='off'></input>").addClass("cw-maininput");
            $overlay.append($input);
            $input.on("input",function(ev){
                copyLetters($tr,$(this).val());
                highlightLetter($tr,$(this).val());
                util.log($(this).val());
            });
            $input.on("keydown",function(ev){
                //just for ms
                if(ev.which===13){
                    copyLetters($origTr,$(this).val());
					saveState();
				    	
                    //hideOverlay();                    
                    closeWindow();
                }
            });
            $input.on("keyup",function(ev){
                var len = $tr.find("td").length;               
                if($(this).val().length>len){
                    $(this).val($(this).val().slice(0,len));
                } 
                util.log('val: '+$(this).val());
                copyLetters($tr,$(this).val());
                highlightLetter($tr,$(this).val());
            });
            //render question
            var $q = $("<div></div>").html(obj.body[idx].question);
            $overlay.append($q);
            //create table
            var $table = $("<table></table>").addClass("cw-table");            
            var $tr = $("<tr></tr>");
            $table.append($tr);
            for(var i=0;i<obj.body[idx].correct.length;i++){
                $tr.append($("<td></td>").addClass("cw-letter").append($("<span></span>")));
            }
            var $close = $("<div />",{"class":"cw-close-btn"}).html("x");
            $close.on("click",function(){
                //hideOverlay();
                closeWindow();
            });            
            $overlay.append($table);
            $overlay.append($close);
            $("body").append($overlay);
            $input.focus();
            highlightLetter($tr,"");
            //$(".reader-content").css("display","none");
        };
        var hideOverlay = function(){
            $(".cw-overlay").remove();
            //$(".reader-content").css("display","block");
            //$("body, html").scrollTop(scrollPos);
        };
        util.log("handling cw-1");
        var maxCells = 0;
        var $mainDiv = $(div);
        $mainDiv.addClass("momi");
        var $table = $("<table></table>").addClass("cw-table");
        var $questions = $("<div></div>").addClass("cw-questions");
        $.each(obj.body,function(idx,item){
            //render questions
            var $question = $("<div>").html((idx+1)+". "+item.question);
            $questions.append($question);
            //table row
            var $tr = $("<tr></tr>"); 
            //number
            $tr.append($("<td></td>").html((idx+1)+".").addClass("cw-num"));
            for(var i=1;i<item.position;i++){
                $tr.append($("<td></td>").addClass("cw-position-cell"));
            }
            for(var i=0;i<item.correct.length;i++){
                var $letterTd = $("<td></td>").addClass("cw-letter");
                $letterTd.append($("<span></span>"));
                if(obj.config.solutionPosition===(i+item.position)){
                    $letterTd.addClass("cw-solution");
                }
                $tr.append($letterTd);
            }
            maxCells = Math.max(maxCells,$tr.find("td").length);
            //on tr click
            $tr.on("click",function(){
                showOverlay($(this),idx);
            });
            // on question click
            //$question.on("click",function(){
            //    showOverlay($tr,idx);
            //});
            $table.append($tr);            
        });
        //check button
        var $check = $("<button type='button'>Sprawdź</button>").addClass("ex-btn-check");
        $check.on("click",function(){
            checkAnswer();
        });
        //feedback
        var $feedback = $("<div></div>").addClass("ex-feedback");
        var $correct = $("<div></div>").addClass("ex-correct").css("display","none");
        $correct.html(obj.description.correctFeedback);
        $feedback.append($correct);
        var $wrong = $("<div></div>").addClass("ex-wrong").css("display","none");
        $wrong.html(obj.description.wrongFeedback);
        $feedback.append($wrong);
        //reset
        var $reset = $("<button type='button'>Wyczyść</button>").addClass("ex-btn-clear");
        $reset.on("click",function(){
            clearFeedback();
            $table.find("span").html("");
            util.setStateForWomi(womiId, null);
        });
        //hint
        var $hint = $("<div></div>").addClass("ex-hint").html(obj.description.hint).css("display","none");
        $feedback.append($hint);
        var $showHint = $("<button type='button'>Wskazówka</button>").addClass("ex-btn-hint").css("display","none");
        $showHint.on("click",function(){
            var d = $hint.css("display");
            if(d==="none"){
                $hint.css("display","block");
                $(this).html("Ukryj wskazówkę");
            }else{                
                $hint.css("display","none");
                $(this).html("Wskazówka");
            }
            //var s = $hint.attr("style"); 
            //if(s!==undefined && s!==false){
                //$hint.removeAttr("style");
            //    $hint.css("display","none");
            //    $(this).html("Wskazówka");
            //}else{
            //    $hint.css("display","block");
            //    $(this).html("Ukryj wskazówkę");
            //}
        });
        $table.css("width",2*maxCells+"em");
        var $exDescription = $("<div></div>").addClass("ex-description");
        $mainDiv.append($exDescription);
        var $title = $("<div></div>").addClass("ex-title");
        $title.html(obj.description.title);
        $exDescription.append($title);
        var $descContent = $("<div></div>").addClass("ex-content");
        $descContent.html(obj.description.content);
        $exDescription.append($descContent);
        var $wrap = $("<div></div>").addClass("ex-main cw-1");
        $wrap.append($table);
        $wrap.append($questions);
        $mainDiv.append($wrap);
        var $exerciseButtons = $("<div></div>").addClass("ex-buttons");
        $exerciseButtons.append($reset);
        $exerciseButtons.append($check);
        $exerciseButtons.append($showHint);
        $mainDiv.append($feedback);
        $mainDiv.append($exerciseButtons);
        util.log("maxcells :"+maxCells);

		if(stateObj)
		{
			$table.find("span").each(function(idx,item){
				$(item).text(stateObj[idx]===null?"":stateObj[idx]);
			});
		};
    };
    return {
        handle:handle
    };
});

