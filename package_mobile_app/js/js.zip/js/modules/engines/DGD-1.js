define(['jquery', 'modules/util'],function($,util){
    'use strict';
    util.log("dgd-1 loaded");    
    var handle = function(obj,div,womiId,stateObj){
        util.log("handling dgd-1");
        $(div).html("TODO");
    };
    return {handle:handle};
});
