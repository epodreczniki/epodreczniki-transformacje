﻿define(['modules/engines/enginesUtil', 'modules/util'], function (enginesUtil, util){
    'use strict';
    util.log("mem-1 loaded");    
    var handle = function(obj, div,womiId,stateObj){
        util.log("handling mem-1");
        var cfg = {
            el1: "empty",
            el2: "empty",
            ex: obj,
            $div: $(div),
			womiId: womiId
        };
        cfg.ex.config.id = cfg.$div.uniqueId().attr("id");
        cfg.$div.removeUniqueId();

        generate(cfg, stateObj);
		loadState(cfg, stateObj);
    };

    var generate = function (cfg, stateObj) {
        //Opis zadania
        var $output = $("<div></div>", {
            "class": "ex-description"
        });
        $("<div></div>", {
            "class": "ex-title",
            text: cfg.ex.description.title
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-content"
        }).append(cfg.ex.description.content).appendTo($output);
        cfg.$div.append($output);

        //Zadanie
        $output = $("<div></div>", {
            "class": "ex-main mem-1",
            id: cfg.ex.config.id
        });
        var $collection = $("<div></div>", {
            "class": "mem-zone"
        });
        var array = cfg.ex.body;
		if(stateObj) {
			var lastState = [];
			for (var i = 0; i < stateObj.length; i++) // stateObj[i].id
			{
				var elem = $.grep(cfg.ex.body, function (n) { return n.id == stateObj[i].id })[0];
				lastState.push(elem);
			};
			array = lastState;
		} else {
			if (cfg.ex.config.randomize) {
				array = enginesUtil.shuffleArray(cfg.ex.body);
			};
		};
        $.each(array, function (i, val) {
            if (val.images) {
                $("<div></div>", {
                    "class": "card back picture",
                    "data-pk": val.id
                }).append(val.content).appendTo($collection);
            } else {
                $("<div></div>", {
                    "class": "card back",
                    "data-pk": val.id
                }).append($("<span></span>").append(val.content)).appendTo($collection);
            };
        });
        $output.append($collection);
        cfg.$div.append($output);

        //Rezultat
        $output = $("<div></div>", {
            "class": "ex-feedback"
        });
        $("<div></div>", {
            "class": "ex-correct",
            text: cfg.ex.description.correctFeedback
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-wrong",
            text: cfg.ex.description.wrongFeedback
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<div></div>", {
                "class": "ex-hint",
                text: cfg.ex.description.hint
            }).appendTo($output);
            cfg.$div.append($output);
        };

        //Przyciski kontrolne
        $output = $("<div></div>", {
            "class": "ex-buttons"
        });
        $("<button></button>", {
            "class": "ex-btn-clear",
            text: "Nowe zadanie",
            on: {
                click: function (event) {
                    reset(cfg);
                }
            }
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<button></button>", {
                "class": "ex-btn-hint",
                text: "Pokaż wskazówkę",
                on: {
                    click: function (event) {
                        hint(cfg);
                    }
                }
            }).css("display", "block").appendTo($output);
        };
        cfg.$div.append($output);

        cfg.$div.find(".card").click(function () {
            revert(cfg, $(this));
        });
    };

	var revert = function (cfg, $el) {
        if (cfg.el1 != "empty" && cfg.el2 != "empty") {
            return;
        };

        $el.unbind("click");

        var pk = $el.data("pk");
        var back = false;
        if ($el.hasClass("back")) {
            back = true;
            if (cfg.el1 == "empty") {
                cfg.el1 = pk;
            } else {
                cfg.el2 = pk;
            };
        } else {
            if (cfg.el1 == pk) {
                cfg.el1 = 'empty';
            } else if (cfg.el2 == pk) {
                cfg.el2 = 'empty';
            };
        };


        var first = false;
        if (cfg.el1 == "empty" || cfg.el2 == "empty") {
            first = true;
        };


        $({ deg: 0 }).animate({ deg: 90 }, {
            duration: 300,
            step: function (now) {
                $el.css({
                    transform: "rotateY(" + now + "deg)"
                });
            },
            complete: function () {
                if (back) {
                    $el.removeClass("back");
                } else {
                    $el.addClass("back");
                };
                $({ deg: 90 }).animate({ deg: 0 }, {
                    duration: 300,
                    step: function (now) {
                        $el.css({
                            transform: "rotateY(" + now + "deg)"
                        });
                    },
                    complete: function () {
                        $el.removeAttr('style').click(function () {
                            revert(cfg, $(this));
                        });

                        if (!first && cfg.el1 != "empty" && cfg.el2 != "empty") {
                            var $el1 = cfg.$div.find("[data-pk='" + cfg.el1 + "']");
                            var $el2 = cfg.$div.find("[data-pk='" + cfg.el2 + "']");

                            if (!match(cfg)) {
                                $({ deg: 0 }).animate({ deg: 90 }, {
                                    duration: 300,
                                    step: function (now) {
                                        $el1.css({
                                            transform: "rotateY(" + now + "deg)"
                                        });
                                        $el2.css({
                                            transform: "rotateY(" + now + "deg)"
                                        });
                                    },
                                    complete: function () {
                                        $el1.addClass("back");
                                        $el2.addClass("back");

                                        $({ deg: 90 }).animate({ deg: 0 }, {
                                            duration: 300,
                                            step: function (now) {
                                                $el1.css({
                                                    transform: "rotateY(" + now + "deg)"
                                                });
                                                $el2.css({
                                                    transform: "rotateY(" + now + "deg)"
                                                });
                                            },
                                            complete: function () {
                                                $el1.removeAttr('style');
                                                $el2.removeAttr('style');
                                                cfg.el1 = "empty";
                                                cfg.el2 = "empty";
                                            }
                                        });
                                    }
                                });
                            } else {
                                if (cfg.$div.find(".card.back").length == 0) {
                                    cfg.$div.find(".ex-correct").slideDown(250, "linear");
                                };

                                $el1.unbind("click");
                                $el2.unbind("click");
                                cfg.el1 = "empty";
                                cfg.el2 = "empty";
								saveState(cfg);
                            };
                        };
                    }
                });
            }
        });
    };

    var match = function (cfg) {
        var match = 'unknown';
        var good = false;
        $.each(cfg.ex.body, function (i, val) {
            if (val.id == cfg.el1) {
                if (match == 'unknown') {
                    match = val.match;
                } else if (match == val.match) {
                    good = true;
                    return;
                } else {
                    return;
                };
            } else if (val.id == cfg.el2) {
                if (match == 'unknown') {
                    match = val.match;
                } else if (match == val.match) {
                    good = true;
                    return;
                } else {
                    return;
                };
            };
        });

        if (good) {
            return true;
        } else {
            return false;
        };
    };

    var reset = function (cfg) {
        cfg.$div.empty();
        generate(cfg, null);
		util.setStateForWomi(cfg.womiId, null);
    };

    var hint = function (cfg) {
        var $hint = cfg.$div.find(".ex-hint");

        if ($hint.css('display') == 'none') {
            $hint.slideDown(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Schowaj wskazówkę");
            });
        }
        else {
            $hint.slideUp(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Pokaż wskazówkę");
            });
        };
    };
	
	var saveState = function (cfg) {
		var state = [];
		$.each(cfg.$div.find(".card"), function (cid, card) {
			var crd = {
				id: $(card).data("pk"),
				isBack: $(card).hasClass("back")
			};
			state.push(crd);
		});
		util.setStateForWomi(cfg.womiId, state);
	};
	
	var loadState = function (cfg, state) {
		if(state)
		{
			$.each(state, function (idx, elem) {
				var $card = cfg.$div.find(".card[data-pk='" + elem.id + "']");
				if (!elem.isBack)
				{
					$card.removeClass("back");
					$card.unbind("click");
				}
			});
		}
	};

    return {
        handle:handle
    };
});