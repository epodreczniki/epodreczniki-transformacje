define(['jquery', 'modules/util'],function($, util){
    'use strict';
    util.log("tmw-1 loaded");    
    var handle = function(obj,div){
        util.log("handling tmw-1");
//        $(div).html("TODO   " + obj.description.title);
  		      
		var store = {
			shownAnswers:null,
			uiTitle:null,
			uiContent:null,
			uiAnswers:null,
			uiFeedback:null,
			uiFeedbackCorrect:null,
			uiFeedbackWrong:null,
			uiFeedbackHint:null,
			uiButtons:null,
			uiButtonsCheck:null,
			uiButtonsHint:null,
			uiButtonsNextExample:null
		};
		
		createContainers(obj, div, store);
		createTable(obj, div, store);
		makeButtons(obj, div, store);
    };

    var createContainers = function(obj, div, store) {

        var descriptionDiv = $("<div>", {
            class: "ex-description"
        });
        descriptionDiv.appendTo(div);

        store.uiAnswers = $("<div>", {
            class: "ex-main " + obj.config.type.toLowerCase()
        });
        store.uiAnswers.appendTo(div);

        store.uiFeedback = $("<div>", {
            class: "ex-feedback"
        });
        store.uiFeedback.appendTo(div);

        store.uiButtons = $("<div>", {
            class: "ex-buttons"
        });
        store.uiButtons.appendTo(div);

        //

        store.uiTitle = $("<div>", {
            class: "ex-title",
            html: obj.description.title
        });
        store.uiTitle.appendTo(descriptionDiv);

        store.uiContent = $("<div>", {
            class: "ex-content",
            html: obj.description.content
        });
        store.uiContent.appendTo(descriptionDiv);

        //

        store.uiFeedbackCorrect = $("<div>", {
            class: "ex-correct",
            html: obj.description.correctFeedback
        });
        store.uiFeedbackCorrect.appendTo(store.uiFeedback);

        store.uiFeedbackWrong = $("<div>", {
            class: "ex-wrong",
            html: obj.description.wrongFeedback
        });
        store.uiFeedbackWrong.appendTo(store.uiFeedback);

        store.uiFeedbackHint = $("<div>", {
            class: "ex-hint",
            html: "hint"
        });
        store.uiFeedbackHint.appendTo(store.uiFeedback);
    };
 
 	//macierz odpowiedzi
 	var createTable = function(obj, div, store)
 	{
 		var tbl = $('<table></table>').attr({ id: "answers-matrix" });
    	store.uiAnswersRows = [];
    	
    	//header
    	var row = $('<tr></tr>').appendTo(tbl);   		
    	$('<th></th>').text("PYTANIE").appendTo(row);
    	for (var h=0; h < obj.answers.length; h++) {
    		$('<th></th>').text(obj.answers[h].content).appendTo(row);
    	}    	    	
    	
    	
    	
    	for (var i = 0; i < obj.questions.length; i++) {
    		var row = $('<tr/>', {
    			value: obj.questions[i].id
    		});
    		
    		
    		$('<td></td>').text(obj.questions[i].content).appendTo(row);
    		for (var j=0; j < obj.answers.length; j++) {
    		     var radio = $('<input>', {
                    class: "answer-input",
                    type: "radio",
                    name: obj.questions[i].id,
                    value: obj.answers[j].id
                });
                radio.click(function(e) {
                	answerClicked(store, e);
            	});
    			$('<td></td>').append(radio).appendTo(row);
    		}
    		        		
    		row.appendTo(tbl);       		 
    		//store.uiAnswersRows[store.uiAnswersRows.length] = row;  
    	}
    	
    	store.uiAnswersTable = tbl;
    	store.uiAnswersTable.appendTo(store.uiContent);    
 	};
    
    
    var makeButtons = function(obj, div, store) {

        store.uiButtonsCheck = $('<button>', {
            text: "Sprawdź",
            class: "ex-btn-check"
        });
        store.uiButtonsCheck.click(function() {
            checkAnswer(obj, store);
        });
        store.uiButtons.append(store.uiButtonsCheck);

        store.uiButtonsHint = $('<button>', {
            text: "Pokaż wskazówkę",
            class: "ex-btn-hint"
        });
        prepareHint(obj, store);
        store.uiButtons.append(store.uiButtonsHint);
    };

    
    var checkAnswer = function(obj, store) {
    	var allAnswersCorrect = true;
        var isAnyChecked = false;

/* tego nie umiem zrobić w ten sposób
		for (var r=0; r < store.uiAnswersRows.length; r++) {
			var questionId = store.uiAnswersRows[r].prop('value');
			//var correctAnswer = findCorrectAnswerForQuestion(store, questionId);
			
			store.uiAnswersRows[r].each(function() {
            var item = $(this);
            var answerId = item.prop('value');
            var questionId = item.prop('name');
            var isChecked = item.prop('checked');
            if (isChecked) {
                isAnyChecked = true;
            }

			var isThisAnswerCorrect = true;

	


			if (isThisAnswerCorrect) {
            	if (isChecked) {
                	item.parent().parent().addClass("ex-correct");
            	}
            	else if (isChecked) {
                	item.parent().parent().addClass("ex-wrong");
                	allAnswersCorrect =false;
            	}
            }
        });
		}
*/

        store.uiAnswersTable.find("input").each(function() {
            var item = $(this);
            var answerId = item.prop('value');
            var questionId = item.prop('name');
            var isChecked = item.prop('checked');
            if (isChecked) {
                isAnyChecked = true;
            }


			var correctAnswer = findCorrectAnswerForQuestion(obj, questionId);			
			var isThisAnswerCorrect = false;
			if (correctAnswer == answerId)
				isThisAnswerCorrect = true;

			if (isThisAnswerCorrect) {
            	if (isChecked) {
                	item.parent().parent().addClass("ex-correct");
            	}
            	else {
                	item.parent().parent().addClass("ex-wrong");
                	allAnswersCorrect =false;
            	}
            }
        });

 	
    	
    
        prepareFeedback (obj, store, allAnswersCorrect);
    };
    
    var answerClicked = function(store, e) {
        var target = $(e.target);
        var input = $(e.currentTarget).find("input");
        var isRadio = input.attr("type") == "radio";
        var isTargetInput = target.is("input");
        if (!isTargetInput && input.prop("checked") && isRadio) {
            return;
        }

        if (isRadio) {
            if (input.data("last-checked") !== undefined) {
                return;
            }

            input.prop("checked", true);
            store.uiAnswers.find("input").each(function() {
                $(this).removeData("last-checked");
            });
            input.data("last-checked", "true");
        } else {
            if (!isTargetInput) {
                input.prop("checked", !input.prop("checked"));
            }
        }

        store.uiFeedbackHint.hide();
        store.uiFeedbackCorrect.hide();
        store.uiFeedbackWrong.hide();
        store.uiAnswersTable.find("tr").removeClass("ex-correct ex-wrong");
        store.uiButtonsHint.hide();
  
        store.uiButtonsCheck.removeAttr('disabled');
		store.uiButtonsCheck.attr('style', '');

    };

    
    var findCorrectAnswerForQuestion = function(obj, questionId) {
    	for (var q=0; q < obj.questions.length; q++) {
    		if (obj.questions[q].id == questionId) 
    			return obj.questions[q].correct;
    	}
    }

    //pokazuje info, że dobrze/źle i (w razie potrzeby 
    var prepareFeedback = function(obj, store, allAsnwersCorrect) {
        if (allAsnwersCorrect) {
            store.uiFeedbackCorrect.show();
            return true;
        } else {
            store.uiFeedbackWrong.show();
            prepareHint(obj, store);
            if (obj.description.hint) //bo jak nie ma żadnej podpowiedzi to nie pokazuj przycisku
            {
               store.uiButtonsHint.show();
            }
            return false;
        }
    };
    
    
    var prepareHint = function(obj, store) {
        store.uiButtonsHint.off("click");
        store.uiButtonsHint.text("Pokaż wskazówkę");
        store.uiButtonsHint.click(function() {
        	setHint(obj, obj.description.hint, store);
        });
    };
    
    var setHint = function(obj, str, store) {
        store.uiFeedbackHint.html(str);
        store.uiFeedbackHint.show();
        store.uiButtonsHint.off("click");
        store.uiButtonsHint.text("Schowaj wskazówkę");
        store.uiButtonsHint.click(function() {
            store.uiFeedbackHint.html("");
            store.uiFeedbackHint.hide();
            checkAnswer(obj, store, store);
        });
    };
    
    return {handle:handle};
});
