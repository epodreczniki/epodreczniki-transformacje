define(['jquery', 'modules/engines/enginesUtil', 'modules/util'], function($, enginesUtil, util) {
    'use strict';
    util.log("commonZJW loaded");

    var createContainers = function(obj, div, store) {
		try
		{
			var descriptionDiv = $("<div>", {
				class: "ex-description"
			});
			descriptionDiv.appendTo(div);

			store.uiAnswers = $("<div>", {
				class: "ex-main " + obj.config.type.toLowerCase()
			});
			store.uiAnswers.appendTo(div);

			store.uiFeedback = $("<div>", {
				class: "ex-feedback"
			});
			store.uiFeedback.appendTo(div);

			store.uiButtons = $("<div>", {
				class: "ex-buttons"
			});
			store.uiButtons.appendTo(div);

			//

			store.uiTitle = $("<div>", {
				class: "ex-title",
				html: obj.description.title
			});
			store.uiTitle.appendTo(descriptionDiv);

			store.uiContent = $("<div>", {
				class: "ex-content",
				html: obj.description.content
			});
			store.uiContent.appendTo(descriptionDiv);

			//

			store.uiFeedbackCorrect = $("<div>", {
				class: "ex-correct",
				html: obj.description.correctFeedback
			});
			store.uiFeedbackCorrect.appendTo(store.uiFeedback);

			store.uiFeedbackWrong = $("<div>", {
				class: "ex-wrong",
				html: obj.description.wrongFeedback
			});
			store.uiFeedbackWrong.appendTo(store.uiFeedback);

			store.uiFeedbackHint = $("<div>", {
				class: "ex-hint",
				html: "hint"
			});
			store.uiFeedbackHint.appendTo(store.uiFeedback);
        }
    	catch (e) {
    		console.log(e);
    	}

    };

    var makeButtons = function(obj, div, store) {
		try
		{
			store.uiButtonsCheck = $('<button>', {
				text: "Sprawdź",
				class: "ex-btn-check"
			});
			store.uiButtonsCheck.click(function() {
				checkAnswer(obj, store);
			});
			store.uiButtons.append(store.uiButtonsCheck);

			store.uiButtonsHint = $('<button>', {
				text: "Pokaż wskazówkę",
				class: "ex-btn-hint"
			});
			prepareHint(obj, null, store);
			store.uiButtons.append(store.uiButtonsHint);

			store.uiButtonsNextExample = $('<button>', {
				text: "Nowe zadanie",
				class: "ex-btn-clear"
			});
			store.uiButtonsNextExample.click(function() {
				buildAnswersList(obj, div, store, null);
				util.setStateForWomi(store.womiId, null);
			});
			store.uiButtons.append(store.uiButtonsNextExample);
        }
    	catch (e) {
    		console.log(e);
    	}

    };

    var buildAnswersList = function(obj, div, store, state) {
		try
		{
			store.uiAnswers.html("");
			store.uiFeedbackHint.hide();
			store.uiFeedbackCorrect.hide();
			store.uiFeedbackWrong.hide();
			store.uiButtonsHint.hide();
	   
			store.uiButtonsCheck.attr('disabled', 'disabled');
			store.uiButtonsCheck.attr('style', 'color: #BBBBBB;');
			
			
			if(state)
			{
				//load answers
				store.shownAnswers = state.shownAnswers;
			}
			else
			{
				if (obj.config.answerSets == false) {
					if (obj.config.randomize) {
						store.shownAnswers = chooseRandomAnswers(obj, obj.answers, store);
					} else {
						store.shownAnswers = obj.answers;
					}
				} else {
					var arrRandomSet = chooseRandomSet(obj, obj.answers, store);
					if (obj.config.randomize) {
						store.shownAnswers = chooseRandomAnswers(obj, arrRandomSet, store);
					} else {
						store.shownAnswers = arrRandomSet;
					}
				}
			}


			if (store.configError)
			{
				var errorDiv = $("<div>", {
					class: "answer-row",
					html: store.configError
				});
				store.uiAnswers.append(errorDiv);
			}
			else
			{
				var inputType = "radio";
				if (obj.config.numberOfCorrectAnswerInSet > 1) {
					inputType = "checkbox";
				}

				if (obj.config.type == "ZW-2") {
					buildAnswers_TrueFalse(obj, store.shownAnswers, store, state);
					return;
				}

				for (var i = 0; i < store.shownAnswers.length; i++) {
					var newAnswer = $('<div>', {
						class: "answer-item"
					});
					var style = '';
					if ((/^<img/).test(store.shownAnswers[i].content)) {
						style = 'display: inline-block';
					}

					newAnswer.append(
						$('<input>', {
							class: "answer-input",
							type: inputType,
							name: "answer",
							value: store.shownAnswers[i].id
						}),
						$('<div>', {
							class: "answer-content",
							html: store.shownAnswers[i].content,
							style: style
						})
					);
					newAnswer.click(function(e) {
						answerClicked(store, e);
					});
			
					var answerRow = $("<div>", {
						class: "answer-row"
					});
					answerRow.append(newAnswer);
					store.uiAnswers.append(answerRow);
				}
			}
			
			//load checked answers
			if(state)
			{
				store.uiAnswers.find("input").each(function(idx, input) {
					if(state.checked[idx]) {
						$(input).trigger("click");
					};
				});
			};
			
        }
    	catch (e) {
    		console.log(e);
    	}

    };

    var prepareHint = function(obj, answer, store) {
        store.uiButtonsHint.off("click");
        store.uiButtonsHint.text("Pokaż wskazówkę");
        store.uiButtonsHint.click(function() {
            if (answer && answer.hint) {
                setHint(obj, answer.hint, store);
            } else {
                setHint(obj, obj.description.hint, store);
            }
        });
    };

    var setHint = function(obj, str, store) {
        store.uiFeedbackHint.html(str);
        store.uiFeedbackHint.show();
        store.uiButtonsHint.off("click");
        store.uiButtonsHint.text("Schowaj wskazówkę");
        store.uiButtonsHint.click(function() {
            store.uiFeedbackHint.html("");
            store.uiFeedbackHint.hide();
            checkAnswer(obj, store, store);
        });
    };

    var chooseRandomAnswers = function(obj, allAnswers, store) {
        var arrCorrectAnswer = [];
        var arrWrongAnswers = [];

        for (var i = 0; i < allAnswers.length; i++) {
            if (allAnswers[i].correct) {
                arrCorrectAnswer[arrCorrectAnswer.length] = allAnswers[i];
            } else {
                arrWrongAnswers[arrWrongAnswers.length] = allAnswers[i];
            }
        }

        var arrChoosenCorrectAnsw = [];
        if (obj.config.numberOfCorrectAnswerInSet > arrCorrectAnswer.length)
        {
            //alert("W zadaniu '" + obj.description.title + "' są tylko " + arrCorrectAnswer.length + 
              //      " poprawne odpowiedzi, więc nie można wybrać " + obj.config.numberOfCorrectAnswerInSet);
            store.configError = "[Zadanie zdefiniowane niepoprawnie - za mało poprawnych odpowiedzi]" ;
        }
        else
        {
            for (var c = 0; c < obj.config.numberOfCorrectAnswerInSet; c++) {
                var r = Math.floor(Math.random() * (arrCorrectAnswer.length));
                arrChoosenCorrectAnsw[arrChoosenCorrectAnsw.length] = arrCorrectAnswer[r];
                arrCorrectAnswer.splice(r, 1); //usun, zeby go nie wylosować dwa razy
            }
        }

        var numWrong = obj.config.numberOfPresentedAnswers - obj.config.numberOfCorrectAnswerInSet;
        if (numWrong > arrWrongAnswers.length)
        {
            //alert("W zadaniu '" + obj.description.title + "' jest zbyt mało niepoprawnych odpowidzi. ");
            store.configError = "[Zadanie źle zdefiniowane - zła liczba odpowiedzi poprawnych/niepoprawnych]";
        }
        else
        {
            var arrChoosenWrongAns = [];
            for (var w = 0; w < numWrong; w++) {
                var r = Math.floor(Math.random() * (arrWrongAnswers.length));
                arrChoosenWrongAns[arrChoosenWrongAns.length] = arrWrongAnswers[r];
                arrWrongAnswers.splice(r, 1);
            }
        }
        
        var arrChoosen = arrChoosenCorrectAnsw.concat(arrChoosenWrongAns);
        arrChoosen = enginesUtil.shuffleArray(arrChoosen);

        return arrChoosen;
    };

    var checkAnswer = function(obj, store) {
	
        if (obj.config.type == "ZW-2") {
            return checkAnswers_TrueFalse(obj, store);
        }

        var allAsnwersCorrect = true;
        var answerWithSpecialHint;
        var isAnyChecked = false;

        store.uiAnswers.find("input").each(function() {
            var item = $(this);
            var answerId = item.prop('value');
            var isChecked = item.prop('checked');
            if (isChecked) {
                isAnyChecked = true;
            }

            for (var i = 0; i < obj.answers.length; i++) {
                if (obj.answers[i].id == answerId) {
                    if (obj.answers[i].correct != isChecked) {
                        allAsnwersCorrect = false;
                        if (obj.answers[i].hint) {
                            answerWithSpecialHint = obj.answers[i];
                        }
                    }

                    if (obj.answers[i].correct && isChecked) {
                        item.parent().parent().addClass("ex-correct");
                    }
                    if (!obj.answers[i].correct && isChecked) {
                        item.parent().parent().addClass("ex-wrong");
                    }
                    break;
                }
            }
        });

        prepareFeedback (obj, answerWithSpecialHint, store, allAsnwersCorrect);
    };

    //pokazuje info, że dobrze/źle i (w razie potrzeby 
    var prepareFeedback = function(obj, answerWithSpecialHint, store, allAsnwersCorrect) {
        if (allAsnwersCorrect) {
            store.uiFeedbackCorrect.show();
            return true;
        } else {
            store.uiFeedbackWrong.show();
            prepareHint(obj, answerWithSpecialHint, store);
            if ((answerWithSpecialHint && answerWithSpecialHint.hint) || obj.description.hint) //bo jak nie ma żadnej podpowiedzi to nie pokazuj przycisku
            {
               store.uiButtonsHint.show();
            }
            return false;
        }
    };

    var checkAnswers_TrueFalse = function(obj, store) {
        var allAsnwersCorrect = true;
        var answerWithSpecialHint;
        var isAnyChecked = false;

        store.uiAnswers.find("input").each(function() {
            var item = $(this);
            var answerId = item.prop('value');
            var isChecked = item.prop('checked');
            var inputClass = item.data('data-input-type');
            if (isChecked) {
                isAnyChecked = true;
            }

            for (var i = 0; i < obj.answers.length; i++) {
                if (obj.answers[i].id == answerId) {
                    if (inputClass == "radio-answer-true") {
                        if (obj.answers[i].correct != isChecked) {
                            allAsnwersCorrect = false;
                            if (obj.answers[i].hint) {
                                answerWithSpecialHint = obj.answers[i];
                            }
                        }

                        if (obj.answers[i].correct && isChecked) {
                            item.parent().parent().addClass("ex-correct");
                        }
                        else if (!obj.answers[i].correct && isChecked) {
                            item.parent().parent().addClass("ex-wrong");
                        }
                    } else {
                        if (obj.answers[i].correct == isChecked) {
                            allAsnwersCorrect = false;
                            if (obj.answers[i].hint) {
                                answerWithSpecialHint = obj.answers[i];
                            }
                        }

                        if (!obj.answers[i].correct && isChecked) {
                            item.parent().parent().addClass("ex-correct");
                        }
                        else if (obj.answers[i].correct && isChecked) {
                            item.parent().parent().addClass("ex-wrong");
                        }
                    }
                    break;
                }
            }
        });
        store.uiAnswers.find(".answer-row").each(function(index, elem) {
        	var checked = false;
        	var $elem = $(elem);
			$elem.find("input").each(function(index, input) {
        		checked |= $(input).prop('checked');
        	});
        	if (!checked) {
        		$elem.addClass("ex-wrong");
        	}
        });

        prepareFeedback (obj, answerWithSpecialHint, store, allAsnwersCorrect);
    };

    var buildAnswers_TrueFalse = function(obj, shownAnswers, store, state) {
        for (var i = 0; i < shownAnswers.length; i++) {
            var answerRow = $("<div>", {
            	class: "answer-row"
            });
            store.uiAnswers.append(answerRow);
            
            answerRow.append($('<div>', {
            	class: "answer-title",
                html: shownAnswers[i].content
            }));
            var newAnswerTrue = $('<div>', {
            	class: "answer-item"
            });
            newAnswerTrue.append(
                $('<input>', {
                	class: "answer-input",
                    type: "radio",
                    name: "answer" + shownAnswers[i].id,
                    value: shownAnswers[i].id
                }).data("data-input-type", "radio-answer-true"),
                $('<div>', {
                	class: "answer-content",
                    text: "Prawda"
                })
            );
            newAnswerTrue.click(function(e) {
                answerClicked(store, e);
            });
            answerRow.append(newAnswerTrue);

            var newAnswerFalse = $('<div>', {
            	class: "answer-item"
            });
            newAnswerFalse.append(
                $('<input>', {
                    class: "answer-input",
                    type: "radio",
                    name: "answer" + shownAnswers[i].id,
                    value: shownAnswers[i].id
                }).data("data-input-type", "radio-answer-false"),
                $('<div>', {
                	class: "answer-content",
                    text: "Fałsz"
                })
            );
            newAnswerFalse.click(function(e) {
                answerClicked(store, e);
            });
            answerRow.append(newAnswerFalse);
        }
		
		//load checked answers
		if(state)
		{
			store.uiAnswers.find("input").each(function(idx, input) {
				if(state.checked[idx]) {
					$(input).trigger("click");
				};
			});
		};
    }

    var answerClicked = function(store, e) {
        var target = $(e.target);
        var input = $(e.currentTarget).find("input");
        var isRadio = input.attr("type") == "radio";
        var isTargetInput = target.is("input");
        if (!isTargetInput && input.prop("checked") && isRadio) {
            return;
        }

        if (isRadio) {
            if (input.data("last-checked") !== undefined) {
                return;
            }

            input.prop("checked", true);
            store.uiAnswers.find("input").each(function() {
                $(this).removeData("last-checked");
            });
            input.data("last-checked", "true");
        } else {
            if (!isTargetInput) {
                input.prop("checked", !input.prop("checked"));
            }
        }

        store.uiFeedbackHint.hide();
        store.uiFeedbackCorrect.hide();
        store.uiFeedbackWrong.hide();
        store.uiAnswers.find("div").removeClass("ex-correct ex-wrong");
        store.uiButtonsHint.hide();
  
        store.uiButtonsCheck.removeAttr('disabled');
		store.uiButtonsCheck.attr('style', '');
			
		saveState(store);
    };
	
	var saveState = function (store) {
		var checked = [];

		store.uiAnswers.find("input").each(function() {
			checked.push($(this).prop("checked")?true:false);
		});

		var state = {
			shownAnswers: store.shownAnswers,
			checked: checked
		};
		util.setStateForWomi(store.womiId, state);
	};


    var chooseRandomSet = function(obj, allAnswers, store) {
        var dictSets = {};
        for (var i = 0; i < allAnswers.length; i++) {
            var setId = allAnswers[i].set;

            if (dictSets[setId] == undefined) {
                dictSets[setId] = [];
            }
            dictSets[setId].push(allAnswers[i]);
        }
        return dictSets[randomKey(dictSets)];
    }

    var randomKey = function(obj, store) {
        var ret;
        var c = 0;
        for (var key in obj)
            if (Math.random() < 1 / ++c)
                ret = key;
        return ret;
    };

    return {
        createContainers: createContainers,
        makeButtons: makeButtons,
        buildAnswersList: buildAnswersList
    };
});