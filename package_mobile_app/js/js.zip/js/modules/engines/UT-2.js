define(['jquery','modules/util'],function($,util){
    'use strict';
    util.log("ut-2 loaded");    
    var handle = function(obj,div,womiId,stateObj){       
        var shuffle = function(array){
            var m = array.length, t, i;
            while (m) {
                i = Math.floor(Math.random() * m--);
                t = array[m];
                array[m] = array[i];
                array[i] = t;
            }
            return array;
        };
        var clearExercise = function(){
            clearFeedback();
            $mainDiv.find("select").val("");
        };
        var clearFeedback = function(){
            $mainDiv.find("select").removeClass("ex-wrong ex-correct");
            $correct.css("display","none");
            $wrong.css("display","none");
        };
        var correctAnswers = {}; 
        util.log("handling ut-2");
        var $mainDiv = $(div);
        $mainDiv.addClass("momi");
        var $exDescription = $("<div></div>").addClass("ex-description");
        $mainDiv.append($exDescription);
        var $title = $("<div></div>").addClass("ex-title").html(obj.description.title);
        $exDescription.append($title);
        var $descContent = $("<div></div>").addClass("ex-content").html(obj.description.content);
        $exDescription.append($descContent);
        var $exDiv = $("<div></div>").addClass("ex-main ut-2");
        $mainDiv.append($exDiv);
        $.each(obj.body,function(idx,item){
            if(item.preInputText){
                var $sp = $("<span></span>").html(item.preInputText);
                $exDiv.append($sp);
            }
            var $select = $("<select></select>").data("id",item.id);
            $select.on("change",function(){
                clearFeedback();
				saveState(womiId, $mainDiv);
            });
            var $pl = $("<option value='' disabled selected>"+(item.placeholder?item.placeholder:"Wybierz...")+"</option>");
            $select.append($pl);
            var optionsArray = [];
            $.each(item.answersId,function(optIdx,optId){
                var opt = {};
                opt["val"]=optId;
                $.each(obj.answers,function(ansIdx,answer){
                    if(optId===answer.id){
                        opt["content"]=answer.content;
                        if(answer.correct){
                            correctAnswers[item.id]=answer.id;
                        }
                    }
                });
                optionsArray.push(opt);
            });
            if(obj.config.randomize){
                shuffle(optionsArray);
            }
            $.each(optionsArray,function(optIdx,opt){
                var $option = $("<option>"+opt.content+"</option>").val(opt.val);
                $select.append($option);
            });
            
            $exDiv.append($select);
            // no alt for select
            if(item.postInputText){
                var $sp = $("<span></span>").html(item.postInputText);
                $exDiv.append($sp);
            }
            if(item.lineBreak){
                $exDiv.append($("<br />"));
            }
        });
        
        var $feedback = $("<div></div>").addClass("ex-feedback");
        $mainDiv.append($feedback);
        var $correct = $("<div></div>").addClass("ex-correct").html(obj.description.correctFeedback);
        $feedback.append($correct);
        var $wrong = $("<div></div>").addClass("ex-wrong").html(obj.description.wrongFeedback);
        $feedback.append($wrong);
        var $hint = $("<div></div>").addClass("ex-hint").html(obj.description.hint);
        $feedback.append($hint);
            
        var $exerciseButtons = $("<div></div>").addClass("ex-buttons");
        var $clear = $("<button type='button'>Wyczyść</button>").addClass("ex-btn-clear");
        $clear.on("click",function(){
            clearExercise();
			util.setStateForWomi(womiId, null);
        });
        $exerciseButtons.append($clear);
        var $check = $("<button type='button'>Sprawdź</button>").addClass("ex-btn-check");
        $check.on("click",function(){
            clearFeedback();
            var $selects = $mainDiv.find("select");
            var somethingWrong = false;
            $selects.each(function(idx,sel){
                var qid = $(sel).data("id");
                if(correctAnswers[qid]===$(sel).val()){
                    $(sel).addClass("ex-correct");
                }else{
                    $(sel).addClass("ex-wrong");
                    somethingWrong = true;
                }
            });
            if(somethingWrong){
                if(!!obj.description.hint){
                    $showHint.css("display","inline-block");
                }
                $wrong.css("display","block");
            }else{
                $correct.css("display","block");
            }
        });
        $exerciseButtons.append($check);
        var $showHint = $("<button type='button'>Wskazówka</button>").addClass("ex-btn-hint");
        $showHint.on("click",function(){
            var s = $hint.attr("style");
            if(s!==undefined&&s!==false){
                $hint.removeAttr("style");
                $(this).html("Wskazówka");
            }else{
                $hint.css("display","block");
                $(this).html("Ukryj wskazówkę");
            }
            //if($hint.hasClass("ut-hidden")){
            //    $hint.removeClass("ut-hidden");
            //    $(this).html("Ukryj wskazówkę");
            //}else{
            //    $hint.addClass("ut-hidden");
            //    $(this).html("Wskazówka");
            //}
        });
        $exerciseButtons.append($showHint);
        $mainDiv.append($exerciseButtons);
		
		loadState(stateObj, $mainDiv);
        
    };
	
	var saveState = function (womiId, $mainDiv) {
		var state = [];
        var $selects = $mainDiv.find("select");
        $selects.each(function(idx,sel){
            var vid = $(sel).val();
            state.push(vid);
        });
		util.setStateForWomi(womiId, state);
    };
	
	var loadState = function (state, $mainDiv) {
		if(state)
		{
			var $selects = $mainDiv.find("select");
			$selects.each(function(idx,sel){
				$(sel).val(state[idx]);
			});
		}
	};
	
    return {
        handle:handle
    };
});

