﻿define(['modules/engines/enginesUtil','modules/util','jqtouch'], function (enginesUtil, util) {
    'use strict';
    util.log("dgs-2 loaded");
    var handle = function(obj, div,womiId,stateObj){
        util.log("handling dgs-2");
        var cfg = {
            ex: obj,
            $div: $(div),
			womiId: womiId
        };
        cfg.ex.config.id = cfg.$div.uniqueId().attr("id");
        cfg.$div.removeUniqueId();

        generate(cfg, stateObj);
    };

    var generate = function (cfg, stateObj) {
        //Opis zadania
        var $output = $("<div></div>", {
            "class": "ex-description"
        });
        $("<div></div>", {
            "class": "ex-title",
            text: cfg.ex.description.title
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-content"
        }).append(cfg.ex.description.content).appendTo($output);
        cfg.$div.append($output);

        //Zadanie
        $output = $("<div></div>", {
            "class": "ex-main dgs-1",
            id: cfg.ex.config.id
        });
        var $collection = $("<ul></ul>");
        var array = cfg.ex.sortable;
		if (stateObj) {
			//load state
			var lastState = [];
			for (var i = 0; i < stateObj.length; i++)
			{
				var elem = $.grep(cfg.ex.sortable, function (n) { return n.id == stateObj[i] })[0];
				lastState.push(elem);
			};
			array = lastState;
		} else {
			if (cfg.ex.config.randomize) {
				array = enginesUtil.shuffleArray(cfg.ex.sortable);
			};
		}
        
        $.each(array, function (i, val) {
            if (val.content.indexOf("<img") >= 0) {
                $("<li></li>", {
                    "class": "value picture",
                    "data-pk": val.id
                }).append(val.content).appendTo($collection);
            } else {
                $("<li></li>", {
                    "class": "value",
                    text: val.content,
                    "data-pk": val.id
                }).appendTo($collection);
            };
        });
        $("<div></div>", {
            "class": "sort-zone"
        }).append($collection).appendTo($output);
        cfg.$div.append($output);

        //Rezultat
        $output = $("<div></div>", {
            "class": "ex-feedback"
        });
        $("<div></div>", {
            "class": "ex-correct",
            text: cfg.ex.description.correctFeedback
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-wrong",
            text: cfg.ex.description.wrongFeedback
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<div></div>", {
                "class": "ex-hint",
                text: cfg.ex.description.hint
            }).appendTo($output);
            cfg.$div.append($output);
        };

        //Przyciski kontrolne
        $output = $("<div></div>", {
            "class": "ex-buttons"
        });
        $("<button></button>", {
            "class": "ex-btn-clear",
            text: "Nowe zadanie",
            on: {
                click: function (event) {
                    reset(cfg);
                }
            }
        }).appendTo($output);
        $("<button></button>", {
            "class": "ex-btn-check",
            text: "Sprawdź",
            on: {
                click: function (event) {
                    check(cfg);
                }
            }
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<button></button>", {
                "class": "ex-btn-hint",
                text: "Pokaż wskazówkę",
                on: {
                    click: function (event) {
                        hint(cfg);
                    }
                }
            }).appendTo($output);
        };
        cfg.$div.append($output);

        cfg.$div.find(".sort-zone ul").sortable({
            revert: true,
            revertDuration: 150,
            containment: cfg.$div.find("ul"),
            cursor: "move",
            cursorAt: { top: 12, left: 12 },
            disable: false,
            placeholder: "placeholder",
            distance: 5,
            forcePlaceholderSize: true,
            opacity: 0.5,
            tolerance: "pointer",
            scroll: false,
            create: function () {
                var _this = $(this);
                setTimeout(function () {
                    _this.height(_this.height());
                }, 2000);
            },
            start: function (event, ui) {
                cfg.$div.find(".ex-main").trigger("click");
            },
            stop: function (event, ui) {
				saveState(cfg);
            }
        });
    };

    var reset = function (cfg) {
        cfg.$div.empty();
        generate(cfg, null);
        util.setStateForWomi(cfg.womiId, null);
    };

    var check = function (cfg) {
        var good = true;

        $.each($("#" + cfg.ex.config.id + " .sort-zone ul").children(), function (answerIndex, answer) {
            if (cfg.ex.correctOrder[answerIndex] == $(answer).data("pk")) {
                $(answer).addClass("correct")
            }
            else {
                $(answer).addClass("wrong")
                good = false;
            };
        });

        if (good) {
            cfg.$div.find(".ex-correct").slideDown(250, "linear");
        } else {
            cfg.$div.find(".ex-wrong").slideDown(250, "linear");
            cfg.$div.find(".ex-btn-hint").fadeIn(250, "linear");
        };

        cfg.$div.find(".ex-main").bind("click", function () {
            cfg.$div.find(".value").removeClass("correct wrong", "fast", "linear");
            cfg.$div.find(".ex-correct").slideUp(250, "linear");
            cfg.$div.find(".ex-wrong").slideUp(250, "linear");

            $(this).unbind("click");
        });
	};

	var hint = function(cfg) {
	    var $hint = cfg.$div.find(".ex-hint");

	    if ($hint.css('display') == 'none') {
	        $hint.slideDown(250, "linear", function () {
	            cfg.$div.find(".ex-btn-hint").text("Schowaj wskazówkę");
	        });
	    }
	    else {
	        $hint.slideUp(250, "linear", function () {
	            cfg.$div.find(".ex-btn-hint").text("Pokaż wskazówkę");
	        });
	    };
	};

	var saveState = function (cfg) {
		var state = [];
		$.each($("#" + cfg.ex.config.id + " .sort-zone ul").children(), function (answerIndex, answer) {
			state.push($(answer).data("pk"));
		});
		util.setStateForWomi(cfg.womiId, state);
	};
	
    return {
        handle:handle
    };
});
