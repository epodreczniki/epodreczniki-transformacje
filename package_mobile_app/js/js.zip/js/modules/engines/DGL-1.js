define(['modules/engines/enginesUtil', 'modules/tooltips', 'modules/util', 'jqtouch'], function (enginesUtil, tooltips, util) {
    'use strict';
    util.log("dgl-1 loaded");
    var handle = function(obj, div,womiId,stateObj){
        util.log("handling dgl-1");
        var cfg = {
            $el: null,
            touch: enginesUtil.isAndroid ? true : false,
            left: false,
            answers: [],
            ex: obj,
            $div: $(div),
            checked: false,
			womiId: womiId
        };
        cfg.ex.config.id = cfg.$div.uniqueId().attr("id");
        cfg.$div.removeUniqueId();

		if(stateObj) {
			cfg.touch = stateObj.shift();
		};
        generate(cfg);
		loadState(cfg, stateObj);
    };

    var saveState = function (cfg) {
        var pairs = [];
		pairs.push(cfg.touch);
        $.each(cfg.ex.droppable, function (i, val) {
            var $el1 = cfg.$div.find("[data-pk='" + val.id + "']");
            if ($el1.data("fk"))
            {
                pairs.push($el1.data("fk"));
                pairs.push($el1.data("pk"));
            }
        });
		util.setStateForWomi(cfg.womiId, pairs);
    }

    var generate = function (cfg) {
        //Opis zadania
        var $output = $("<div></div>", {
            "class": "ex-description"
        });
        $("<div></div>", {
            "class": "ex-title",
            text: cfg.ex.description.title
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-kind",
            text: "Aktywny tryb: " + (cfg.touch ? "Dotykowy" : "Przeciągnij i upuść"),
            on: {
                click: function (event) {
                    tooltips.showDlgModeInfo();
                }
            }
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-content"
        }).append(cfg.ex.description.content).appendTo($output);
        cfg.$div.append($output);

        //Zadanie
        $output = $("<div></div>", {
            "class": "ex-main dgl-1",
            id: cfg.ex.config.id
        });
        //Lewa kolumna
        var $collection = $("<div></div>", {
            "class": "left"
        });
        var array = cfg.ex.draggable;
        if (cfg.ex.config.randomize) {
            array = enginesUtil.shuffleArray(cfg.ex.draggable);
        };
        $.each(array, function (i, val) {
            if (val.content.indexOf("<img") >= 0) {
                $("<div></div>", {
                    "class": "value picture",
                    "data-pk": val.id
                }).append(val.content).appendTo($collection);
            } else {
                $("<div></div>", {
                    "class": "value",
                    text: val.content,
                    "data-pk": val.id
                }).appendTo($collection);
            };
        });
        $output.append($collection);
        cfg.$div.append($output);
        //Prawa kolumna
        $collection = $("<div></div>", {
            "class": "right"
        });
        array = cfg.ex.droppable;
        if (cfg.ex.config.randomize) {
            array = enginesUtil.shuffleArray(cfg.ex.droppable);
        };
        $.each(array, function (i, val) {
            if (val.content.indexOf("<img") >= 0) {
                $("<div></div>", {
                    "class": "value picture",
                    "data-pk": val.id
                }).append(val.content).appendTo($collection);
            } else {
                $("<div></div>", {
                    "class": "value",
                    text: val.content,
                    "data-pk": val.id
                }).appendTo($collection);
            };
        });
        $output.append($collection);
        cfg.$div.append($output);

        //Rezultat
        $output = $("<div></div>", {
            "class": "ex-feedback"
        });
        $("<div></div>", {
            "class": "ex-correct",
            text: cfg.ex.description.correctFeedback
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-wrong",
            text: cfg.ex.description.wrongFeedback
        }).appendTo($output);

        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<div></div>", {
                "class": "ex-hint",
                text: cfg.ex.description.hint
            }).appendTo($output);
            cfg.$div.append($output);
        };

        //Przyciski kontrolne
        $output = $("<div></div>", {
            "class": "ex-buttons"
        });
        $("<button></button>", {
            "class": "ex-btn-clear",
            text: "Nowe zadanie",
            on: {
                click: function (event) {
                    reset(cfg);
                }
            }
        }).appendTo($output);
        $("<button></button>", {
            "class": "ex-btn-change",
            text: "Zmień tryb",
            on: {
                click: function (event) {
                    cfg.touch = !cfg.touch;
                    reset(cfg);
                }
            }
        }).appendTo($output);
        $("<button></button>", {
            "class": "ex-btn-check",
            text: "Sprawdź",
            on: {
                click: function (event) {
                    check(cfg);
                }
            }
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<button></button>", {
                "class": "ex-btn-hint",
                text: "Pokaż wskazówkę",
                on: {
                    click: function (event) {
                        hint(cfg);
                    }
                }
            }).appendTo($output);
        };
        cfg.$div.append($output);

        if (cfg.touch) {
            cfg.$div.find(".left .value").bind("click", function () {
                cfg.$div.find(".ex-main").trigger("click");
                if (cfg.$el == null) {
                    cfg.$el = $(this);
                    $(this).addClass("connected");
                    cfg.left = true;
                } else if (!cfg.left) {
                    connect(cfg, $(this), cfg.$el);
                    cfg.$el = null;
                };
            });

            cfg.$div.find(".right .value").bind("click", function () {
                cfg.$div.find(".ex-main").trigger("click");
                if (cfg.$el == null) {
                    cfg.$el = $(this);
                    $(this).addClass("connected");
                    cfg.left = false;
                } else if (cfg.left) {
                    connect(cfg, $(this), cfg.$el);
                    cfg.$el = null;
                };
            });
        } else {
            cfg.$div.find(".left .value").draggable({
                revert: true,
                revertDuration: 150,
                helper: "clone",
                containment: cfg.$div,
                cursor: "move",
                cursorAt: { top: 12, left: 12 },
                scroll: array.length > 10 ? true : false,
                start: function (event, ui) {
                    cfg.$div.find(".ex-main").trigger("click");
                }
            });

            cfg.$div.find(".right .value").draggable({
                revert: true,
                revertDuration: 150,
                helper: "clone",
                containment: cfg.$div,
                cursor: "move",
                cursorAt: { top: 12, left: 12 },
                scroll: array.length > 10 ? true : false,
                start: function (event, ui) {
                    cfg.$div.find(".ex-main").trigger("click");
                }
            });

            cfg.$div.find(".left .value").droppable({
                tolerance: 'pointer',
                accept: cfg.$div.find(".right .value"),
                drop: function (event, ui) {
                    connect(cfg, $(this), $(ui.draggable));
                }
            });

            cfg.$div.find(".right .value").droppable({
                tolerance: 'pointer',
                accept: cfg.$div.find(".left .value"),
                drop: function (event, ui) {
                    connect(cfg, $(ui.draggable), $(this));
                }
            });
        };

        $(window).resize(function () {
            resize(cfg);
        });
	};

    var loadState = function (cfg, pairs) {
        if(pairs)
        {
            for(var i = 0; i < pairs.length; i+=2)
            {
                var el1pk = pairs[i];
                var el2pk = pairs[i+1];

                var $el1 = cfg.$div.find("[data-pk='" + el1pk + "']");
                var $el2 = cfg.$div.find("[data-pk='" + el2pk + "']");

                $el1.data('fk', el2pk).addClass("connected", 250, "easeInBack");
                $el2.data('fk', el1pk).addClass("connected", 250, "easeInBack");
            }

            redraw(cfg, false);
        }
    };

    var reset = function (cfg) {
        cfg.$div.empty();
        util.setStateForWomi(cfg.womiId, null);
        generate(cfg);
    };

    var check = function (cfg) {
        var all = true;
        $.each(cfg.ex.droppable, function (i, val) {
            var $el1 = cfg.$div.find("[data-pk='" + val.id + "']");
            if (!$el1.data("fk")) {
                all = false;
                return false;
            };
        });

        var good = true;
        if (!all) {
            good = false;
        };

        $.each(cfg.ex.droppable, function (i, val) {
            var $el1 = cfg.$div.find("[data-pk='" + val.id + "']");
            if ($el1.data("fk")) {
                var $el2 = cfg.$div.find("[data-pk='" + $el1.data("fk") + "']");
                if (val.correctDrg[0] == $el1.data("fk")) {
                    $el1.addClass("correct");
                    $el2.addClass("correct");
                } else {
                    $el1.addClass("wrong");
                    $el2.addClass("wrong");
                    good = false;
                };
            };
        });

        cfg.checked = true;
        redraw(cfg, true);

        if (good) {
            cfg.$div.find(".ex-correct").slideDown(250, "linear");
        } else {
            cfg.$div.find(".ex-wrong").slideDown(250, "linear");
            cfg.$div.find(".ex-btn-hint").fadeIn(250, "linear");
        };

        cfg.$div.find(".ex-main").bind("click", function () {
            cfg.$div.find(".value").removeData("fk").removeClass("connected correct wrong", "fast", "linear");
            cfg.$div.find(".line").fadeOut("fast", "linear", function () { $(this).remove(); });
            cfg.$div.find(".ex-correct").slideUp(250, "linear");
            cfg.$div.find(".ex-wrong").slideUp(250, "linear");
            cfg.checked = false;

            $(this).unbind("click");
        });
    }

    var hint = function (cfg) {
        var $hint = cfg.$div.find(".ex-hint");

        if ($hint.css('display') == 'none') {
            $hint.slideDown(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Schowaj wskazówkę");
            });
        }
        else {
            $hint.slideUp(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Pokaż wskazówkę");
            });
        };
    };

    var resize = function (cfg) {
        redraw(cfg, cfg.checked);
    };

    var connect = function (cfg, $el1, $el2) {
        if ($el1.data('fk')) {
            cfg.$div.find("[data-pk='" + $el1.data('fk') + "']").removeClass("connected", 250, "easeOutBack").removeData('fk');
        };
        if ($el2.data('fk')) {
            cfg.$div.find("[data-pk='" + $el2.data('fk') + "']").removeClass("connected", 250, "easeOutBack").removeData('fk');
        };

        $el1.data('fk', $el2.data('pk')).addClass("connected", 250, "easeInBack");
        $el2.data('fk', $el1.data('pk')).addClass("connected", 250, "easeInBack");

        redraw(cfg, false);
		
		saveState(cfg);
    };

    var redraw = function (cfg, check) {
        cfg.$div.find(".line").remove();

        $.each(cfg.ex.droppable, function (i, val) {
            var $el1 = cfg.$div.find("[data-pk='" + val.id + "']");
            if ($el1.data("fk")) {
                var $el2 = cfg.$div.find("[data-pk='" + $el1.data("fk") + "']");
                var css = "";
                if (check) {
                    if (val.correctDrg[0] == $el1.data("fk")) {
                        css = " correct";
                    } else {
                        css = " wrong";
                    };
                };
                draw(cfg, $el2, $el1, css);
            };
        });
    };

    var draw = function (cfg, $div1, $div2, css) {
        var off1 = $div1.position();
        var off2 = $div2.position();
        var thickness = 1;

        // Pozycja kreski przy lewej kolumnie
        var x1 = off1.left + $div1.outerWidth(true);
        var y1 = off1.top + ($div1.outerHeight(true) / 2);
        // Pozycja kreski przy prawej kolumnie
        var x2 = off2.left;
        var y2 = off2.top + ($div2.outerHeight(true) / 2);

        // Długość kreski
        var length = Math.sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)));
        // Środek kreski
        var cx = ((x1 + x2) / 2) - (length / 2);
        var cy = ((y1 + y2) / 2) - (thickness / 2);
        // Kąt
        var angle = Math.atan2((y1 - y2), (x1 - x2)) * (180 / Math.PI);
        // Html

        $("<div></div>", {
            "class": "line" + css
        }).css({
            'left': cx,
            'top': cy,
            'width': length,
            '-moz-transform': 'rotate(' + angle + 'deg)',
            '-webkit-transform': 'rotate(' + angle + 'deg)',
            '-o-transform': 'rotate(' + angle + 'deg)',
            '-ms-transform': 'rotate(' + angle + 'deg)',
            'transform': 'rotate(' + angle + 'deg)'
        }).appendTo(cfg.$div.find(".dgl-1"));
    };

    return {
        handle:handle
    };
});
