define(['modules/engines/commonZJW', 'modules/util'], function (commonZJW, util) {
    'use strict';
    
    util.log("zw-2 loaded");    
    
    var handle = function(obj,div,womiId,stateObj){
    	util.log("handling zw-2");
        
        var store = {
			shownAnswers:null,
			uiTitle:null,
			uiContent:null,
			uiAnswers:null,
			uiFeedback:null,
			uiFeedbackCorrect:null,
			uiFeedbackWrong:null,
			uiFeedbackHint:null,
			uiButtons:null,
			uiButtonsCheck:null,
			uiButtonsHint:null,
			uiButtonsNextExample:null,
			womiId: womiId
		};
		commonZJW.createContainers(obj, div, store);
		commonZJW.makeButtons(obj, div, store);
		commonZJW.buildAnswersList(obj, div, store, stateObj);
    };
    return {
        handle:handle
    };
});

