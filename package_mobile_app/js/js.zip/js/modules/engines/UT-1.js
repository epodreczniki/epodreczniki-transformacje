define(['jquery','modules/util'],function($,util){
    'use strict';
    util.log("ut-1 loaded");    
    var handle = function(obj,div,womiId,stateObj){
        util.log("handling ut-1");
        var clearFeedback = function(){
            $correct.css("display","none");
            $wrong.css("display","none");
            //$correct.removeAttr("style");
            //$wrong.removeAttr("style");
            $mainDiv.find("input[type='text']").removeClass("ex-correct ex-wrong");
        };
        var checkAnswer = function(){
            clearFeedback();
            var $inputs = $mainDiv.find("input[type='text']");            
            $inputs.each(function(idx,input){
                var ids = $(input).data("answersId");
                var acceptedAnswers = [];
                var somethingWrong = false;
                $.each(ids,function(iidx,iitem){
                    $.each(obj.answers,function(aidx,aitem){
                        if(iitem===aitem.id){
                            acceptedAnswers.push(aitem.content);
                        }
                    })                    
                });
                $.each(acceptedAnswers,function(aaidx,aaitem){
                    if(!$(input).hasClass("ex-correct")){
                        if(obj.config.strictMode){
                            if($(input).val()===aaitem){
                                $(input).removeClass("ex-wrong");
                                $(input).addClass("ex-correct");
                            }else{
                                $(input).addClass("ex-wrong");
                            }
                        }else{
                            if($(input).val().toUpperCase().trim()===aaitem.toUpperCase()){
                                $(input).removeClass("ex-wrong");
                                $(input).addClass("ex-correct");
                            }else{
                                $(input).addClass("ex-wrong");
                            }
                        }            
                    }
                });                
            });
            //global feedback
            if($mainDiv.find("input[type='text'].ex-wrong").length>0){
                //show negative feedback                
                $wrong.css("display","block");
                if(!!obj.description.hint){
                    $showHint.css("display","inline-block");
                }
            }else{
                //show positive feedback
                $correct.css("display","block");
            }
        };
        var clearExercise = function(){
            clearFeedback();
            var $inputs = $mainDiv.find("input[type='text']");
            $inputs.val("");
			util.setStateForWomi(womiId, null);
        };
        var $mainDiv = $(div);
        $mainDiv.addClass("momi");
        var $exDescription = $("<div></div>").addClass("ex-description");
        $mainDiv.append($exDescription);        
        var $title = $("<div></div>").addClass("ex-title").html(obj.description.title);
        $exDescription.append($title);
        var $descContent = $("<div></div>").addClass("ex-content").html(obj.description.content);
        $exDescription.append($descContent);
        var $exDiv = $("<div></div>").addClass("ex-main ut-1");
        $mainDiv.append($exDiv);
        $.each(obj.body,function(idx,item){
            if(item.preInputText){
                var $sp = $("<span></span>").html(item.preInputText);            
                $exDiv.append($sp);
            }
            var $input = $("<input type='text'></input>");
            $input.on("keydown",function(){
                clearFeedback();
            });
			$input.on("keyup",function(){
				saveState(womiId, $mainDiv);
            });
            if(item.placeholder){
                $input.attr("placeholder",item.placeholder);
            }else{
                $input.attr("placeholder","Uzupełnij...");
            }
            if(item.inputAlt){
                $input.attr("alt",item.alt);
            }
            $input.data("answersId",item.answersId);
            //determine input length
            var inputSize = $input.attr("placeholder").length;
            $.each(item.answersId,function(iidx,iitem){
                $.each(obj.answers,function(aidx,aitem){
                    if(iitem===aitem.id){
                        inputSize = Math.max(inputSize,aitem.content.length);
                    }
                });
            });
            $input.attr("size",inputSize);
            $exDiv.append($input);
            if(item.postInputText){
                var $sp = $("<span></span>").html(item.postInputText);
                $exDiv.append($sp);
            }
            if(item.lineBreak){
                $exDiv.append($("<br />"));
            }
        });
         
        var $feedback = $("<div></div>").addClass("ex-feedback");
        $mainDiv.append($feedback);
        var $correct = $("<div></div>").addClass("ex-correct").html(obj.description.correctFeedback);        
        $feedback.append($correct);
        var $wrong = $("<div></div>").addClass("ex-wrong").html(obj.description.wrongFeedback);
        $feedback.append($wrong);
        var $hint = $("<div></div>").addClass("ex-hint").html(obj.description.hint);
        $feedback.append($hint);
        
        var $exerciseButtons = $("<div></div>").addClass("ex-buttons");
        var $clear = $("<button type='button'>Wyczyść</button>").addClass("ex-btn-clear");
        $clear.on("click",function(){
            clearExercise();
        });
        $exerciseButtons.append($clear);
        var $check = $("<button type='button'>Sprawdź</button>").addClass("ex-btn-check");
        $check.on("click",function(){
            checkAnswer();
        });
        $exerciseButtons.append($check);
        var $showHint = $("<button type='button'>Wskazówka</button>").addClass("ex-btn-hint");
        $showHint.on("click",function(){
            var s = $hint.attr("style");
            if(s!==undefined && s!==false){
                $hint.removeAttr("style");
                $(this).html("Wskazówka");
            }else{
                $hint.css("display","block");
                $(this).html("Ukryj wskazówkę");
            }
        });
        $mainDiv.append($exerciseButtons);
        $exerciseButtons.append($showHint);
		
		loadState(stateObj, $mainDiv);
    };
	
	var saveState = function (womiId, $mainDiv) {
		var state = [];
		var $inputs = $mainDiv.find("input[type='text']");            
        $inputs.each(function(idx,input){
			var answer = $(input).val();
			state.push(answer);
		});
		util.setStateForWomi(womiId, state);
	};
	
	var loadState = function (state, $mainDiv) {
		if(state)
		{
			var $inputs = $mainDiv.find("input[type='text']");            
			$inputs.each(function(idx,input){
				$(input).val(state[idx]);
			});
		}
	};
    return {
        handle:handle
    };
});

