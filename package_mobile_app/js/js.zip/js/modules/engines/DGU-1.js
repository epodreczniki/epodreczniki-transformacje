﻿define(['modules/engines/enginesUtil', 'modules/tooltips', 'modules/util', 'jqtouch'], function (enginesUtil, tooltips, util) {
    'use strict';
    util.log("dgu-1 loaded");
    var handle = function (obj, div,womiId,stateObj) {
        util.log("handling dgu-1");
        var cfg = {
            $el: null,
            touch: enginesUtil.isAndroid ? true : false,
            answers: [],
            ex: obj,
            $div: $(div),
			womiId: womiId
        };
        cfg.ex.config.id = cfg.$div.uniqueId().attr("id");
        cfg.$div.removeUniqueId();

		if(stateObj) {
			cfg.touch = stateObj.shift();
		};
        generate(cfg);
		loadState(cfg, stateObj);
    };

    var generate = function (cfg) {
        //Opis zadania
        var $output = $("<div></div>", {
            "class": "ex-description"
        });
        $("<div></div>", {
            "class": "ex-title",
            text: cfg.ex.description.title
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-kind",
            text: "Aktywny tryb: " + (cfg.touch ? "Dotykowy" : "Przeciągnij i upuść"),
            on: {
                click: function (event) {
                    tooltips.showDlgModeInfo();
                }
            }
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-content"
        }).append(cfg.ex.description.content).appendTo($output);
        cfg.$div.append($output);

        //Zadanie
        $output = $("<div></div>", {
            "class": "ex-main dgu-1",
            id: cfg.ex.config.id
        });
        var $collection = $("<div></div>", {
            "class": "drop-zone"
        });
        $.each(cfg.ex.body, function (i, val) {
            var breaking = "";
            if (i > 0 && cfg.ex.body[i - 1].lineBreak) {
                breaking = "break";
            };
            var $line = $("<span></span>", {
                "class": breaking
            });
            $line.append(val.preInputText);
            $("<span></span>", {
                "class": "drop-place",
                "data-pk": val.id
            }).appendTo($line);
            $line.append(val.postInputText);
            $line.appendTo($collection);
        });
        $output.append($collection);
        $collection = $("<div></div>", {
            "class": "drag-zone"
        });
        var array = cfg.ex.answers;
        if (cfg.ex.config.randomize) {
            array = enginesUtil.shuffleArray(cfg.ex.answers);
        };
        $.each(array, function (i, val) {
            if (val.content.indexOf("<img") >= 0) {
                $("<div></div>", {
                    "class": "value picture",
                    "data-pk": val.id
                }).append(val.content).appendTo($collection);
            } else {
                $("<div></div>", {
                    "class": "value",
                    text: val.content,
                    "data-pk": val.id
                }).appendTo($collection);
            };
        });
        $output.append($collection);
        cfg.$div.append($output);

        //Rezultat
        $output = $("<div></div>", {
            "class": "ex-feedback"
        });
        $("<div></div>", {
            "class": "ex-correct",
            text: cfg.ex.description.correctFeedback
        }).appendTo($output);
        $("<div></div>", {
            "class": "ex-wrong",
            text: cfg.ex.description.wrongFeedback
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<div></div>", {
                "class": "ex-hint",
                text: cfg.ex.description.hint
            }).appendTo($output);
            cfg.$div.append($output);
        };

        //Przyciski kontrolne
        $output = $("<div></div>", {
            "class": "ex-buttons"
        });
        $("<button></button>", {
            "class": "ex-btn-clear",
            text: "Nowe zadanie",
            on: {
                click: function (event) {
                    reset(cfg);
                }
            }
        }).appendTo($output);
        $("<button></button>", {
            "class": "ex-btn-change",
            text: "Zmień tryb",
            on: {
                click: function (event) {
                    cfg.touch = !cfg.touch;
                    reset(cfg);
                }
            }
        }).appendTo($output);
        $("<button></button>", {
            "class": "ex-btn-check",
            text: "Sprawdź",
            on: {
                click: function (event) {
                    check(cfg);
                }
            }
        }).appendTo($output);
        if (cfg.ex.description.hasOwnProperty("hint") && cfg.ex.description.hint.length > 0) {
            $("<button></button>", {
                "class": "ex-btn-hint",
                text: "Pokaż wskazówkę",
                on: {
                    click: function (event) {
                        hint(cfg);
                    }
                }
            }).appendTo($output);
        };
        cfg.$div.append($output);

        if (cfg.touch) {
            cfg.$div.find(".value").bind("click", function (event) {
                event.stopPropagation();
                cfg.$div.find(".ex-main").trigger("click");
                cfg.$el = $(this);
                $(this).addClass("putted");
            });
            cfg.$div.find(".drop-place").bind("click", function () {
                if ($(this).children().length > 0) {
                    $.each($(this).children(), function (i, val) {
                        $(val).remove();
                    });
                };
                cfg.$el.removeClass("putted");
                $(this).append(cfg.$el.clone().addClass("putted"));
                cfg.$el = null;
				saveState(cfg);
            });
        } else {
            cfg.$div.find(".value").draggable({
                revert: true,
                revertDuration: 150,
                helper: "clone",
                containment: cfg.$div,
                cursor: "move",
                cursorAt: { top: 12, left: 12 },
                scroll: false,
                disable: false,
                start: function (event, ui) {
                    cfg.$div.find(".ex-main").trigger("click");
                }
            });

            cfg.$div.find(".drop-place").droppable({
                tolerance: 'pointer',
                accept: cfg.$div.find(".value"),
                activeClass: "drop-active",
                drop: function (event, ui) {
                    if ($(this).children().length > 0) {
                        $.each($(this).children(), function (i, val) {
                            $(val).remove();
                        });
                    };
                    $(this).append($(ui.draggable).clone().addClass("putted"));
					saveState(cfg);
                },
                disable: true
            });
        };
    };

    var reset = function (cfg) {
        cfg.$div.empty();
		util.setStateForWomi(cfg.womiId, null);
        generate(cfg);
    };

    var check = function (cfg) {
        var all = true;
        $.each($("#" + cfg.ex.config.id + " .drop-zone").find(".drop-place"), function (i, val) {
            if ($(val).children().length == 0) {
                all = false;
                return false;
            }
        });

        var good = true;
        if (!all) {
            good = false;
        };

        $.each(cfg.ex.body, function (correctIndex, correct) {
            var $answer = cfg.$div.find("[data-pk='" + correct.id + "']").children(":first");
            if ($answer.data("pk") == correct.answersId[0]) {
                $answer.addClass("correct");
            } else {
                $answer.addClass("wrong");
                good = false;
            };
        });

        if (good) {
            cfg.$div.find(".ex-correct").slideDown(250, "linear");
        } else {
            cfg.$div.find(".ex-wrong").slideDown(250, "linear");
            cfg.$div.find(".ex-btn-hint").fadeIn(250, "linear");
        };

        cfg.$div.find(".ex-main").bind("click", function () {
            cfg.$div.find(".value").removeClass("correct wrong", "fast", "linear");
            cfg.$div.find(".ex-correct").slideUp(250, "linear");
            cfg.$div.find(".ex-wrong").slideUp(250, "linear");

            $(this).unbind("click");
        });
       
    };

    var hint = function (cfg) {
        var $hint = cfg.$div.find(".ex-hint");

        if ($hint.css('display') == 'none') {
            $hint.slideDown(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Schowaj wskazówkę");
            });
        }
        else {
            $hint.slideUp(250, "linear", function () {
                cfg.$div.find(".ex-btn-hint").text("Pokaż wskazówkę");
            });
        };
    };
	
	var saveState = function (cfg) {
		var state = [];
		state.push(cfg.touch);
		$.each(cfg.ex.body, function (correctIndex, correct) {
            var $answer = cfg.$div.find("[data-pk='" + correct.id + "']").children(":first");
			state.push($answer.data("pk"));
		});
		util.setStateForWomi(cfg.womiId, state);
	};
	
	var loadState = function (cfg, state) {
		if(state)
		{
			$.each($("#" + cfg.ex.config.id + " .drop-zone").find(".drop-place"), function (idx, place) {
				var $el = cfg.$div.find(".drag-zone .value[data-pk='" + state[idx] + "']");
				$(place).append($el.clone().addClass("putted"));
			});
		}
	};

    return {
        handle: handle
    };
});
