var FireArgs = function (dependency, args, callback) {
	this.dependency = dependency;
	this.args = args;
	this.callback = callback;
	this.fire = function () {
		this.callback.apply(this, this.args);
	};
};