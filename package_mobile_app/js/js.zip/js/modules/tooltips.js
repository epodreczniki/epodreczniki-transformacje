define(['jquery', 'modules/util', 'modules/dispatcher', 'modules/windowutil', 'modules/fontsize'],function($, util, dispatcher, windowutil, fontsize){
    'use strict';
    
    util.log("tooltips loaded");
    
    var handle = function(tooltipsArray) {
    	util.log("tooltips handling ", tooltipsArray.length);
    	
    	tooltipsArray.each(function(index) {
			var aHref = $(this);
			aHref.click(function(e){
				e.preventDefault();
				util.log("tooltips click");
				loadTooltip(aHref.data("tooltip-file"));
				return false;
			});
		});
    };
    
    var loadTooltip = function(file) {
    	util.notifyModalWindowVisible();
    	util.loadFile(file, function(content) {
    		var rootDiv = $("body > div.reader-content");
    		var overlay = createTooltip(content, rootDiv);
    		overlay.showOverlay();
    	});
    };
    
    var createTooltip = function(content, rootDiv) {
    	
    	var overlay = $("<div>", {
    		"class": "tooltip-overlay",
    		style: "display: none"
    	});
    	overlay.appendTo($('body'));
    	
    	var container = $("<div>", {
    		"class": "tooltip-container"
    	});
    	container.appendTo(overlay);
    	
		windowutil.addCloseWindowCallback(function() {
			
			$("body > .reader-content").show();
    		var top = rootDiv.data("tooltip-top");
    		overlay.remove();
			rootDiv.removeClass("overlay-article-content");
			rootDiv.removeData("tooltip-top");
			$(document).scrollTop(top);
			util.notifyModalWindowHidden();
		});
		
    	var body = $("<div>", {
    		"class": "tooltip-container-body"
    	});
    	body.appendTo(container);
    	discoverLinks(body, content);
    	
    	var showOverlay = function() {
    		var top = $(document).scrollTop();
    		rootDiv.data("tooltip-top", top);
			rootDiv.addClass("overlay-article-content");
			$(document).scrollTop(0);
			overlay.show();
			fontsize.updateSize(overlay);
			$("body > .reader-content").hide();
    	};
    	
    	return {
    		showOverlay:showOverlay
    	};
    };
    
    var discoverLinks = function(body, content) {
    	
    	var loadModules = true;
    	if (content == '' || content == undefined) {
    		loadModules = false;
    		content = '<p style="margin: 20px">Nie znaleziono danych.</p>';
		}
		
		body.html(content);
		body.scrollTop(0);
		body.find('a.glossary-link, a.biography-link, a.event-link, a.bibliography-link, a.tooltip-link, a.concept-link').each(function(index) {
    		
    		var aHref = $(this);
			aHref.click(function(e){
				e.preventDefault();
				var file = aHref.data("tooltip-file");
				util.loadFile(file, function(data) {
					discoverLinks(body, data);
				});
			});
    	});
    	
    	dispatcher.loadModulesInsideDiv(body, ['tooltips', 'notifyEverythingWasLoaded', 'wpswipe']);
    };
    
    var showDlgModeInfo = function() {
    	loadTooltip('tooltips/showDlgModeInfo.html');
    };
    
    return {
    	handle:handle,
    	showDlgModeInfo:showDlgModeInfo
    }
});
