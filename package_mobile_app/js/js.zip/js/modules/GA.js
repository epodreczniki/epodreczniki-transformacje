define(['jquery','modules/util','iscrollzoom', 'modules/windowutil','modules/mediaplayer'],function($,util,IScroll, windowutil,mediaplayer){
    'use strict';
    util.log("GA loaded");
    var overlayControlsShown = true;
    var overlayShown = false;
    var scrollPos;
    var imgScroll;
    var currImgs;
    var oCurrImg = 0;
    
    var $overlay = $("<div />",{"class":"gc-overlay note-ignore"}).css("display","none");
    //overlay controls
    var $overlayDesc = $("<div />",{"class":"gco-desc"});
    var $overlayPrev = $("<button />",{"class":"gco-prev gco-btn"});
    var $overlayNext = $("<button />",{"class":"gco-next gco-btn"});
    var $overlayImgContainer = $("<div />",{"class":"gco-container","style":"position:absolute;top:0px;bottom:0px;left:0px;right:0px;overflow:scroll"});
    var $overlayImg = $("<img />");
    if(!util.isAndroid()){
        $overlayImg.addClass("gco-img");
    }
    $overlayImgContainer.append($overlayImg);
    $overlay.append($overlayDesc).append($overlayPrev).append($overlayNext).append($overlayImgContainer);        
    $("body").append($overlay);
    if(util.isAndroid()){
        util.log('test null '+$overlayImgContainer.get(0));
        imgScroll = new IScroll($overlayImgContainer.get(0),{
             zoom:true,
             zoomMin:0.2,
             zoomMax:3,
             zoomStart:1,
             scrollX:true,
             scrollY:true,
             click:true,
        });
    $overlayImg.on("load",function(){
        var initScale = parseFloat($overlayImgContainer.width())/parseFloat($overlayImg.width());
        imgScroll.refresh();
        imgScroll.zoom(initScale,0,0);
        });
    }
    
    $overlay.on("click",function(){
        switchOverlayControls();
    });
    
    $overlayPrev.on("click",function(ev){
        ev.stopImmediatePropagation();
        showImgMo(oCurrImg>0?oCurrImg-1:currImgs.length-1);
    });
    
    $overlayNext.on("click",function(ev){
        ev.stopImmediatePropagation();
        showImgMo(oCurrImg<currImgs.length-1?oCurrImg+1:0);
    });        

    var hideOverlay = function(){
        util.log('hide');
        $overlay.css("display","none");
        $overlayImgContainer.find(".media-player").remove();
        $("body > .reader-content").css("display","block");
        $("body,html").scrollTop(scrollPos);
        overlayShown = false;
        
        // fires from tooltips
        if ($("body > .tooltip-overlay").length > 0) {
        	$("body > .tooltip-overlay").css("z-index", 1000);
        	$("body > .gc-overlay").css("z-index", 0);
        }
        else {
        	util.notifyModalWindowHidden();
        }
    };

    var showOverlay = function(){
        scrollPos = Math.max($("body, html").scrollTop(),$("body").scrollTop());
        //$("body").append($overlay);
        $overlay.css("display","block");
        overlayShown = true;            
        overlayControlsShown = true;
        showOverlayControls(true);
        $("body > .reader-content").css("display","none");
        util.log("pos: "+scrollPos);
        
		// close handler
		windowutil.addCloseWindowCallback(function() {
			hideOverlay();
		});
		
        // fires from tooltips
        if ($("body > .tooltip-overlay").length > 0) {
        	$("body > .tooltip-overlay").css("z-index", 0);
        	$("body > .gc-overlay").css("z-index", 1000);
        }
        else {
        	util.notifyModalWindowVisible();
        }
    };

    var showImgMo = function(idx,imgs){
        if(imgs!==undefined && currImgs!==imgs){
            util.log('new images');
            currImgs = imgs;
        }
        if(!overlayShown){
            showOverlay();
        }
        oCurrImg = idx;
        var cim = currImgs[idx];
        $overlayImgContainer.find(".media-player").remove();
        if(!!cim.div){
            $overlayImg.css("display","none"); 
            $overlayImgContainer.append(cim.div);
            mediaplayer.handle($(cim.div));
        }else{
            $overlayImg.css("display","inline"); 
            $overlayImg.attr("src",currImgs[idx].src);
        }
        $overlayDesc.html(currImgs[idx].caption.label+" "+currImgs[idx].caption.numbering+" "+currImgs[idx].caption.title);
    };

    var switchOverlayControls = function(){
        overlayControlsShown=!overlayControlsShown;
        showOverlayControls(overlayControlsShown);
    };  
        
    var showOverlayControls = function(show){      
        $overlay.find(".gco-btn , .gco-desc").css("visibility",show?"visible":"hidden");
    };

    var handle = function(div,miniaturesOnly,gW,gH){       
        util.log("handling GA");
        
        var imgs = [];       
        var currImg = 0; 
        var showImg = function(idx){            
            if(idx>-1&&idx<imgs.length){
                var captionStr = "";
                if(!!imgs[idx].caption.label){
                    captionStr+=imgs[idx].caption.label;
                }
                if(!!imgs[idx].caption.numbering){
                    captionStr+=" "+imgs[idx].caption.numbering;
                    captionStr.trim();
                }
                if(!!imgs[idx].caption.title){
                    captionStr+=" "+imgs[idx].caption.title;
                    captionStr.trim();
                }
                $caption.html(captionStr);
                $asoText.text(imgs[idx].aso);
                $tr.find("img.shown").removeClass("shown");
                currImg = idx;            
                $tr.find("img").eq(idx).addClass("shown");
                var cim = imgs[idx];
                //remove media-player div is present
                $stage.find(".media-player").remove();
                if(!!cim.div){
                    //this is video     
                    $stage.css("background-image","none");
                    $stage.append(cim.div);
                    console.log("setting height: "+($stage.width()/cim.ratio));
                    //$stage.css("height",($stage.width()/cim.ratio)+"px");
                    mediaplayer.handle($(cim.div));
                    $zoomBtn.css("display","none");
                }else{
                    $stage.css("background-image","url('"+imgs[idx].src+"')");
                    $stage.data("imgsrc",imgs[idx].src);
                    if(util.isAndroid()){
                        $zoomBtn.css("display","inline-block");
                    }
                    setMaxHeight();
                }
            }
        };

        var setMaxHeight = function(){            
            var thumbHeight = Math.min(60,$(window).height()/4);
            var thumbWidth = 3*thumbHeight/2;
            $tr.find("td").css("width",thumbWidth+"px").css("height",thumbHeight+"px");
            $thumbsTable.css("width",imgs.length*thumbWidth+"px");
            var w = $stage.width();
            //var h = Math.min($(window).height()-thumbHeight-50,2*w/3);
            var h = 0.5625*w;
            //$stage.css("height",($(window).height()-thumbHeight-50)+"px");           
            $stage.css("height",h+"px");           
        };
    
        /*var checkSrc = function(src){
            var ok = false;
            $.ajax(src,{async:false}).done(function(){
                ok = true;
            });
            return ok;
        };*/
    
        var $mainDiv = $(div);
        $mainDiv.find(".womi-gallery-contents").css("display","none");
        var $womiContainers = $mainDiv.find("div.womi-container");
        var reg = /(\.[a-zA-Z]{3,4})$/;
        $womiContainers.each(function(){
            var img = {};
            var $vid = $(this).find("div.media-player");
            if($vid.length>0){
                console.log("video detected");
                console.log($vid.data("poster"));
            }
            var $img = $(this).find("img");
            if($vid.length>0&&$img.length==0){
                //this is a video
                img.div = $vid.get(0);
                img.thumbnail = $vid.data("poster");
                img.ratio = $vid.data("aspectratio");
            }else{
                //this is an image
                img.src = $img.data("src")?$img.data("src"):$img.attr("src");
                if(img.src.match(reg)){
                    img.thumbnail = img.src.replace(reg,"_thumbnail$1");
                }
            }
            img.caption = {};
            var label = $(this).find("span.womi-label").html();            
            img.caption.label=!!label?label:"";
            var numbering = $(this).find("span.womi-numbering").html();
            img.caption.numbering=!!numbering?numbering:"";
            var title = $(this).find("span.womi-title").html();
            img.caption.title=!!title?title:"";
            img.aso = $(this).find(".womi-associated-text").text();
            imgs.push(img);
        });
        
        var $galleryContainer = $("<div />",{"class":"ga-container note-ignore"});
        $mainDiv.append($galleryContainer);
        var $caption = $("<div />",{"class":"ga-caption"});
        $galleryContainer.append($caption);
        var $thumbsDiv = $("<div />",{"class":"ga-thumbs"});    
        $galleryContainer.append($thumbsDiv);
        var $stage = $("<div />",{"class":"ga-stage"});        
        if(miniaturesOnly){
            $stage.css("display","none");
            $caption.css("display","none");
        }
        $galleryContainer.append($stage);        
        if(util.isAndroid()){
            var $zoomBtn = $("<div />",{"class":"ga-zoom-img"});
            $stage.append($zoomBtn);
            $zoomBtn.on("click",function(ev){
                ev.stopImmediatePropagation();
                showImgMo(currImg,imgs);
            });
        }
        var $asoText = $("<div />",{"class":"ga-aso-text"});
        $galleryContainer.append($asoText);
        var $thumbsTable = $("<table />",{"class":"ga-table"});
        $thumbsDiv.append($thumbsTable);
        if(!!gW && !! gH){
            var $currTr;
            $.each(imgs,function(idx,item){
                if(idx%gW==0){
                    $currTr = $("<tr />");
                    $thumbsTable.append($currTr);
                }
                var $td = $("<td />");
                $currTr.append($td);
                var $img = $("<img />",{"src":item.thumbnail?item.thumbnail:item.src});
                $td.append($img);
                $td.on("click",function(){
                    showImgMo(idx,imgs);
                });
            });
        }else{
            var $tr = $("<tr />");
            $thumbsTable.append($tr);
            $.each(imgs,function(idx,item){
                var $td = $("<td />");
                $tr.append($td);
                var $img = $("<img />",{"src":item.thumbnail?item.thumbnail:item.src});
                if(miniaturesOnly){
                    $img.addClass("shown");
                }
                $td.append($img);
                $td.on("click",function(){
                    if(miniaturesOnly){
                        showImgMo(idx,imgs);
                    }else{
                        showImg(idx);
                    }
                });
                util.log(item);
            });
            if(!miniaturesOnly){
                showImg(0);
            }
        }
        $(window).on("resize",function(){           
            if($tr){
                //check if $tr exists (race condition on Win8)
                setMaxHeight();
                if(!miniaturesOnly){
                    showImg(currImg);
                }
            }
        });
        $stage.on("click",function(){
            if(util.isAndroid()){
                //TODO 
                //var d = $zoomBtn.css("display");                
                //$zoomBtn.css("display",d==="none"?"inline-block":"none"); 
            }
        });
                
    };
    return {
        handle:handle
    }
});
