define(['jquery', 'modules/util'],function($, util){
    'use strict';
    
    util.log("pagelinks loaded");
    
    var handle = function() {
    	
    	var links = $("a.pagina-link");
    	
    	util.log("pagelinks handling", links.length);
    	
    	links.each(function(index) {
			var aHref = $(this);
			aHref.click(function(e) {
				e.preventDefault();
				
				var items = aHref.attr("href").split("#");
				if (items.length == 2) {
					util.openPageLink(items[0], "#" + items[1]);
				}
				else {
					util.openPageLink(items[0], null);
				}
			});
		});
    };
    
    window.jumpToAnchor = function (anchor) {
		window.location.href = anchor;
	};
    
    return {
    	handle:handle
    }
});
