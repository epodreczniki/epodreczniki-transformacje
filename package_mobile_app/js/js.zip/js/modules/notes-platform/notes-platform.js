define(['exports','notes-core','modules/util'],function(exports,core,util){
    "use strict";
    
    //PUBLIC
    var handleNoteClick = function(noteId){
        if(util.isAndroid()){
            Android.handleNoteClick(noteId);
        }else if(util.isIOS()){
        	if (window.iosProxy && window.iosProxy.handleNoteClick) {
				iosProxy.handleNoteClick(noteId);
			}
        }else if(util.isWin8()){
            try {                
                var payload = "handleNoteClick;" + noteId;
                window.external.notify(payload);
            }
            catch (e) {
                log("error handleNoteClick(");
            }
        }else if(util.isWP8()){
        //TODO
        }
    };

    var showNoteCreate = function(noteText,noteLocation,notesToMerge){
        if(util.isAndroid()){
            Android.showNoteCreate(noteText,noteLocation,notesToMerge);
        //TODO
        }else if(util.isIOS()){
        	if (window.iosProxy && window.iosProxy.showNoteCreate) {
				iosProxy.showNoteCreate(noteText,noteLocation,notesToMerge);
			}
        }else if(util.isWin8()){
            try {
                var Note = new Object();
                Note.Text = noteText;
                Note.Location = JSON.parse(noteLocation);
                if(notesToMerge === undefined)
                    Note.ToMarge = "";
                else
                    Note.ToMarge = JSON.parse(notesToMerge);

                var payload = "showNoteCreate;" + JSON.stringify(Note);
                window.external.notify(payload);
            }
            catch (e) {
                log("error showNoteCreate(");
            }

        } else if (util.isWP8()) {
            var note = {
                text: noteText,
                location: JSON.parse(noteLocation),
                toMerge: notesToMerge === undefined ? "" : JSON.parse(notesToMerge)
            };
            window.external.notify("showNoteCreate;" + JSON.stringify(note));
        }
    };

    var showMessage = function(message){
        if(util.isAndroid()){
            Android.showMessage(message);
        }else if(util.isIOS()){
        	if (window.iosProxy && window.iosProxy.showMessage) {
				iosProxy.showMessage(message);
			}
        }else if(util.isWin8()){
            try {                
                var payload = "showMessage;" + message;
                window.external.notify(payload);
            }
            catch (e) {
                log("error showMessage");
            }
        }else if(util.isWP8()){
        //TODO
        }
    };

    var getNoteByLocalNoteId = function(noteId){
        if(util.isAndroid()){
            return Android.getNoteByLocalNoteId(noteId);
        }else if(util.isIOS()){
        	if (window.iosProxy && window.iosProxy.getNoteByLocalNoteId) {
				return iosProxy.getNoteByLocalNoteId(noteId);
			}
			return null
        }else if(util.isWin8()){
        //TODO
        }else if(util.isWP8()){
        //TODO
        }
    };

    var getNotesForCurrentView = function(){
        if(util.isAndroid()){
            //TODO converto to objects?
            return Android.getNotesForCurrentView();
        }else if(util.isIOS()){
        	if (window.iosProxy && window.iosProxy.getNotesForCurrentView) {
				return iosProxy.getNotesForCurrentView();
			}
			return []
        }else if(util.isWin8()){
            window.external.notify("getNotesForCurrentView");
            var notes = [];
            return notes;
        }else if(util.isWP8()){
            window.external.notify("getNotesForCurrentView");
        }
    };

    exports.handleNoteClick=handleNoteClick;
    exports.showNoteCreate=showNoteCreate;
    exports.showMessage=showMessage;
    exports.getNoteById=getNoteByLocalNoteId;
    exports.getNotesForCurrentView=getNotesForCurrentView;
});
