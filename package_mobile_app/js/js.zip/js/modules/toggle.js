define(['jquery'],function($){
    return {
        solution:function(target,source){
            var solution = $("#"+target+" .solution");
            var $solutionToggles = $("#"+target+" .solution-toggles");
            if($solutionToggles.size()>source-1){
                var solutiontoggle = $($solutionToggles.get(source-1)).find(".solution-toggle");
                if($(solution[source-1]).css("display") == "none") {        
                    $(solution[source-1]).css("display", "block");
                    $(solutiontoggle[0]).css("display", "none");
                    $(solutiontoggle[1]).css("display", "inline");
                } else {
                    $(solution[source-1]).css("display", "none");
                    $(solutiontoggle[0]).css("display", "inline");
                    $(solutiontoggle[1]).css("display", "none");
                }
            }
        },
        commentary:function(target,source){
            var commentary = $("#"+target+" .commentary");
            var commentaryToggles = $("#"+target+" .commentary-toggles");
            if(commentaryToggles.size()>source-1){
                var commentaryToggle = $($(commentaryToggles).get(source-1)).find(".commentary-toggle");
                if($(commentary[source-1]).css("display") == "none") {
                    $(commentary[source-1]).css("display", "block");
                    $(commentaryToggle[0]).css("display","none");
                    $(commentaryToggle[1]).css("display","inline");
                }else{
                    $(commentary[source-1]).css("display", "none");
                    $(commentaryToggle[0]).css("display","inline");
                    $(commentaryToggle[1]).css("display","none");
                }
            }
        },
        authorLicense:function(id_div, id_btn, value_btn_show, value_btn_hidei){
            var div = $("#"+id_div);
            if(div.css("display") == "none") {
                div.css("display", "block");
                $("#"+id_btn).attr("value", value_btn_hide);
            } else {
                div.css("display", "none");
                $("#"+id_btn).attr("value", value_btn_show);
            }
        }
    };
});
