define(['jquery', 'modules/util', 'modules/dispatcher', 'modules/windowutil'],function($, util, dispatcher, windowutil){
    'use strict';
    
    util.log("womiloader loaded");
    
    var handle = function(engineName, url, div) {
    	
		var $div = $(div);
		var placeholderImage = $div.find(".play-button-interactive-exercise");
		
		if (engineName == "womi_exercise_engine") {
			placeholderImage.click(function () {
			    
				var womiDiv = $("<div>", {
					"class": "womi-content",
					style: "margin:0px; padding:0px; overflow:hidden"
				});
				var rootDiv = $("body > div.reader-content");
	    		var top = $(document).scrollTop();
	    		rootDiv.data("tooltip-top", top);
				
				var clonedDiv = $(div).clone();
				clonedDiv.empty();
				womiDiv.append(clonedDiv);
	    		dispatcher.loadOnDemandModulesInsideDiv(womiDiv, ['notifyEverythingWasLoaded']);
				
				util.notifyModalWindowVisible();
				
				$("body > .reader-content").hide();
				$("body").append(womiDiv);
				
				windowutil.addCloseWindowCallback(function() {
					var top = rootDiv.data("tooltip-top");
					$("body > .womi-content").remove();
					$("body > .reader-content").show();
					$(document).scrollTop(top);
					util.notifyModalWindowHidden();
				});
				
				return false;
			});
		}
		else if (engineName == "geogebra") {
			placeholderImage.click(function () {
			    util.openExternalWindow("content/" + url, true);
				return false;
			});
		}
		else if (engineName == "custom_womi") {
			placeholderImage.click(function () {
			    util.openExternalWindow("content/" + url, false);
				
				return false;
			});
		}
		else if (engineName == "autonomic_womi") {
			placeholderImage.click(function () {
			    util.openExternalWindow("content/" + url, false);
				
				return false;
			});
		}
		else if (engineName == "processingjs_animation") {
			placeholderImage.click(function () {
				util.openExternalWindow("content/" + url, false);
			});
		}
		else if (engineName == "custom_logic_exercise_womi") {
			
			placeholderImage.click(function () {
			    util.openExternalWindow("content/" + url, false);
				return false;
			});
		}
		else if (engineName == "custom_logic_exercise_womi_run") {
			require(['../' + url], function(womi) {
				
				var womiObj = new womi();
				womiObj.start($div)
			});
		}
		else {
			$div.text("Nieznany silnik: " + engineName);
		}
    };
    
    return {
    	handle:handle
    }
});
