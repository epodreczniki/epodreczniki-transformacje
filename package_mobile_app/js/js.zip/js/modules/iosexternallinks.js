define(['jquery', 'modules/util'],function($, util){
    'use strict';
    
    util.log("iosexternallinks loaded");
    
    var handle = function(iosLinks) {
    	
    	util.log("iosexternallinks handling", iosLinks.length);
    	
    	iosLinks.each(function(index) {
			var aHref = $(this);
			aHref.click(function(e) {
				if (window.iosProxy != undefined && window.iosProxy.openExternalLink != undefined) {
					e.preventDefault();
					window.iosProxy.openExternalLink(aHref.attr("href"));
				}
			});
		});
    };
    
    return {
    	handle:handle
    }
});
