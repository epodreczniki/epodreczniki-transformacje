define(['jquery', 'modules/util'],function($, util){
    'use strict';
    
    var handle = function(mediaplayerArray) {
    	require(["dropup", "jquery.jplayer.dev", "player.ext"], function (dropup, jplayer, player) {
			mediaplayerArray.each(function (i, obj) {
			    player.createPlayer(obj, function(url, container) {
					return util.canPlayVideo(url, container, player);
			    }, 'static', function (container, full) {
			        return util.fullScreenCallback(container, full);
			    });
			});
			$(window).on("resize orientationchange", function () {
				player.updatePlayerSize();
			});
		});
    };
    
    return {
    	handle:handle
    }
});
