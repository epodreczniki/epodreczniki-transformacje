define(['jquery', 'modules/util', 'base64'],function($, util, base64){
    'use strict';
    
    util.log("open questions loaded");
    
    var handle = function(openquestionsArray) {
    	util.log("open questions handling ", openquestionsArray.length);
    	
		var idsArray = [];
		
    	openquestionsArray.each(function(index) {
			var $div = $(this);
			var openQuestionID = $div.attr("id");
			idsArray.push(openQuestionID);
			
			// event
			$div.find(".work-area").focusout(function() {
				
				var base64str = base64.encode($(this).val());
				util.setStateForOpenQuestion(openQuestionID, base64str);
			});
		});
		
		util.getStateForOpenQuestions(idsArray);
    };
    
    return {
    	handle:handle
    }
});
