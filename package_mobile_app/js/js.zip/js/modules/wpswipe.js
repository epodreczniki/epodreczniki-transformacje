define(['jquerymobile', 'modules/util'],function(jmobile, util){
    'use strict';
    
	util.log("wpswipe loaded");
    
	var handle = function(){
        
		util.log(jmobile.version);
		
    };
    return {
        handle:handle
    };

});