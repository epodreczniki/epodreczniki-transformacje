define(['jquery', 'modules/util'],function($, util){
    'use strict';
    
    util.log("windowutil loaded");
    
	var closeCallbacks = new Array();
	
    window.closeWindow = function() {
		
		var callbackFun = closeCallbacks.pop();
		
		if (callbackFun != undefined) {
			util.log("closeWindow calling");
			callbackFun();
		}
		else {
			util.log("closeWindow nothing to call");
		}
    };
	
	var addCloseWindowCallback = function(callbackFun) {
		util.log("addCloseWindowCallback");
		
		closeCallbacks.push(callbackFun);
	};
    
	var runCloseWindowCallback = function() {
		window.closeWindow();
	};
	
    return {
    	addCloseWindowCallback:addCloseWindowCallback,
		runCloseWindowCallback:runCloseWindowCallback
    }
});
