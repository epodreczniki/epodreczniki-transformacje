define(['jquery','iscrollzoom', 'modules/util','modules/windowutil'],function($,IScroll,util,windowutil){
    'use strict';
    var imgScroll;
    var scrollPos;
    var closeImg = function(){
            $(".reader-content").css("display","block");
            $("body").scrollTop(scrollPos);
            $("#big_image_container").css("display", "none");
            util.notifyModalWindowHidden();
    };
    $(document).ready(function(){
        //initialize the component
        $("div.womi-details").addClass("andy");
        $("#big_image_container").css("position","absolute").css("width","100%").css("height","100%").css("top","0px").css("bottom","0px").css("left","0px").css("right","0px").css("margin","0px");
        $("#controls").css("position","absolute").css("top","0px").css("right","0px");
        var $imgContainer = $("#img-container");
        if($imgContainer.length<1){
            //this should not happen in target environment
            util.log('creating dummy container');
            $imgContainer = $("<div />",{"id":"img-container","style":"display:none"}).append($("<div />"));
            $("body").append($imgContainer);
        }
        imgScroll = new IScroll($imgContainer.get(0),{
            zoom:true,
            zoomMin:0.2,
            zoomMax:3,
            zoomStart:1,
            scrollX:true,
            scrollY:true,
            click:true,
        });
        $("#img_bigger").on("load",function(){
            $("#big_image_container").css("display","block");
            $(".reader-content").css("display","none");
            //calculate initial scale
            var initScale = parseFloat($("#img-container").width())/parseFloat($("#img_bigger").width());
            imgScroll.refresh();
            imgScroll.zoom(initScale,0,0);            
        });        
        $("#display_btn").css("display","none");
        /*$("#img-container").bind("click",function(){
            var ctrls = $("#controls");
            if(ctrls.hasClass("hidden")){
                ctrls.removeClass("hidden");
            }else{
                ctrls.addClass("hidden");
            }
        });*/
        $("#close_btn").css("display","none").removeAttr("onclick").on('click',closeImg);
    });

    return {
        openImage:function(ev,source,id){
            ev.preventDefault();
            windowutil.addCloseWindowCallback(function(){
                closeImg();
            });
            util.notifyModalWindowVisible();
            scrollPos = $("body").scrollTop();
            var image = $("#img_bigger");
            if(image.attr("src")===source){
                $("#big_image_container").css("display", "block");
                $(".reader-content").css("display","none");
                // jezeli ten sam obrazek wchodzi ponownie to nie resetujemy zoomu
                // tak ma byc
                imgScroll.refresh();
            }else{
                image.attr("src",source);
            }
        }
    };
});
