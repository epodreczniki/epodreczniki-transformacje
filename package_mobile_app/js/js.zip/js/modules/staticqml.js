define(['jquery','jqtouch'],function($){
    'use strict';
    var orderExercises = [];
    var wrappers = {};
    var loadStaticExercises = function(){
        var stat = $(".exercise:not(.dynamic)");
        $.each(stat,function(idx,item){
            var id = $(item).find(".qmlitem").attr("id");
            //console.log("id: "+id);
            if(id!==undefined){
                wrappers[id]=$("#"+id);
                wrappers[id].find(".button.ex_hint").css("display","none");
                if(getType(item)==="ordered-response"){
                    orderExercises.push($(item).find(".qmlitem").attr("id"));
                    var frm = wrappers[id].find('form');
                    frm.find(".answer>input").css("display","none");
                    frm.sortable({items:".answer"});
                }
            }
        });
    };

    var showAnswer = function(ex_id,form_id,correct_answers){
        //reset feedback 
        var hidden_hints = wrappers[ex_id].find(".hint").filter(function(){
            return $(this).css("display") === "none";
        });
        var hint_btn = wrappers[ex_id].find(".button.ex_hint");
        wrappers[ex_id].find(".feedback").css("display","none");
        var correctIds = correct_answers.split(",");
        if($.inArray(ex_id,orderExercises)>-1){
            var diffs = 0;
            $.each(wrappers[ex_id].find(".answer>input"),function(idx,item){
                var id = $(item).attr("id").replace(new RegExp("-id$","gm"),"");
                diffs+=correctIds[idx]===id?0:1;
            });
            if(diffs===0){
                wrappers[ex_id].find(".feedback.correct").css("display","block");
                wrappers[ex_id].find(".hint").css("display","none");
                hint_btn.css("display","none");
            }else{
                wrappers[ex_id].find(".feedback.incorrect").css("display","block");
                if(hidden_hints.size()>0){
                    hint_btn.css("display","block");
                }
            }
        }else{
            var checked = wrappers[ex_id].find("input:checked");
            var checkedIds = [];
            $.each(checked,function(idx,item){
                checkedIds.push($(item).attr("id").replace(new RegExp("-id$","gm"),""));
            });
            if($(correctIds).not(checkedIds).length == 0 && $(checkedIds).not(correctIds).length == 0){
                wrappers[ex_id].find(".feedback.correct").css("display","block");
                // hide hints and hint button
                wrappers[ex_id].find(".hint").css("display","none");
                hint_btn.css("display","none");
            }else{
                wrappers[ex_id].find(".feedback.incorrect").css("display","block");
                if(hidden_hints.size()>0){
                    hint_btn.css("display","blocK");
                }
            }
        }
        wrappers[ex_id].find(".feedback:not(.correct):not(.incorrect)").css("display","block");
    };

    var showHint = function(ex_id){
        var hint_btn = wrappers[ex_id].find(".button.ex_hint");
        var hidden_hints = wrappers[ex_id].find(".hint").filter(function(){
            return $(this).css("display") === "none";
        });
        if(hidden_hints.size()>0){
            $(hidden_hints[0]).css("display","block");
            if(hidden_hints.size()==1){
                hint_btn.css("display","none");
            }else{
                hint_btn.attr("value","Następna wskazówka");
            }
        }
    };

    var addMe = function(){
        //nada
    };

    var getType = function(ex_div){
        return $(ex_div).find("form").attr("id").split("_")[0];
    };

    $(document).ready(function(){
        loadStaticExercises();
    });
    return {
        addMe:addMe,
        showHint:showHint,
        showAnswer:showAnswer
    };
});
