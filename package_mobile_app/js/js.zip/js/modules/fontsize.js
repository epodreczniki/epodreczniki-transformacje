define(['jquery','modules/util'],function($,util){
    'use strict';

    var readFontSize = function(){
        var res = parseInt(window.Android?Android.getFontSize():localStorage.getItem("epo-font-size"));
        return isNaN(res)?100:res;
    };

    var storeFontSize = function(newSize){
        if(window.Android){
            Android.storeFontSize(newSize);
        }else{
            localStorage.setItem("epo-font-size",newSize);
        } 
    };
    
    var notifyButtonsState = function(fontSize){
        if(!fontSize){
            fontSize = readFontSize();
        }
        util.notifyFontButtonsEnabled(fontSize!=100,fontSize!=150);    
    };
    
    var decreaseSize = function(){
        var fontSize = readFontSize();
        if(fontSize>100){
            fontSize-=25;
            storeFontSize(fontSize); 
            notifyButtonsState(fontSize);
            applySize();
        }
    };

    var increaseSize = function(){
        var fontSize = readFontSize();
        if(fontSize<150){
            fontSize+=25;
            storeFontSize(fontSize);           
            notifyButtonsState(fontSize);
            applySize();
        }
    };

    var applySize = function(element){
        $(document).ready(function(){
            var fontSize = readFontSize();
            var $element = element?(element.jquery?element:$(element)):$(".reader-content");
            var $images = $element.find("div.img>img"); 
            $element.css("font-size",fontSize+"%"); 
            var scale = parseFloat(fontSize)/parseFloat(100);
            $images.each(function(){
                var $t = $(this);
                if(!$t.data("original-width")){
                    $t.data("original-width",$t.width());
                }
                if(!$t.data("original-height")){
                    $t.data("original-height",$t.height());
                }
                $t.parent().css("width",$t.data("original-width")*scale); 
                $t.parent().css("height",$t.data("original-height")*scale);
                $t.css("width",$t.data("original-width")*scale);
                $t.css("height",$t.data("original-height")*scale);
                $t.css("vertical-align","top");
            });
        });
    };
    
    applySize();
    notifyButtonsState();

    return {
        decreaseSize:decreaseSize,
        increaseSize:increaseSize,
        updateSize:applySize    
    };    
});
