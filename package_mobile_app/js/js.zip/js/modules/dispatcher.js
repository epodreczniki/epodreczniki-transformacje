define(['jquery',
		'underscore',
        'modules/util',
        'modules/fireargs'
       ],function($, _, util){
    'use strict';
    
	var onDemandModules = [
    	{
    		name: "exercises",
    		dependency: [],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
				var thisModule = this;
    			var $exercises = $div.find("div.standard-interactive-object");
				$exercises.each(function(){
					var jsonPath = $(this).data("object-src");
					var engineName = $(this).data("object-engine-name");
					if (engineName == undefined || jsonPath == undefined) {
						util.log("error: no engine found");
						return;
					}
					
					var _this = this;
					var localDependency = [ 'modules/engines/' + engineName ];
					var localArgs = [ jsonPath, _this, localDependency ];
					registerCallback(new FireArgs(localDependency, localArgs, thisModule.callback));
				});
    		},
    		callback: function(jsonPath, div, localDependency) {
        		util.loadJSON(jsonPath, function(jsonData) {
					if (jsonData !== undefined) {
						var womiId = $(div).data('womi-id');
						
						util.getStateForWomi(womiId, function(jsonObj) {
							console.log(jsonObj);
							var engine = require(localDependency[0]);
        					engine.handle(jsonData, div, womiId, jsonObj);
						});
					}
				});
        	}
    	}
	];
	
    var pageModules = [
		{
    		name: "womiloader",
    		dependency: ['modules/womiloader'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
				var thisModule = this;
    			var $exercises = $div.find("div.standard-interactive-object");
				$exercises.each(function(){
					var jsonPath = $(this).data("object-src");
					var object_engine = $(this).data("object-engine");
					var localArgs = [ object_engine, jsonPath, this ];
					registerCallback(new FireArgs(thisModule.dependency, localArgs, thisModule.callback));
				});
    		},
    		callback: function(engineName, url, div) {
        		var engine = require(this.dependency[0]);
        		engine.handle(engineName, url, div);
        	}
		},
    	{
    		name: "gallery",
    		dependency: ['modules/GA'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			var thisModule = this;
    			var $galleryDivs = $div.find("div.womi-gallery");
				$galleryDivs.each(function(){
					var w = $(this).data("viewWidth");
					var h = $(this).data("viewHeight");
					var minOnly = $(this).data("miniaturesOnly");
					
					var localArgs = [];
					if (w || h) {
						util.log("type B");
						localArgs = [ this, true, w, h ];
					} else {
						util.log(this);
						util.log(!!minOnly);
						localArgs = [ this, !!minOnly ];
					}
					registerCallback(new FireArgs(thisModule.dependency, localArgs, thisModule.callback));
				});
    		},
    		callback: function(div, miniaturesOnly, w, h) {
            	var galleryA = require(this.dependency[0]);
            	galleryA.handle(div, miniaturesOnly, w, h);
        	}
    	},
    	{
    		name: "iosexternallinks",
    		dependency: ['modules/iosexternallinks'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude) && util.isIOS();
    		},
    		init: function ($div, registerCallback) {
    			var iosLinks = $("a[target='_blank']");
				if (iosLinks.length > 0) {
					var localArgs = [ iosLinks ];
					registerCallback(new FireArgs(this.dependency, localArgs, this.callback));
				}
    		},
    		callback: function(iosLinks) {
            	var links = require(this.dependency[0]);
            	links.handle(iosLinks);
        	}
    	},
    	{
    		name: "pagelinks",
    		dependency: ['modules/pagelinks'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			registerCallback(new FireArgs(this.dependency, [], this.callback));
    		},
    		callback: function() {
            	var links = require(this.dependency[0]);
            	links.handle();
        	}
    	},
    	{
    		name: "androidimg",
    		dependency: ['modules/androidimg'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude) && util.isAndroid();
    		},
    		init: function ($div, registerCallback) {
    			registerCallback(new FireArgs(this.dependency, [], this.callback));
    		},
    		callback: function() {
    			var engine = require(this.dependency[0]);
            	window.openImage = engine.openImage;
				//window.closeImage = engine.closeImage;
        	}
    	},
    	{
    		name: "media-player",
    		dependency: ['modules/mediaplayer'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			var mediaplayer = $div.find(".media-player");
				if (mediaplayer.length > 0) {
					var localArgs = [ mediaplayer ];
					registerCallback(new FireArgs(this.dependency, localArgs, this.callback));
				}
    		},
    		callback: function(mediaplayerArray) {
    			var engine = require(this.dependency[0]);
            	engine.handle(mediaplayerArray);
        	}
    	},
    	{
    		name: "foldables",
    		dependency: ['modules/foldables'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			var $fc = $div.find(".foldable");
				if ($fc.length > 0) {
					var localArgs = [ $fc ];
					registerCallback(new FireArgs(this.dependency, localArgs, this.callback));
				}
    		},
    		callback: function($fc) {
    			var engine = require(this.dependency[0]);
            	engine.handle($fc);
        	}
    	},
		{
    		name: "wpswipe",
    		dependency: ['modules/wpswipe'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude) && util.isWP8();
    		},
    		init: function ($div, registerCallback) {
    			registerCallback(new FireArgs(this.dependency, [], this.callback));
    		},
    		callback: function() {
    			var engine = require(this.dependency[0]);
            	engine.handle();
        	}
		},
    	{
    		name: "tooltips",
    		dependency: ['modules/tooltips'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			var tooltips = $div.find("a.glossary-link, a.biography-link, a.event-link, a.bibliography-link, a.tooltip-link, a.concept-link");
				if (tooltips.length > 0) {
					var localArgs = [ tooltips ];
					registerCallback(new FireArgs(this.dependency, localArgs, this.callback));
				}
    		},
    		callback: function(tooltipsArray) {
    			var engine = require(this.dependency[0]);
            	engine.handle(tooltipsArray);
        	}
    	},
		{
    		name: "openquestions",
    		dependency: ['modules/openquestions'],
    		shouldLoad: function ($div, exclude) {
    			return shouldLoadModule(this.name, exclude);
    		},
    		init: function ($div, registerCallback) {
    			var openquestions = $div.find("div.open-question");
				if (openquestions.length > 0) {
					var localArgs = [ openquestions ];
					registerCallback(new FireArgs(this.dependency, localArgs, this.callback));
				}
    		},
    		callback: function(openquestionsArray) {
    			var engine = require(this.dependency[0]);
            	engine.handle(openquestionsArray);
        	}
		}
    ];
    
	var loadOnDemandModulesInsideDiv = function($div, exclude) {
		loadModulesInsideDiv($div, exclude, onDemandModules);
	};
	
    var loadModulesInsideDiv = function($div, exclude, modules) {
    	if (exclude === undefined) {
    		exclude = [];
    	}
    	util.log("loadModulesInsideDiv excluded:", exclude);
    	if (modules == undefined) {
    		modules = pageModules;
    	}
		
    	try {
    		var dependenciesAndArgs = findDependenciesAndArgs($div, exclude, modules);
    		dispatchModules(dependenciesAndArgs, function () {});
    	}
    	catch (err) {
    		util.log(err);
    	}
    };
    
    var shouldLoadModule = function(name, exclude) {
    	return _.contains(exclude, name) == false;
    };
    
    var callFinishMethod = function (exclude) {
    	if (shouldLoadModule('notifyEverythingWasLoaded', exclude)) {
			util.notifyEverythingWasLoaded();
		}
    };
    
    var findDependenciesAndArgs = function ($div, exclude, modules) {
    	util.log("findModules");
    	
    	var found = {
    		dependencies: [],
    		fireArgs: [],
    		append: function (fireArg) {
    			this.dependencies = this.dependencies.concat(fireArg.dependency);
    			this.fireArgs.push(fireArg);
    		}
    	};
    	
    	for (var i = 0; i < modules.length; i++) {
    		var module = modules[i];
    		
    		if (module.shouldLoad($div, exclude)) {
    			module.init($div, function (fireArgs) {
    				found.append(fireArgs);
    			});
    		}
    	}
    	
    	return found;
    };
    
    var dispatchModules = function (dependenciesAndArgs, finished) {
    	util.log("dispatchModules");
    	
    	// load all modules
    	require(dependenciesAndArgs.dependencies, function() {
    		
    		// handle all modules
    		var args = dependenciesAndArgs.fireArgs;
			for (var i = 0; i < args.length; i++) {
				try {
					var fireArgs = args[i];
					fireArgs.fire();
				}
				catch (err) {
					util.log(err);
				}
			}
			
			if (finished !== undefined) {
				finished();
			}
    	});
    };
    
    return {
    	loadModulesInsideDiv:loadModulesInsideDiv,
		loadOnDemandModulesInsideDiv:loadOnDemandModulesInsideDiv,
		callFinishMethod:callFinishMethod
    }
});
