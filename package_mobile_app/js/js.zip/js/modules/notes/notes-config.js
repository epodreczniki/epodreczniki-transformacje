define(function(){
    return {
        ignoredClasses:['note-ignore','xyztesting'],
    };
});
