define([], function() {
	return {
		isMobile: true,
		isDesktop: false
	}
});