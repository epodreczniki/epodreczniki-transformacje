define([
    'jquery',
    'backbone',
    'portal/remote/modules/core/WomiManager',
    'portal/remote/layout',
    'portal/remote/layouts/Component',
    'underscore',
    'portal/remote/modules/core/Registry',
    'portal/remote/modules/core/Logger',
    'portal/remote/modules/utils/ReaderUtils',
    //'layoutWomiPath/gallery/WOMIContainer',
    //'layoutWomiPath/WOMIGalleryContainer',
    //womi classes to load
    'portal/remote/modules/core/womi/DummyContainer',
    'portal/remote/modules/core/womi/WOMIImageContainer',
    'portal/remote/modules/core/womi/WOMIIconContainer',
    'portal/remote/modules/core/womi/WOMIMovieContainer',
    'portal/remote/modules/core/womi/WOMIAudioContainer',
    'portal/remote/modules/core/womi/WOMIAttachmentContainer',
    'portal/remote/modules/core/womi/WOMIInteractiveObjectContainer',
    'portal/remote/modules/core/womi/MultipleWOMIContainer',
    //womi engines
    'portal/remote/modules/core/engines/AceEditorEngine',
    'portal/remote/modules/core/engines/AdobeEdgeEngine',
    'portal/remote/modules/core/engines/CustomLogicExerciseWomi',
    'portal/remote/modules/core/engines/GeneratedExerciseEngine',
    'portal/remote/modules/core/engines/GeogebraEngine',
    'portal/remote/modules/core/engines/PureHTMLEngine',
    'portal/remote/modules/core/engines/RaphaelWomiEngine',
    'portal/remote/modules/core/engines/SvgEditEngine',
    'portal/remote/modules/core/engines/SwiffyEngine',
    'portal/remote/modules/core/engines/WomiExerciseEngine'
], function ($, Backbone, womi, layout, Component, _, Registry, Logger, ReaderUtils, /* WOMIContainerGallery, WOMIGalleryContainer,*/ //womis
             DummyContainer, WOMIImageContainer, WOMIIconContainer, WOMIMovieContainer, WOMIAudioContainer, WOMIAttachmentContainer, WOMIInteractiveObjectContainer, MultipleWOMIContainer, //engines
             AceEditorEngine, AdobeEdgeEngine, CustomLogicExerciseWomi, GeneratedExerciseEngine, GeogebraEngine, PureHTMLEngine, RaphaelWomiEngine, SvgEditEngine, SwiffyEngine, WomiExerciseEngine) {

    return Component.extend({
        name: 'WOMI',

        postInitialize: function (options) {

            this._galleryRegisters();
            //initialize womi processors
            var o = {
                DummyContainer: DummyContainer,
                WOMIImageContainer: WOMIImageContainer,
                WOMIMovieContainer: WOMIMovieContainer,
                WOMIAudioContainer: WOMIAudioContainer,
                WOMIIconContainer: WOMIIconContainer,
                WOMIAttachmentContainer: WOMIAttachmentContainer,
                WOMIInteractiveObjectContainer: WOMIInteractiveObjectContainer,
                MultipleWOMIContainer: MultipleWOMIContainer
            };
            Registry.set('womi', o);

            //initialize womi engines
            var e = {
                ace_editor: AceEditorEngine,
                edge_animation: AdobeEdgeEngine,
                custom_logic_exercise_womi: CustomLogicExerciseWomi,
                custom_womi: GeneratedExerciseEngine,
                ge_animation: GeneratedExerciseEngine,
                geogebra: GeogebraEngine,
                createjs_animation: PureHTMLEngine,
                raphael_womi: RaphaelWomiEngine,
                svg_editor: SvgEditEngine,
                swiffy: SwiffyEngine,
                womi_exercise_engine: WomiExerciseEngine,
                framed_html: PureHTMLEngine
            };

            Registry.set('engines', e);

        },

        _galleryRegisters: function(){
            Registry.set('womiContainerGallery', WOMIContainerGallery);
            Registry.set('galleryContainer', WOMIGalleryContainer);
        },

        eventBlacklist: ['toggleWOMILicense', 'toggleWOMIAltText'],

        load: function () {
            var _this = this;
            this.listenTo(this._layout, 'moduleLoaded', function () {
                womi.load(function () {
                    //TODO: invent better load function in case of promise of all graphics loaded
                    setTimeout(function () {
                        _this.trigger('moduleWomiLoaded');
                        //womi.womiEventBus.trigger('toggleWOMILicense');
                    }, 2000);
                });
            });

            this.listenTo(womi.womiEventBus, 'all', function () {
                if(_.indexOf(_this.eventBlacklist, arguments[0]) < 0) {
                    _this.trigger.apply(_this, arguments);
                }
            });
        }

    });
});