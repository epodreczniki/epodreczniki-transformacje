define(['require', 'jquery', 'bowser'], function (require, $, bowser) {
    'use strict';
    var readerDefinition = $('#reader-definition');
    var deviceDetection = require('device_detection');

    readerDefinition = {
        stylesheet: readerDefinition.data('stylesheet'),
        env: readerDefinition.data('environment-type')
    };

    function EngineInterface(source, destination) {
        this.init(source, destination);
    }

    $.extend(EngineInterface.prototype, {
        debounceTimeout: 500,
        maxPercentageHeight: 0.80,
        roles: {},

        init: function (source, destination) {
            this.source = source;
            this.destination = destination;
            this.fsMode = false;
            var image = this.destination.find('.image-container');
            if (image.length == 1) {
                this.splashScreen = image.clone();
            }
        },

        load: function () {
        },

        dispose: function () {
        },

        createIframe: function (container, dimensions, onloadCallback, preLoadCallback) {
            var iframe = $('<iframe frameborder="0">').css({
                margin: 0,
                padding: 0,
                border: 'none',
                width: dimensions.width,
                height: dimensions.height
            });

            if (preLoadCallback) {
                preLoadCallback(iframe);
            }
            iframe.addClass('proper-element');

            iframe.load(function () {
                iframe.contents().find('body').css({
                    margin: 0,
                    padding: 0
                });

                onloadCallback(iframe);
            });

            $(container).append(iframe);
        },

        debounceBody: function (width, height) {
            this.dispose();
            this.load();
        },

        _reprocess: function () {
            if (!this._playScreenClicked) {
                this.dispose();
                this.load();
            }
        },

        _womiContainer: function () {
            return this.destination.closest('.womi-container')[0];
        },

        _processEvent: function (event, type) {
            if (typeof type !== 'undefined' && event.target == this._womiContainer()) {
                (this['_' + type])();
            }
        },

        getButtons: function () {
            return null;
        },

        debouncedResizeHandler: function () {
            var _this = this;

            if (this._debounceHandler) {
                return this._debounceHandler;
            } else {
                this._debounceHandler = $.debounce(_this.debounceTimeout, (function () {
                    var lastWidth = $(window).width();
                    var lastHeight = $(window).height();

                    return function (event, type) {
                        // This is a fix for behaviour seen on iPhone where address bar show/hide events cause resize events
                        if (lastHeight == $(window).height() && lastWidth == $(window).width()) {
                            _this._processEvent(event, type);
                            return;
                        }
                        var ua = navigator.userAgent;

                        if (ua.indexOf('Android') != -1 || ua.indexOf('iPhone') != -1 || ua.indexOf('iPad') != -1 || ua.indexOf('Windows Phone') != -1) {
                            var rotated = (lastHeight != $(window).height()) && (lastWidth != $(window).width());
                            if (!rotated) {
                                return;
                            }

                        }

                        lastHeight = $(window).height();
                        lastWidth = $(window).width();

                        _this.debounceBody(lastWidth, lastHeight);
                    };
                }()));

                return this._debounceHandler;
            }
        },

        setFullScreenMode: function () {
            this.fsMode = true;
        },
        hasFullscreen: function () {
            return true;
        },
        setRoles: function (roles) {
            this.roles = roles;
        },
        _prependUnderlay: function (create) {
            var dest = $(this.destination), _this = this;
            var underlay = dest.parent().find('.womi-underlay');
            if (create && underlay.length == 0) {
                underlay = $('<div>', { class: 'womi-underlay' });
                dest.before(underlay);
            }
            var wc = $(_this._womiContainer());
            if (underlay.length > 0) {
                underlay.css('position', 'absolute');
                underlay.css('top', wc.top);
                underlay.css('left', wc.left);
                underlay.css('width', wc.width() + 'px');
                underlay.css('height', wc.height() + 'px');
                underlay.css('z-index', -9999);
            }
        },

        _removeOverlay: function () {
            $(this.destination).parent().find('.womi-underlay').remove();
        },

        _fsEvent: function () {
            var ev;
            if (!bowser.msie) {
                ev = new CustomEvent('fullscreen', {
                    bubbles: true,
                    cancelable: true
                });
            } else {
                ev = document.createEvent("Event");
                ev.initEvent('fullscreen', true, true);
            }
            return ev;
        },

        _initPlayScreen: function (dimension) {
            var _this = this;
            if (this._playScreenClicked) {
                this.destination.empty();
                return false;
            } else {
                this._recreateSplashScreen();
                this.playItem = this._playItem(dimension);
                this.playItem.click(function () {
                    if (!epGlobal.isMobile) {
                        _this._playScreenClicked = true;
                        _this.load();
                    } else {

                        _this.destination[0].dispatchEvent(_this._fsEvent());
                    }
                    return false;
                });
                if (this.destination.find('.play-div').length == 0) {
                    this.destination.append(this.playItem);
                }
                return true;
            }
        },

        triggerFS: function () {
            this.destination[0].dispatchEvent(this._fsEvent());
        },

        _playItem: function (dimension) {
            var image, width, height;
            var _this = this;
            if (this.splashScreen) {
                var womi = require('womi');
                image = new womi.WOMIImageContainer(this.destination.find('.image-container'));
                image._isSplash = true;
                if (this.fsMode) {
                    //image._width = 100.0;
                    //image.maxHeight = 1.0;
                }
                this._playscreenImage = image;
                image.load();
                var container = $(image._imgElement);
                width = container.width();
                height = container.height();
            } else {
                width = dimension.width;
                height = dimension.height;
            }

            var div = $('<div/>', {
                class: 'play-div',
                css: {
                    position: 'relative'
                }
            });
            this._modifyPlayDiv(div);
            var overlay = $('<div/>', {
                class: 'womi-overlay'
            });

            var buttonClass = ( !deviceDetection.isMobile ? 'play-button-classic' : 'play-button-mini' );

            var button = $('<button/>', {
                class: 'play-button ' + buttonClass
            });

            div.append(button);

            if (image) {
                $(image._imgElement).addClass('proper-element');
                div.append(image._imgElement);
                div.on('remove', function () {
                    if (_this._playscreenImage) {
                        _this._playscreenImage.dispose();
                    }
                });
            }

            return div;
        },

        _modifyPlayDiv: function (div) {

        },

        _playLabel: function () {
            return '';
        },

        _loadEngineScript: function (name, url, callback) {
            if ($('script[data-engine-name="' + name + '"]').length == 0) {
                epGlobal.head.js(url, function () {
                    callback();
                });
            } else {
                callback();
            }
        },

        _loadScripts: function (args) {
            epGlobal.head.js.apply(this, arguments);
        },

        _recreateSplashScreen: function () {
            if (this.splashScreen) {
                if (this.destination.find('.image-container').length != 1) {
                    this.destination.append(this.splashScreen.clone());
                }
            }
        },
        getSize: function () {
        }
    });

    var scalingDivIframe = {
        plusWH: 3,
        iframeResizeCallback: function (width, height, iframe) {
            console.log('iframe callback called', width, height, iframe);
        },
        contentsAdjust: function (iframe) {
            iframe.contents().find('body').css({
                margin: 0,
                padding: 0,
                overflow: 'hidden'
            });
        },
        addMessageEvent: false,
        createIframe: function (container, dimensions, onloadCallback, preLoadCallback) {

            var iframe = $('<iframe frameborder="0">').css({
                margin: 0,
                padding: 0,
                border: 'none',
                width: dimensions.width + this.plusWH,
                height: dimensions.height + this.plusWH,
                overflow: 'hidden'
            });

            var _this = this;
            if (this.addMessageEvent) {
                $(window).on('message', function (e) {
                    if (iframe[0].contentWindow == e.originalEvent.source && e.originalEvent.data.msg == 'edgeResize') {
                        _this.iframeResizeCallback(e.originalEvent.data.width, e.originalEvent.data.height, iframe);
                    }
                });
            }
            if (preLoadCallback) {
                preLoadCallback(iframe);
            }
            iframe.addClass('proper-element');

            iframe.load(function () {
                _this.contentsAdjust(iframe);
                onloadCallback(iframe);
                iframe.css('transform', 'scale(' + (dimensions.scale) + ')');
                iframe.css('transform-origin', '0 0');
                iframe.css({
                    position: 'absolute',
                    top: 0,
                    left: 0
                });
            });
            var scalingDiv = $('<div>');
            scalingDiv.width(dimensions.desiredWidth).height(dimensions.desiredHeight);
            scalingDiv.css('margin', '0 auto');
            scalingDiv.css('overflow', 'hidden');
            $(container).append(scalingDiv);
            scalingDiv.append(iframe);
            scalingDiv.css({
                position: 'relative'
            });
        }
    };


    function GeogebraEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(GeogebraEngine.prototype, EngineInterface.prototype, scalingDivIframe, {
        scriptSrc: "{% autoescape off %}{{ STATIC_URL }}{{ EXTERNAL_ENGINES.geogebra.url_template }}{% endautoescape %}",

        VERSION_MAP: {
            '4.2': '4.2.60.0',
            '4.3': '4.3.81.0',
            '4.4': '4.4.37.0',
            'default': '4.4.37.0'
        },

        verRegex: /(\d+.\d+).\d+.\d+/,

        versionResolver: function (ver) {
            if (ver) {
                var splitVersion = ver.match(this.verRegex)[1];
                var resolver = this.VERSION_MAP[splitVersion];
                if (resolver) {
                    return resolver;
                } else {
                    return this.VERSION_MAP['default']
                }
            } else {
                return this.VERSION_MAP['default']
            }
        },

        load: function () {
            var dimensions = this.resizeArticleToContainer(this.destination);
            var ver = $(this.destination).data('version');

            this._prependUnderlay(false);

            if (!this.fsMode) {
                if (this._initPlayScreen(dimensions)) {
                    $(window).on('resize', this.debouncedResizeHandler());
                    return;
                } else {
                    $(window).off('resize', this.debouncedResizeHandler());
                }
            }

            var article = $(this.source);

            article.attr("data-param-enableRightClick", "false");

            var script = document.createElement('script');
            script.src = this.scriptSrc.replace('{ver}', this.versionResolver(ver));


            this.createIframe(this.destination, dimensions, function (iframe) {
                var cloned = article.clone();
                cloned.attr('data-param-width', cloned.attr('data-param-width') - 3);
                cloned.attr('data-param-height', cloned.attr('data-param-height') - 3);
                iframe.contents().find('body').append(cloned);
                iframe[0].contentWindow.document.body.appendChild(script);
            }, function (iframe) {
                iframe[0].scrolling = 'no';
            });

            $(window).on('resize', this.debouncedResizeHandler());
        },

        dispose: function () {
            this._prependUnderlay(true);
            $(this.destination).children().remove();
            this._playScreenClicked = false;
            $(window).off('resize', this.debouncedResizeHandler());

        },

        resizeArticleToContainer: function (container) {
            var article = $(this.source);
            var width = parseFloat($(container).data('width')) / 100.0;
            var w = (this.fsMode ? $(window).width() : (width * $(container).width()));
            var ratio = w / article.attr('data-param-width');

            var desiredWidth = w;
            var desiredHeight = article.attr('data-param-height') * ratio;

            var maxHeight = this.maxPercentageHeight * $(window).height();
            if (this.fsMode) {
                maxHeight = $(window).height();
            }

            if (desiredHeight > maxHeight) {
                var scale = maxHeight / desiredHeight;
                desiredWidth *= scale;
                desiredHeight *= scale;
            }

            desiredWidth = Math.floor(desiredWidth);
            desiredHeight = Math.floor(desiredHeight);

            // XXX Geogebra seems to use some additional pixels to draw its border so account for that
            //article.attr('data-param-width', article.attr('data-param-width') - 3);
            //article.attr('data-param-height', desiredHeight - 3);

            return {
                desiredWidth: desiredWidth,
                desiredHeight: desiredHeight,
                width: article.attr('data-param-width') * 1,
                height: article.attr('data-param-height') * 1,
                scale: Math.min(desiredWidth / article.attr('data-param-width'), desiredHeight / article.attr('data-param-height'))
            };
        },

        getSize: function () {
            var article = $(this.source);
            var dimensions = this.resizeArticleToContainer(this.destination);

            //return {width: article.attr('data-param-width'), height: article.attr('data-param-height')}
            return {width: dimensions.desiredWidth, height: dimensions.desiredHeight}
        },
        license: function(){
            return {
                type: 'object',
                src: {
                    license: 'PŁ'
                }
            }
        }

    });

    function SwiffyEngineScriptUrl(version) {
        var enginesPattern = '{% autoescape off %}{{ EXTERNAL_ENGINES.swiffypattern.url_template }}{% endautoescape %}';

        return '{{ STATIC_URL }}' + enginesPattern.replace('{ver}', version);
    }

    function SwiffyEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(SwiffyEngine.prototype, EngineInterface.prototype, {

        load: function () {
            this.internalWindow = null;
            var srcUrl = this.source;
            var dimensions = {
                width: $(this.destination).width(),
                height: $(this.destination).width() * $(this.destination).parent().data('height-ratio')
            };

            var maxHeight = this.maxPercentageHeight * $(window).height();
            if (this.fsMode) {
                maxHeight = $(window).height();
            }

            if (dimensions.height > maxHeight) {
                var scale = maxHeight / dimensions.height;
                dimensions.width *= scale;
                dimensions.height *= scale;
            }
            this._prependUnderlay(false);
            if (!this.fsMode) {
                if (this._initPlayScreen(dimensions)) {
                    $(window).on('resize', this.debouncedResizeHandler());
                    return;
                } else {
                    $(window).off('resize', this.debouncedResizeHandler());
                }
            }
            var _this = this;
            if (navigator.userAgent.indexOf("MSIE") != -1) {

                $.get(srcUrl, function (data) {
                    _this.createIframe(_this.destination, dimensions, function (iframe) {
                        var scriptSrc = SwiffyEngineScriptUrl("6.0");
                        var scriptSrcPattern = /var scriptSrc = .*;/;
                        var documentDomainPattern = /document\.domain .*;/;
                        var newData = data.replace(scriptSrcPattern, 'var scriptSrc = \"' + scriptSrc + '\";');
                        newData = newData.replace(documentDomainPattern, '');
                        iframe[0].contentWindow.document.write(newData);
                        _this.internalWindow = iframe[0].contentWindow;
                        iframe.contents().find('#swiffycontainer').css('width', dimensions.width + "px").css('height', dimensions.height + "px");
                    }, function (iframe) {
                        //pass
                    });

                    $(window).on('resize', _this.debouncedResizeHandler());
                }, null, 'html');
            } else {
                this.createIframe(this.destination, dimensions, function (iframe) {
                    iframe.contents().find('#swiffycontainer').css('width', dimensions.width + "px").css('height', dimensions.height + "px");
                    _this.internalWindow = iframe[0].contentWindow;
                }, function (iframe) {
                    iframe[0].src = srcUrl;
                });

                $(window).on('resize', this.debouncedResizeHandler());
            }

        },

        dispose: function () {
            this._prependUnderlay(true);
            $(this.destination).children().remove();
            this._playScreenClicked = false;
            this.internalWindow = null;
            $(window).off('resize', this.debouncedResizeHandler());
        },

        getSize: function () {
            var hRatio = $(this.destination).parent().data('height-ratio');

            return {width: 900, height: 900 * hRatio}
        },

        getButtons: function () {
            var _this = this;
            return {
                stop: function () {
                    _this.dispose();
                    _this.load();
                },
                pause: function () {
                    if (_this.internalWindow != null) {
                        if (this.paused) {
                            _this.internalWindow.stageObj.start();
                            this.paused = false;
                        } else {
                            _this.internalWindow.stageObj.stop();
                            this.paused = true;
                        }
                    } else {
                        _this._playScreenClicked = true;
                        _this.load();
                    }

                }
            }
        }
    });

    function PureHTMLEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(PureHTMLEngine.prototype, EngineInterface.prototype, {
        _calcDimensions: function () {
            var dimensions = {
                width: $(this.destination).width(),
                height: $(this.destination).width() * $(this.destination).parent().data('height-ratio')
            };

            var maxHeight = this.maxPercentageHeight * $(window).height();
            if (this.fsMode) {
                maxHeight = $(window).height();
            }

            if (dimensions.height > maxHeight) {
                var scale = maxHeight / dimensions.height;
                dimensions.width *= scale;
                dimensions.height *= scale;
            }
            return dimensions;
        },

        load: function () {

            var srcUrl = this.source;
            var dimensions = this._calcDimensions();

            if (!this.fsMode) {
                if (this._initPlayScreen(dimensions)) {
                    $(window).on('resize', this.debouncedResizeHandler());
                    return;
                } else {
                    $(window).off('resize', this.debouncedResizeHandler());
                }
            }
            var _this = this;
            this.createIframe(this.destination, dimensions, function (iframe) {
            }, function (iframe) {
                iframe[0].src = srcUrl;
                _this.debounceBody = function (width, height) {
                    iframe.css(_this._calcDimensions());
                };
            });

            $(window).on('resize', this.debouncedResizeHandler());

        },

        _modifyPlayDiv: function (div) {
            var dim = this._calcDimensions();
            div.css('min-height', dim.height);
        },
        dispose: function () {
            this._prependUnderlay(true);
            $(this.destination).children().remove();
            this._playScreenClicked = false;
            $(window).off('resize', this.debouncedResizeHandler());
        },

        getSize: function () {
            var hRatio = $(this.destination).parent().data('height-ratio');

            return {width: 900, height: 900 * hRatio}
        }
    });


    function AdobeEdgeEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(AdobeEdgeEngine.prototype, PureHTMLEngine.prototype, scalingDivIframe, {
        plusWH: 0,
        _4k: 4000,
        addMessageEvent: true,
        contentsAdjust: function () {
        },
        iframeResizeCallback: function (width, height, iframe) {
            this.savedHeight = height;
            this.savedWidth = width;
            var dimensions = this._calcDimensions();
            iframe.width(width).height(height);
            iframe.css('transform', 'scale(' + (dimensions.scale) + ')');
            iframe.css('transform-origin', '0 0');
            var _this = this;
            this.debounceBody = function (width, height) {
                var d = _this._calcDimensions();
                iframe.parent().css({
                    width: d.desiredWidth,
                    height: d.desiredHeight
                });
                iframe.css('transform', 'scale(' + (d.scale) + ')');
                iframe.css('transform-origin', '0 0');
            };
        },
        _calcDimensions: function () {
            var hRatio = $(this.destination).parent().data('height-ratio');
            var dimensions = {
                width: $(this.destination).width(),
                height: $(this.destination).width() * hRatio
            };

            var maxHeight = this.maxPercentageHeight * $(window).height();
            if (this.fsMode) {
                maxHeight = $(window).height();
            }

            if (dimensions.height > maxHeight) {
                var scale = maxHeight / dimensions.height;
                dimensions.width *= scale;
                dimensions.height *= scale;
            }
            dimensions.desiredWidth = dimensions.width;
            dimensions.desiredHeight = dimensions.height;
            dimensions.width = this.savedWidth || dimensions.desiredWidth;
            dimensions.height = this.savedHeight || dimensions.desiredHeight;
            dimensions.scale = Math.min(dimensions.desiredWidth / dimensions.width, dimensions.desiredHeight / dimensions.height);
            return dimensions;
        }
    });


    function AceEditorEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(AceEditorEngine.prototype, EngineInterface.prototype, {
        scriptSrc: "{% autoescape off %}{{ STATIC_URL }}{{ EXTERNAL_ENGINES.ace_editor.url_template }}{% endautoescape %}",

        _getExt: function (src) {
            return src.substring(src.indexOf('.') + 1);
        },

        _calcDimensions: function () {
            return {
                width: $(this.destination).width(),
                height: this.maxPercentageHeight * $(window).height()
            };
        },

        load: function () {
            var src = this.source;
            var _this = this;
            var dimensions = this._calcDimensions();
            var ext = this._getExt(src);
            require(['require', 'text!' + src], function (r, config) {
                config = JSON.parse(config);
                require(['text!' + r.toUrl(src + '/../' + config.file)], function (code) {
                    var newSrc = _this.scriptSrc + '?mode=' + config.mode +
                        '&code=' + encodeURIComponent(code) +
                        '&theme=' + config.theme;
                    _this.createIframe(_this.destination, dimensions, function (iframe) {
                    }, function (iframe) {
                        iframe[0].src = newSrc;
                        _this.debounceBody = function (width, height) {
                            iframe.css(_this._calcDimensions());
                        };
                    });

                    $(window).on('resize', _this.debouncedResizeHandler());
                });
            });
        },

        hasFullscreen: function () {
            return false;
        }

    });

    function SvgEditEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(SvgEditEngine.prototype, PureHTMLEngine.prototype, {
        scriptSrc: "{% autoescape off %}{{ STATIC_URL }}{{ EXTERNAL_ENGINES.svg_editor.url_template }}{% endautoescape %}",

        _calcDimensions: function () {
            return {
                width: $(this.destination).width(),
                height: (this.fsMode ? $(window).height() : this.maxPercentageHeight * $(window).height())
            };
        },

        load: function () {
            this._playScreenClicked = true;
            this.savedSrc = this.savedSrc || this.source;
            this.source = this.scriptSrc + '?url=' + $('base').attr('href') + this.savedSrc;
            PureHTMLEngine.prototype.load.call(this);
        }
    });

    function RaphaelWomiEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(RaphaelWomiEngine.prototype, PureHTMLEngine.prototype, {
        scriptSrc: "{% autoescape off %}{{ STATIC_URL }}{{ EXTERNAL_ENGINES.raphael_womi.url_template }}{% endautoescape %}",

        load: function () {

            var src = this.source;
            var base = src.replace(src.substr(src.lastIndexOf('/') + 1), '');
            base = base.replace('/', '');

            this.savedSrc = this.savedSrc || this.source;
            var _this = this;

            if (!this._playScreenClicked) {
                require(['require', 'text!' + src], function (r, config) {
                    config = JSON.parse(config);

                    var newSrc = _this.scriptSrc + '?url=' + $('base').attr('href') + base + config.file;

                    if (config.style != undefined)
                        newSrc = newSrc + '&style_url=' + $('base').attr('href') + base + config.style;

                    _this.source = newSrc;

                    PureHTMLEngine.prototype.load.call(_this);
                });
            }
            else {
                PureHTMLEngine.prototype.load.call(this);
            }
        }

    });


    function GeneratedExerciseEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(GeneratedExerciseEngine.prototype, EngineInterface.prototype, {
        _calcDimensions: function (isAvatar) {
            if (isAvatar) {
                return {
                    height: $(this._womiContainer()).height(),
                    width: $(this._womiContainer()).width()
                };
            }

            var hR = $(this.destination).parent().data('height-ratio');
            var tile = this.destination.closest('.tile');
            var dimensions = {
                width: $(this.destination).width(),
                height: $(this.destination).width() * (hR ? hR : 1)
            };

            if(readerDefinition.env == 'uwr'){
                return dimensions;
            }
            var maxHeight = this.maxPercentageHeight * $(window).height();
            if (tile.length > 0) {
                if (!tile.hasClass('anchor-padding')) {
                    maxHeight = tile.height() * this.maxPercentageHeight;
                }
                //_this._mainContainerElement.closest('.womi-container').find('.title').hide();
            }

            if (this.fsMode) {
                maxHeight = $(window).height();
            }
            if (dimensions.height > maxHeight) {
                var scale = maxHeight / dimensions.height;
                dimensions.width *= scale;
                dimensions.height *= scale;
            }
            return dimensions;
        },

        _calcMaximized: function () {
            return {
                height: $(window).height() - 10,
                width: $(window).width() - 10
            };
        },

        _calcContainer: function () {
            if (this.obj.isAvatar && this.roles.context) {
                var a = $(window).height() * 0.25;
                $(this._womiContainer()).css({
                    'position': 'fixed',
                    'bottom': '0px',
                    'left': '80px',
                    padding: 0,
                    width: a,
                    height: a
                });
            }
        },

        _modifyPlayDiv: function (div) {
            //var dimm = this._calcDimensions(this.obj && this.obj.isAvatar);

            //div.css('min-height', dimm.height);
        },

        load: function () {

            var _this = this;
            require([this.source], function (lib) {
                _this.obj = new lib();
                _this._calcContainer();
                var dimensions = _this._calcDimensions(_this.obj.isAvatar);
                if (!_this.obj.isAvatar) {
                    if (!_this.fsMode) {
                        if(readerDefinition.env == 'uwr'){
                            _this._playScreenClicked = true;
                        }
                        if (_this._initPlayScreen(dimensions)) {
                            $(window).on('resize', _this.debouncedResizeHandler());
                            return;
                        } else {
                            $(window).off('resize', _this.debouncedResizeHandler());
                            if (_this.obj.enableMaximize) {
                                _this.savedStyle = _this.destination.attr('style');
                                _this.destination.css({
                                    'background-color': 'white',
                                    position: 'fixed',
                                    top: '5px',
                                    left: '5px',
                                    'z-index': '100000'
                                });
                                dimensions = _this._calcMaximized();
                                _this.destination.css({width: dimensions.width + 'px',
                                    height: dimensions.height + 'px'});
                            }
                        }
                    }
                }

                if (_this.obj.sizeChange) {
                    _this.obj.sizeChange(dimensions.width, dimensions.height);
                }

                var opts = {
                    width: dimensions.width,
                    height: dimensions.height,
                    isFullscreen: _this.fsMode,
                    methods: {
                        openFullscreen: function () {

                            _this.destination[0].dispatchEvent(_this._fsEvent());
                        },
                        closeFullscreen: function () {
                            $.fancybox.close(true);
                        }
                    }
                };
                if (_this.obj.enableMaximize) {
                    opts.methods = {
                        closeWomi: function () {
                            _this.dispose();
                            _this.destination.attr('style', _this.savedStyle);
                            _this.load();
                        }
                    }
                }

                _this.obj.start(_this.destination, opts);
                $(window).on('resize', _this.debouncedResizeHandler());
            });

        },
        dispose: function () {
            try {
                if (this.obj) {
                    if (this.obj.clean) {
                        this.obj.clean();
                    }

                    $(this.destination).children().remove();
                    this._playScreenClicked = false;
                    $(window).off('resize', this.debouncedResizeHandler());
                }

            } catch (err) {
                console.error(err);
            }

        },
        debounceBody: function (width, height) {
            try {
                this._calcContainer();
                var dimensions = this._calcDimensions(this.obj.isAvatar);
                if (this.obj.enableMaximize) {
                    dimensions = this._calcMaximized();
                }
                if (this.obj.sizeChange) {
                    this.obj.sizeChange(dimensions.width, dimensions.height);
                }
            } catch (err) {
                console.error(err);
            }
        },
        hasFullscreen: function () {
            return true;
        },
        getSize: function () {
            return this._calcDimensions(false);
        }
    });

    function WomiExerciseEngine(source, destination) {
        this.init(source, destination);
    }

    $.extend(WomiExerciseEngine.prototype, EngineInterface.prototype, {
        LIMIT_WIDTH: 948,
        load: function () {
            var _this = this;
            require(['modules/womi_exercise'], function (engine) {
                var obj = new engine({source: _this.source, destination: _this.destination});
                obj.start();
            });
        },
        hasFullscreen: function () {
            return false;
        },
        _reprocess: function () {

        },
        getSize: function () {
            return {
                width: ($(window).width() < this.LIMIT_WIDTH ? $(window).width() : this.LIMIT_WIDTH),
                height: $(window).height()
            }
        }
    });

    function CustomLogicExerciseWomi(source, destination) {
        this.init(source, destination);
    }

    $.extend(CustomLogicExerciseWomi.prototype, EngineInterface.prototype, {
        load: function () {
            var _this = this;

            require([this.source], function (lib) {
                _this.obj = new lib();
                _this.obj.start(_this.destination);
            });
        },
        hasFullscreen: function () {
            return false;
        },
        _reprocess: function () {

        }
    });

    function MathJaxEngine() {
        this.init();
    }

    $.extend(MathJaxEngine.prototype, EngineInterface.prototype, {

        init: function () {
            MathJax.Hub.Queue(['Typeset', MathJax.Hub]);
            //$(window).on('resize', this.debouncedResizeHandler());
        },

        mathJaxReload: function () {
            MathJax.Hub.Queue(['Rerender', MathJax.Hub]);
        },

        debounceBody: function (width, height) {
            this.mathJaxReload();
        },

        _processEvent: function (event, type) {
        }

    });

    function PostLoadProcesses() {
        this.init();
    }

    $.extend(PostLoadProcesses.prototype, {
        init: function () {
            this.endProcessHook();
        },
        initialized: false,

        _reprocess: function (className, inputSelector, toggles) {
            $(className).each(function (index, entry) {
                if (typeof toggles === 'undefined') {
                    toggles = false;
                }
                var _this = entry;
                var parent;
                if (toggles) {
                    parent = $(_this).prev();
                } else {
                    parent = $(_this).parent();
                }
                var input = parent.find(inputSelector);
                if (input.length > 0) {
                    input.click(function () {
                        setTimeout(function () {
                            if (typeof MathJax !== 'undefined') {
                                MathJax.Hub.Rerender(_this);
                            }
                            var els = $(_this).find('.womi-container');
                            els.trigger('resize', ['reprocess']);
                        }, 100);

                    });
                }
            });
        },

        _reprocessRoutines: function () {
            this._reprocess('div[class="feedback"]', 'input[type="button"]');
            this._reprocess('div[class="feedback"]', 'input[type="radio"]');
            this._reprocess('div[class="hint"]', 'input[type="button"]');
            //this._reprocess('.solution', 'a', true);
            //this._reprocess('.commentary', 'a', true);
            this._reprocess('.solution', 'input[type="button"]', true);
            this._reprocess('.commentary', 'input[type="button"]', true);
        },

        endProcessHook: function () {
            if (typeof MathJax !== 'undefined') {
                var _this = this;
                MathJax.Hub.Register.MessageHook("End Process", function () {
                    if (!_this.initialized) {
                        _this._reprocessRoutines();
                        _this.initialized = true;
                    }
                });
            } else {
                this._reprocessRoutines();
            }

        }

    });

    var polyfill = {
        EngineInterface: EngineInterface,
        GeogebraEngine: GeogebraEngine,
        SwiffyEngine: SwiffyEngine,
        SwiffyEngineScriptUrl: SwiffyEngineScriptUrl,
        MathJaxEngine: MathJaxEngine,
        PostLoadProcesses: PostLoadProcesses,
        GeneratedExerciseEngine: GeneratedExerciseEngine,
        WomiExerciseEngine: WomiExerciseEngine,
        PureHTMLEngine: PureHTMLEngine,
        CustomLogicExerciseWomi: CustomLogicExerciseWomi,
        AceEditorEngine: AceEditorEngine,
        SvgEditEngine: SvgEditEngine,
        RaphaelWomiEngine: RaphaelWomiEngine,
        AdobeEdgeEngine: AdobeEdgeEngine
    };

    window.epGlobal = window.epGlobal || {};
    epGlobal.common = epGlobal.common || {};
    epGlobal.common.engines = polyfill;

    return polyfill;

});
