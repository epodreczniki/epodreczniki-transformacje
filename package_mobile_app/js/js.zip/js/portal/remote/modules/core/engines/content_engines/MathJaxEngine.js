define(['jquery', './ContentEngineInterface'], function ($, ContentEngineInterface) {

    return ContentEngineInterface.extend({

        initialize: function () {
            MathJax.Hub.Queue(['Typeset', MathJax.Hub]);
        },

        reload: function (placeholder, options) {
            //MathJax.Hub.Queue(['Rerender', MathJax.Hub]);
            if (typeof MathJax !== 'undefined') {
                if (options && options.typeset) {
                    MathJax.Hub.Queue(["Typeset",MathJax.Hub,$(placeholder)[0]]);
                } else {
                    MathJax.Hub.Rerender($(placeholder)[0]);
                }
            }
        }

    });



});
