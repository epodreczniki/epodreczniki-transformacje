define(['portal/remote/modules/core/womi/WOMIImageContainerEmbedded'], function (WOMIImageContainer) {
    return WOMIImageContainer.extend({
        MEDIA_MAPPINGS: {
        },
        DEFAULT_MEDIA: '',
        _buildMediaUrl: function (root, entry) {
            return root;
        }
    });
});