define(['portal/remote/modules/core/Registry',
    'jquery',
    'underscore',
    'portal/remote/modules/core/Performance',
    'portal/remote/modules/core/womi/WOMIContainer',
    'portal/remote/modules/core/womi/WOMIImageContainer',
    'backbone',
	'portal/remote/modules/core/womi/WOMIInteractiveObjectContainer',
	// imports
	'portal/remote/modules/core/womi/WOMIGalleryContainer',
	'portal/remote/modules/core/engines/GeogebraEngine'
], function (Registry, $, underscore, Perf, WOMIContainer, WOMIImageContainer, Backbonem,
	WOMIInteractiveObjectContainer, WOMIContainerGallery, GeogebraEngine) {


    var objList = [];

    var eventBus = {};
    _.extend(eventBus, Backbone.Events);

	Registry.set('womi', {
		'WOMIInteractiveObjectContainer': WOMIInteractiveObjectContainer,
		'WOMIContainerGallery': WOMIContainerGallery
	});
	Registry.set('engines', {
		'geogebra': GeogebraEngine
	});

    function getOverride(overrides) {
        return WOMIContainer.extend({
            CLASS_MAPPINGS: function () {
                var mappings = WOMIContainer.prototype.CLASS_MAPPINGS.call(this);
                return _.extend(mappings, overrides);
            }
        });
    }


    function pushAndCatchError(Clazz, node, loader) {
        //try {
            if ($(node).data('womiObject')) {
                return $(node).data('womiObject');
            }
            var obj = new Clazz({el: node});
            if (loader) {
                loader.registerWomi(obj);
            }
            obj.render();
            objList.push(obj);
            return obj;
			//} catch (err) {
            console.warn('Error on element', node, err);
            $(node).append($('<div>', { html: err.message + '<br>' + err.stack }));
			//}
        return null;
    }

    function loadAllGalleries() {
        var WOMIGalleryContainer = Registry.get('galleryContainer');
        $('.womi-gallery').each(function (index, element) {
            try {
                var obj = new WOMIGalleryContainer({el: element});
                objList.push(obj);
            } catch (err) {
                console.warn('Error on element', element, err);
                $(element).append($('<div>', { html: err.message + '<br>' + err.stack }));
            }
        });
    }

    function createLoader() {
        var object = {
            registeredWomis: 0,
            loadedWomis: 0,
            registerWomi: function (womi) {
                if (womi && womi.selected && womi.selected.object && !(womi.selected.options && womi.selected.options.roles.context)) {
                    this.listenTo(womi.selected.object, 'fullyLoaded', function () {
                        this.loadedWomis++;
                        if (this.registeredWomis == this.loadedWomis) {
                            this.trigger('allWomisLoaded');
                        }
                    });
                } else {
                    this.registeredWomis--;
                    if (this.registeredWomis == this.loadedWomis) {
                        this.trigger('allWomisLoaded');
                    }
                }
            }
        };

        _.extend(object, Backbone.Events);

        return object;
    }

    function loadAllWOMI(callback) {

        objList = [];
        //player.clearPlayers();
        var loader = createLoader();
        loader.on('allWomisLoaded', function () {
            Perf.stopPerformance();
            eventBus.trigger('allWomiLoaded');
        });
        var wcs = $('.womi-container');
        var filtered = [];
        wcs.each(function(){
            if(!$(this).parent().hasClass('related')) {
                filtered.push($(this));
            }
        });
        loader.registeredWomis = filtered.length;
        $(filtered).each(function (index, element) {
            //objList.push(new WOMIContainer(element));
            pushAndCatchError(WOMIContainer, element, loader);
        });
        loadAllGalleries();
        //
        //handleSvg.handleSVGImages();

        $(objList).each(function (index, womi) {
            if (womi.updateWomiMenu) {
                womi.updateWomiMenu();
            }
        });
        callback && callback();
    }

    function loadAllWOMI2(handler) {
        //objList = [];
        //setTimeout(function(){
        $(handler).find('.womi-container').each(function (index, element) {
            pushAndCatchError(WOMIContainer, element);
        });
        //}, 300);

        //handleSvg.handleSVGImages();
    }

    function disposeAllWOMI() {
        objList.forEach(function (entry) {
            entry.dispose();
        });
    }

    function resizeAll() {
        objList.forEach(function (entry) {
            entry.callResize();
        });
    }

    function recalculateAll() {
        objList.forEach(function (entry) {
            entry.callRecalculateSize();
        });

    }

    function resizeSelected(selectedWomis) {
        _.each(selectedWomis, function (womi) {
            womi.callResize();
        });
    }

    function loadSingleWOMI(id, toNode, callback, womiOverrides) {

        require(['placeholder.api'], function (PlaceholderApi) {
            var api = new PlaceholderApi(toNode, false);
            api.getWomiContainer(id, '100%', function (container, manifest) {
                toNode.append(container);
                var o = pushAndCatchError((womiOverrides ? getOverride(womiOverrides) : WOMIContainer), container);
                callback && callback(o);
            });
        });

    }

    return {
        load: loadAllWOMI,
        load2: loadAllWOMI2,
        disposeAll: disposeAllWOMI,
        resizeAll: resizeAll,
        recalculateAll: recalculateAll,
        resizeSelected: resizeSelected,
        loadSingleWOMI: loadSingleWOMI,
        womiEventBus: eventBus,
        get objects() {
            return objList;
        },
        wasFirstLoad: function () {
            return firstLoad;
        },
        otherReady: function (bool) {
            //otherReady = bool
        },
        switchToMobile: function () {
            objList.forEach(function (entry) {
                entry.switchToMobile();
            });
        },
        WOMIImageContainer: WOMIImageContainer
    };
});