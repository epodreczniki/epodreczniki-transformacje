define(['jquery', 'backbone'], function ($, Backbone) {

    return Backbone.View.extend({
        reload: function(placeholder){

        }
    });
});