define(['jquery',
    'backbone',
    'bowser',
    'portal/remote/modules/core/Registry',
    'portal/remote/modules/core/womi/WOMIAudioContainer',
    'portal/remote/modules/core/womi/WOMIImageContainer',
    'portal/remote/modules/core/engines/EngineInterface',
    'videoplayer/player.ext'
], function ($, Backbone, bowser, Registry, WOMIAudioContainer, WOMIImageContainer, EngineInterface, player) {
    var isTouch = true;
    var WOMIMovieContainer = WOMIAudioContainer.extend({
        maxHeight: 0.7,
        containerClass: 'movie-container',
        //template: '<div class="jp-type-single"><div id="{0}_jplayer" name="jplayer" class="jp-jplayer"></div><div class="jp-gui"><div class="jp-video-play"><a href="javascript:;"class="jp-video-play-icon"tabindex="1">play</a></div><div class="jp-interface"><div class="jp-progress"><div class="jp-seek-bar"><div class="jp-play-bar"></div></div></div><div class="jp-current-time"></div><div class="jp-duration"></div><div class="jp-bitrate"><span class="qualityHeader">Jakość:&nbsp;</span><select name="qualityTracks" class="jp-quality-select" onchange="OnQualityTrackChange(this);return false;" title="Wybór jakości"><option value="1080">Najwyższa</option><option value="720">Wysoka</option><option value="360">Średnia</option> <option value="270">Niska</option></select></div><div class="jp-wide"> <div class="jp-tracks-holder"><span class="trackHeader" style="display: none; visibility: hidden">Ścieżki:&nbsp;</span><select name="audioTracks" class="jp-select" style="display: none; visibility: hidden" onchange="OnAudioTrackChange(this);return false;" title="Ścieżki dźwiękowe"></select><span class="subtitleHeader" style="display: none; visibility: hidden">Napisy:&nbsp;</span><select name="subtitleTracks" class="jp-select" style="display: none; visibility: hidden;" onchange="OnSubtitleTrackChange(this);return false;" title="Napisy"></select></div><div class="jp-controls-holder"><ul class="jp-controls"><li><a href="javascript:;"class="jp-play"tabindex="1">play</a></li><li><a href="javascript:;"class="jp-pause"tabindex="1">pause</a></li><li><a href="javascript:;"class="jp-stop"tabindex="1">stop</a></li><li><a href="javascript:;"class="jp-mute"tabindex="1"title="mute">mute</a></li><li><a href="javascript:;"class="jp-unmute"tabindex="1"title="unmute">unmute</a></li><li><a href="javascript:;"class="jp-volume-max"tabindex="1"title="max volume">max volume</a></li></ul><div class="jp-volume-bar"><div class="jp-volume-bar-value"></div></div><ul class="jp-toggles"><li><a href="javascript:;"class="jp-full-screen"tabindex="1"title="full screen">full screen</a></li><li><a href="javascript:;"class="jp-restore-screen"tabindex="1"title="restore screen">restore screen</a></li><li><a href="javascript:;"class="jp-repeat"tabindex="1"title="repeat">repeat</a></li><li><a href="javascript:;"class="jp-repeat-off"tabindex="1"title="repeat off">repeat off</a></li></ul></div></div><div class="jp-title"><ul><li><div name="errorInfo"></div></li></ul></div></div></div><div class="jp-no-solution"><span>Problem z odtwarzaniem</span>W bieżącej przeglądarce nie ma możliwości odtwarzania materiału video, proszę kliknąć w <a id="{0}_fallback" href="" >materiał video</a>.</div><div class="jp-fallback-video" id="{0}_no_solution"><div></div>',
        template: '<div class="jp-type-single"><div id="{0}_jplayer" name="jplayer" class="jp-jplayer"></div><div class="jp-gui"><div class="jp-video-play"><a href="javascript:;"class="jp-video-play-icon"tabindex="1">play</a></div><div class="jp-interface"><div class="jp-progress"><div class="jp-seek-bar"><div class="jp-play-bar"></div></div></div><div class="jp-current-time"></div><div class="jp-duration"></div><div class="jp-bitrate"><span class="qualityHeader">Jakość:&nbsp;</span><select name="qualityTracks" class="jp-quality-select" title="Wybór jakości"><option value="1080">Najwyższa</option><option value="720">Wysoka</option><option value="360">Średnia</option> <option value="270">Niska</option></select></div><div class="jp-wide"> <div class="jp-tracks-holder"><span class="trackHeader" style="display: none; visibility: hidden">Ścieżki:&nbsp;</span><select name="audioTracks" class="jp-select" style="display: none; visibility: hidden" title="Ścieżki dźwiękowe"></select><span class="subtitleHeader" style="display: none; visibility: hidden">Napisy:&nbsp;</span><select name="subtitleTracks" class="jp-select" style="display: none; visibility: hidden;" title="Napisy"></select></div><div class="jp-controls-holder"><ul class="jp-controls"><li><a href="javascript:;"class="jp-play"tabindex="1">play</a></li><li><a href="javascript:;"class="jp-pause"tabindex="1">pause</a></li><li><a href="javascript:;"class="jp-stop"tabindex="1">stop</a></li><li><a href="javascript:;"class="jp-mute"tabindex="1"title="mute">mute</a></li><li><a href="javascript:;"class="jp-unmute"tabindex="1"title="unmute">unmute</a></li><li><a href="javascript:;"class="jp-volume-max"tabindex="1"title="max volume">max volume</a></li></ul><div class="jp-volume-bar"><div class="jp-volume-bar-value"></div></div><ul class="jp-toggles"><li><a href="javascript:;"class="jp-full-screen"tabindex="1"title="full screen">full screen</a></li><li><a href="javascript:;"class="jp-restore-screen"tabindex="1"title="restore screen">restore screen</a></li><li><a href="javascript:;"class="jp-repeat"tabindex="1"title="repeat">repeat</a></li><li><a href="javascript:;"class="jp-repeat-off"tabindex="1"title="repeat off">repeat off</a></li></ul></div></div><div class="jp-title"><ul><li><div name="errorInfo"></div></li></ul></div></div></div><div class="jp-no-solution"><span>Problem z odtwarzaniem</span>W bieżącej przeglądarce nie ma możliwości odtwarzania materiału video, proszę kliknąć w <a id="{0}_fallback" href="" >materiał video</a>.</div><div class="jp-fallback-video" id="{0}_no_solution"><div></div>',

        _lookForBlocks: function () {
            //this._mainContainerElement = $(this._mainContainerElement[0]);
            this._keyframe = this._mainContainerElement.find('.keyframe').clone();
            this._audioTracksBlock = this._mainContainerElement.find('.audio-tracks');
            this._subtitlesBlock = this._mainContainerElement.find('.subtitles');
        },
        _discoverContent: function () {
            var _this = this;
            this._altText = this.options.altText || this._mainContainerElement.data('alt');
            this._width = this.options.width || this._mainContainerElement.data('width');
            this._movieId = this.options.movieId || this._mainContainerElement.data('movie-id');
            this._aspectRatio = this.options.aspectRatio || parseFloat(this._mainContainerElement.data('aspect-ratio')) || 1.78;
            this._describedBy = this._mainContainerElement.data('described-by');
            this.audioTracks = null;
            this.subtitles = null;
            if (this._audioTracksBlock.length) {
                this.audioTracks = [];
                this._audioTracksBlock.find('div').each(function (index, element) {
                    _this.audioTracks.push({
                        text: $(element).data('text'),
                        value: $(element).data('value')
                    });
                });
            }
            if (this._subtitlesBlock.length) {
                this.subtitles = [];
                this._subtitlesBlock.find('div').each(function (index, element) {
                    _this.subtitles.push({
                        text: $(element).data('text'),
                        value: $(element).data('value')
                    });
                });
            }
        },
        contextCallback: function () {
            this.hasFullscreenItem = function () {
                return true;
            };
            //this._fullscreenMenuItem().callback();
            //this._mainContainerElement[0].dispatchEvent(engines.EngineInterface.prototype._fsEvent.apply(null));
            this.parent.trigger('openContext');
            this.hasFullscreenItem = function () {
                return false;
            };
        },
        getFSElement: function () {
            var parentDiv = this._mainContainerElement.clone();
            var cloned = $('<div>');
            parentDiv = $('<div>');
            //cloned.remove();
            var _this = this;

            parentDiv.width($(window).width());
            parentDiv.height($(window).height());

            if (this.player) {
                this.player.Player.jPlayer('pause');
            }

            return {element: parentDiv,
                cancelUpdate: true,
                options: {
                    scrolling: 'hidden',
                    helpers: {
                        overlay: {
                            locked: isTouch
                        }
                    }
                },
                afterLoad: function () {
                    this.movie = new WOMIMovieContainer({ el: cloned, options: {
                        altText: _this._altText,
                        width: _this._width,
                        aspectRatio: _this._aspectRatio,
                        movieId: _this._movieId
                    }});
                    this.movie._isFS = true;
                    parentDiv.append(this.movie.render());
                    this.movie.trigger('renderDone');

                },
                reload: function () {
                },
                afterClose: function () {
                    this.movie && this.movie.dispose();
                }
            };
        },
        _registerPlayerElements: function (div) {
            div.find('[name="qualityTracks"]').change(function () {
                player.OnQualityTrackChange(this);
                return false;
            });


            div.find('[name="subtitleTracks"]').change(function () {
                player.OnSubtitleTrackChange(this);
                return false;
            });

            div.find('[name="audioTracks"]').change(function () {
                player.OnAudioTrackChange(this);
                return false;
            });
        },
        _calcWidth: function () {
            var w = this._avElement.width();
            var maxH = $(window).height() * this.maxHeight;
            if (this._isFS) {
                maxH = $(window).height();
                w = $(window).width();
            }
            //console.log(w, maxH, this._aspectRatio, w / this._aspectRatio);
            if (maxH < (w / this._aspectRatio)) {
                w = maxH * this._aspectRatio;
            }
            //console.log(w);
            return w;
        },
        getAnyImage: function () {
            return this._keyframe;
        },

        _runMedia: function () {
            //createVideoPlayer(this._avElement, this._movieId, this.audioTracks, this.subtitles);
            //$(window).on('resize', this._resize());
            this.alreadyLoaded = true;
            var id = (new Date()).getTime() + '_' + this._movieId;
            this._src = '/content/womi/' + this._movieId + '/blabla';
            this._id = id;
            this.player = null;
            var _this = this;
            var div = $('<div>', { id: id, width: this._calcWidth() });
            if (this._isFS) {
                div.height($(window).height());
            }
            div.css('margin', '0 auto');
            this.mainDiv = div;
            this._avElement.append(div);
            var settings = {
                aspectRatio: this._aspectRatio,
                generatehtml: true,
                autoplay: false
            };
            if (this._keyframe.length) {
                var img = new WOMIImageContainer({el: this._keyframe, options: {}});
                settings.poster = img.getUrl();
            }
            if (this._describedBy) {
                settings.showTranscrptionCallback = function (id) {
                    $.fancybox({
                            content: $('#' + id).html()
                    });
                };
                settings.transcrptionId = this._describedBy;
            }

            this.player = new player.createVideoPlayer('#' + id, '' + this._movieId, settings);
            div.find('video').attr('title', this._altText);
            if (this._isFS) {
                div.find('.jp-full-screen').remove();
            }
//            if (!this._isFS && (/*(bowser.firefox && bowser.version >= 30) || */bowser.msie)) {
//                var btn = div.find('.jp-full-screen');
//                btn.off('click');
//                btn.on('click', function () {
//                    _this.contextCallback();
//                });
//
//            }

            var scroll  = _this._mainContainerElement.offset().top + 100;

            this.videoFS = false;

            var fsControl;

            $('.jp-full-screen').on("click", function(ev){
                scroll  = _this._mainContainerElement.offset().top + 100;
                _this.videoFS = true;
                fsControl = _this._fullscreenControl();
            });

            function windowRestore(){
                window.setTimeout(function () {
                    $(window).scrollTop(scroll);
                    var after = $(window).scrollTop();
                    _this.videoFS = false;
                    fsControl();
                }, 500);
            }

            $('.jp-restore-screen').on("click", function(ev){
                windowRestore();
            });

            $(window).keyup(function(e) {
                var code = (e.keyCode ? e.keyCode : e.which);
                if (code == 27) {
                    if(_this.videoFS){
                        windowRestore();
                    }
                }
            });

            //FF > 30 hack for fullscreen
            if ((bowser.firefox && bowser.version >= 30 && bowser.version < 33)) {
                var full = false;
                var change = true;
                var placeholder = $('<div>');
                var btn = div.find('.jp-full-screen');
                var clickHandlers = $._data(btn[0], "events")['click'];
                var clickFunc = [];
                _.each(clickHandlers, function (value) {
                    clickFunc.push(value.handler);
                });
                btn.off('click');
                //console.log(clickFunc);

                btn.click(function (e) {
                    var t = this;
                    e.preventDefault();
                    if (!full) {
                        _this._avElement.after(placeholder);
                        $('body').append(_this._avElement);
                    } else {
                    }
                    full = !full;
                });

                _.each(clickFunc, function (v) {
                    btn.click(v);
                });

                $(document).on('mozfullscreenchange', function () {
                    if (!change && full) {
                        placeholder.after(_this._avElement);
                        full = !full;
                        change = true;
                    } else if (full) {
                        change = false;
                    }
                });
            }

            this._activateViewPortCheck();

            this.postCreate();

        },

        postCreate: function(){
        },

        _fullscreenControl: function () {
            var keyModuleSwitchHandler;
            var that = this;
            $.each($._data(document, "events").keydown, function (idx, el) {
                if (el.namespace == 'bottombar') {
                    keyModuleSwitchHandler = el;
                }
            });
            $(document).off('keydown.bottombar');

            return function () {
                if (keyModuleSwitchHandler != null) {
                    $(document).on('keydown.bottombar', keyModuleSwitchHandler);
                }
            }
        },

        _activateViewPortCheck: function() {
            this.allowViewPortCheck = true;
            var _this = this;
            function viewPortCheck(){
                if(_this && _this.mainDiv && !_this.videoFS && _this.mainDiv.height() < 1 && !_this.player.Player.data('jPlayer').status.paused){
                    _this.player.Player.jPlayer("pause");
                }
                if(_this && _this.mainDiv && _this.allowViewPortCheck){
                    setTimeout(viewPortCheck, 500);
                }
            }
            setTimeout(viewPortCheck, 500);
        },

        dispose: function () {
            this.allowViewPortCheck = false;
            //$(window).off('resize', this._resize());
            $(this.player).jPlayer("destroy");
        },
        _resize: function () {
            var _this = this;
            if (!this._resizeHandler) {
                this._resizeHandler = function () {
                    var aspectRatio = _this._aspectRatio;
                    var w = _this._calcWidth();
                    //console.log(w);
                    $(_this.mainDiv).width(w);
                    if (this._isFS) {
                        _this.mainDiv.height($(window).height());
                    }

                    if (!$(_this.mainDiv).hasClass('jp-video-full')) {
                        var playerHeight = $(_this.mainDiv).find('.jp-jplayer').height(w / aspectRatio).width(w).find('img').height(w / aspectRatio).width(w).height();
                        $(_this.mainDiv).find('.jp-video-play').css({ 'margin-top': '-' + playerHeight + 'px', 'height': playerHeight + 'px' });
                        //$(_this.player).jPlayer('option', 'size', {width: w, height: playerHeight});
                    }

                }
            }
            return this._resizeHandler;
        },
        hasFullscreenItem: function () {
            return false;

        }
    });
    return WOMIMovieContainer;
});