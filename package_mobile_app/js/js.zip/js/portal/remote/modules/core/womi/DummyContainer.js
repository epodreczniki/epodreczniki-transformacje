define(['portal/remote/modules/core/womi/WOMIContainerBase'], function (Base) {
    return Base.extend({
        _lookForBlocks: function () {
            console.log('problem z WOMI: ', this._mainContainerElement);
        }
    });
});