define(['jquery', 'backbone',
'portal/remote/modules/core/Registry',
'portal/remote/modules/core/womi/WOMIContainerBase'
], function ($, Backbone, Registry, Base) {
    return Base.extend({
        containerClass: 'audio-container',
        _discoverContent: function () {
            this._altText = this._mainContainerElement.data('alt');
            this._audioId = this._mainContainerElement.data('audio-id');
            this._width = this._mainContainerElement.data('width');
            this._id = (new Date()).getTime() + '_' + this._audioId;
        },
        load: function () {
            var _this = this;
            _this.alreadyLoaded = false;
            this.on('renderDone', function () {
                !_this.alreadyLoaded && _this._runMedia();
            });
            if (this._mainContainerElement.find('.generated-av').length > 0 && !this._avElement) {
                this._mainContainerElement.find('.generated-av').remove();
            }
            if (!this._avElement) {

                this._avElement = $('<div />', {
                    'class': 'generated-av',
                    //style: 'width: ' + (this._width ? this._width : '100%') + ";",
                    id: this._id
                });

                this._mainContainerElement.append(this._avElement);
                this.on('resize', this._resize());
                //this._runMedia();

            }
        },
        _resize: function () {
            var _this = this;
            return function () {
                //console.log(_this._mainContainerElement);
            };
        },
        _runMedia: function () {
            //player.createAudioPlayer('#' + this._id, this._audioId);

            var div = $('<div>', {id: this._id, 'class': 'simple-audio-player'});
            var _this = this;
            this._avElement.append(div);
            require(['reader.api'], function (ReaderApi) {
                var readerApi = new ReaderApi(require, true);
                readerApi.bindAudio(div, _this._audioId + '');
            });
            //console.log('audio player', this._mainContainerElement);
            this.alreadyLoaded = true;
        },
        dispose: function () {
            if (this._resize) {
                this.off('resize', this._resize());
            }
            if (this._avElement != null) {
                this._avElement.remove();
                this._avElement = null;
            }
        },
        getFSElement: function () {
            return { element: this._avElement.clone(), options: {} };
        },
        hasFullscreenItem: function () {
            return false;
        }
    });
});