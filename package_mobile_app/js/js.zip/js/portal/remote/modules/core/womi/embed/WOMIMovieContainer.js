define(['portal/remote/modules/core/womi/WOMIMovieContainer'
], function (WOMIMovieContainer) {
    return WOMIMovieContainer.extend({
        maxHeight: 1.0
    });
});