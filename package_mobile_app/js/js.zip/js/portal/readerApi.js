define(['require', 'jquery', 'declare'], function (require, $, declare) {
    return declare({
		instance: {
			constructor: function (requireContext, silent, womiPath) {
			},
			getFullPath: function(path) {
				return path;
			},
			getManifest: function (callback, errorCallback, womiId) {
				console.log("getManifest: " + womiId)
				require(['text!:/../../womi/' + womiId + '/manifest.json'], function(manifest) {
					if (manifest.length > 0) {
						manifestObject = JSON.parse(manifest)
						callback(manifestObject);
					}
					else {
						console.log("No manifest data")
					}
				});
			}
		}
	});
});
