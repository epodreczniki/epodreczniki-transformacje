define([], function() {
	return {
		readerApiModes: {
			debug: false
		}
	}
});