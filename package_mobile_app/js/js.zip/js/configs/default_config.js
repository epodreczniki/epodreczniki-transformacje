require.config({
    paths:{
        jquery:"libs/jquery-2.1.1.min",
        'jquery-wp8':"libs/jquery-1.11.1.min.no-conflict",
        'jquery-1.11.1':"libs/jquery-1.11.1.min",
        jqui:"libs/jquery-ui-1.11.0.min",
        jqtouch:"libs/jquery.ui.touch-punch",
        underscore:"libs/underscore",
        iscrollzoom:"libs/iscroll-zoom",
        dropup:"videoplayer/dropup",
        "jquery.jplayer.dev":"videoplayer/jquery.jplayer.dev",
        "player.ext":"videoplayer/player.ext",
		jquerymobile:"libs/jquery.mobile-1.4.5.min",
        'notes-core':'modules/notes/notes-core',
        'notes-platform':'modules/notes-platform/notes-platform',
        'notes-config':'modules/notes/notes-config',
        'rangy-textrange':'modules/notes/rangy-textrange',
        'rangy-classapplier':'modules/notes/rangy-classapplier',
        'rangy-core':'modules/notes/rangy-core',
        'model/Note':'modules/notes/model/Note',
        'domReady':'libs/domReady',
        base64: 'libs/base64'
    },
    shim:{
    	"underscore":{
            exports:"_"
        },
        "jqui":{
            deps:['jquery']
        },
        "jqtouch":{
            deps:['jqui']
        },
        "iscrollzoom":{
            exports:"IScroll"
        }
    },
    waitSeconds:20
});
require(['jquery',
         'domReady',
		 'modules/toggle',
		 'modules/staticqml',
		 'modules/fontsize',
		 'modules/randomqml',
		 'modules/dispatcher'
		],function($,domReady,toggle,sqml,fontsize,randomqml,dispatcher){
	console.log("default_config");
    window.stopPlayback = function(){
        $('div[name="jplayer"]').each(function(idx,item){
            $(item).jPlayer("pause");
        });
    };
	window.toggleSolution = toggle.solution;
	window.toggleCommentary = toggle.commentary;
	window.showAuthorLicense = toggle.authorLicense;
	window.addMe = sqml.addMe;
	window.showAnswer = sqml.showAnswer;
	window.showHint = sqml.showHint;
    window.decreaseSize = fontsize.decreaseSize;
    window.increaseSize = fontsize.increaseSize;
    window.updateSize = fontsize.updateSize;
    window.jumpToNote = function(noteId){
		var noteElement = document.querySelector("span[note-id='"+noteId+"']");
		if(!!noteElement){
			noteElement.scrollIntoView();
		}
	};
	// dispatcher
	$(document).ready(function(){
    	dispatcher.loadModulesInsideDiv($('body'));
    });
    domReady(function(){
        console.log('domReady','loading notes');
        require(['notes-core'],function(notes){
            window.noteCreateCallback = notes.noteCreateCallback;
            window.noteDeleteCallback = notes.noteDeleteCallback;
            window.noteEditCallback = notes.noteEditCallback;
            window.startAddNote = notes.startAddNote;
            window.showAllNotes = function() {
            	notes.showAllNotes();
            	dispatcher.callFinishMethod([]);
            };
            window.showNotes = function(notesItems) {
            	notes.showNotes(notesItems||[]);
            	dispatcher.callFinishMethod([]);
            };
            window.getSelectedText = notes.getSelectedText;
            window.copyToClipboard = function(){
                if(window.Android){
                    Android.copyToClipboard(notes.getSelectedText());
                }
            };
            //notes.showAllNotes();
            if(window.Android){
                Android.requestNotes();
            }else{
                notes.showAllNotes();
            	dispatcher.callFinishMethod([]);
            }
        });
    });
});
