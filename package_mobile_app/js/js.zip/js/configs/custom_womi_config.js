require.config({
    paths:{
        jquery:"libs/jquery-2.1.1.min",
        'jquery-wp8':"libs/jquery-1.11.1.min.no-conflict",
        'jquery-1.11.1':"libs/jquery-1.11.1.min",
        jqui:"libs/jquery-ui-1.11.0.min",
        jqtouch:"libs/jquery.ui.touch-punch",
        underscore:"libs/underscore",
        iscrollzoom:"libs/iscroll-zoom",
        declare:"libs/declare",
        backbone:"libs/backbone.min",
        'reader.api':"custom_womi/ReaderApi",
        base64: 'libs/base64'
    },
    shim:{
    	"underscore":{
            exports:"_"
        },
        "jqui":{
            deps:['jquery']
        },
        "jqtouch":{
            deps:['jqui']
        },
        "iscrollzoom":{
            exports:"IScroll"
        }
    },
    waitSeconds:20
});
require(['jquery', 'reader.api'], function($, api) {
    console.log("custom_womi_config");
    
    var replaceFrom = [
		'/global/libraries/epo/frame_script.js',
		'/global/libraries/declare/declare.js',
		'/global/libraries/epo/api/withoutRequirejs.js',
		'/global/libraries/epo/api/ReaderApi.js'
	];
	var replaceTo = [
		'../../js/custom_womi/frame_script.js',
		'../../js/libs/declare.js',
		'../../js/custom_womi/withoutRequirejs.js',
		'../../js/custom_womi/ReaderApi.js'
	];
	
	$.get('index.html', function(documentContent) {
		
		var iframe = null;
		window.iframeLoadedCallback = function() {
			// reader api
			require(['reader.api'], function(api) {
				try {
					var readerApi = new api(require);
					iframe.contentWindow.$.gamesRegistry('setApi', readerApi);
				}
				catch (e) {
					console.log("iframeLoadedCallback: error no gamesRegistry");
				}
			});
		};
		
		// fix js scripts
		for (var i = 0; i < replaceFrom.length; i++) {
			documentContent = documentContent.replace(replaceFrom[i], replaceTo[i]);
		}
		
		var iframeWidth = window.innerWidth - 20;
		var iframeHeight = window.innerHeight - 20;
		
		iframe = document.body.appendChild(document.createElement('iframe'));
		iframe.setAttribute("frameborder", "0");
		iframe.setAttribute("style", "margin: 10px;");
		iframe.setAttribute("scrolling", "yes");
		iframe.setAttribute("onload", "this.width=" + iframeWidth + ";this.height=" + iframeHeight + ";window.parent.iframeLoadedCallback();");
		
		iframeDoc = iframe.contentWindow.document;
		iframeDoc.open();
		iframeDoc.write(documentContent);
		iframeDoc.close();
		
		// orientation change
		window.onorientationchange = function() {
			
			setTimeout(function() {
				
				iframeWidth = window.innerWidth - 20;
				iframeHeight = window.innerHeight - 20;
				
				iframe.setAttribute("width", iframeWidth);
				iframe.setAttribute("height", iframeHeight);				
			}, 500);
		};
	});
});
