require.config({
    paths:{
        jquery:"libs/jquery-2.1.1.min",
        'jquery-wp8':"libs/jquery-1.11.1.min.no-conflict",
        'jquery-1.11.1':"libs/jquery-1.11.1.min",
        jqui:"libs/jquery-ui-1.11.0.min",
        jqtouch:"libs/jquery.ui.touch-punch",
        underscore:"libs/underscore",
        iscrollzoom:"libs/iscroll-zoom",
        dropup:"videoplayer/dropup",
        "jquery.jplayer.dev":"videoplayer/jquery.jplayer.dev",
        "player.ext":"videoplayer/player.ext",
		jquerymobile:"libs/jquery.mobile-1.4.5.min",
    	
		declare:"libs/declare",
		"placeholder.api":"portal/placeholderApi",
		"reader.api":"portal/readerApi",
		"text":"libs/text",
		"backbone":"libs/backbone.min",
		"bowser":"libs/bowser.min",
		"device_detection":"portal/device_detection",
		mathjax:'3rdparty/mathjax/MathJax.js?delayStartupUntil=onload',
        base64: 'libs/base64'
    },
    shim:{
    	"underscore":{
            exports:"_"
        },
        "jqui":{
            deps:['jquery']
        },
        "jqtouch":{
            deps:['jqui']
        },
        "iscrollzoom":{
            exports:"IScroll"
        },
        mathjax:{
            exports:"MathJax",
            init:function(){
                MathJax.Hub.Config({
                    jax:["input/MathML","output/HTML-CSS"],
                    extensions:["mml2jax.js"],
                    skipStartupTypeset:true,
                    "HTML-CSS":{
                        imageFont:null,
                        availableFonts:["Asana-Math"],
                        preferredFont:"Asana-Math",
                        webFont:"Asana-Math",
                        linebreaks:{automatic:true}
                    },
                    MathML:{
                        //extensions:["content-mathml.js"]
                    }
                });
                MathJax.Hub.Startup.onload();
                return MathJax;
            }
        }
    },
	waitSeconds:20
});
require(['jquery',
		 'modules/dispatcher',
		 'mathjax'
		],function($,dispatcher, MathJax){
	console.log("generator_config");
	window.reloadMathJax = function() {
		MathJax.Hub.Queue(["Typeset",MathJax.Hub,"math_id"]);
	};
	// dispatcher
	$(document).ready(function(){
    	dispatcher.loadModulesInsideDiv($('body'));
		$("body").attr("id", "math_id");
		
		setTimeout(function(){
			window.reloadMathJax();
		}, 1000)
		
    });
});
