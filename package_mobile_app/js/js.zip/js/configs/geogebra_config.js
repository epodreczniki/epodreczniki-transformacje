require.config({
    paths:{
        jquery:"libs/jquery-2.1.1.min",
        'jquery-wp8':"libs/jquery-1.11.1.min.no-conflict",
        'jquery-1.11.1':"libs/jquery-1.11.1.min",
        jqui:"libs/jquery-ui-1.11.0.min",
        jqtouch:"libs/jquery.ui.touch-punch",
        underscore:"libs/underscore",
        iscrollzoom:"libs/iscroll-zoom",
        dropup:"videoplayer/dropup",
        "jquery.jplayer.dev":"videoplayer/jquery.jplayer.dev",
        "player.ext":"videoplayer/player.ext",
		jquerymobile:"libs/jquery.mobile-1.4.5.min",
        base64: 'libs/base64'
    },
    shim:{
    	"underscore":{
            exports:"_"
        },
        "jqui":{
            deps:['jquery']
        },
        "jqtouch":{
            deps:['jqui']
        },
        "iscrollzoom":{
            exports:"IScroll"
        }
    }
});
require(['jquery', 'modules/util'],function($, util){
	console.log("geogebra_config");
	
	$(document).ready(function() {
		parameters.appletOnLoad = function() {
			util.callParent("done");
		};
  		var applet = new GGBApplet(parameters, '5.0', 'applet_container');
        applet.setHTML5Codebase('./../../js/3rdparty/geogebra/HTML5/5.0/web/');
        applet.inject('preferhtml5');
		window.applet = applet;
    });
});
