require.config({
    paths:{
        jquery:"libs/jquery-2.1.1.min",
        'jquery-wp8':"libs/jquery-1.11.1.min.no-conflict",
        'jquery-1.11.1':"libs/jquery-1.11.1.min",
        jqui:"libs/jquery-ui-1.11.0.min",
        jqtouch:"libs/jquery.ui.touch-punch",
        underscore:"libs/underscore",
        iscrollzoom:"libs/iscroll-zoom",
        dropup:"videoplayer/dropup",
        "jquery.jplayer.dev":"videoplayer/jquery.jplayer.dev",
        "player.ext":"videoplayer/player.ext",
		jquerymobile:"libs/jquery.mobile-1.4.5.min",
        base64: 'libs/base64'
    },
    shim:{
    	"underscore":{
            exports:"_"
        },
        "jqui":{
            deps:['jquery']
        },
        "jqtouch":{
            deps:['jqui']
        },
        "iscrollzoom":{
            exports:"IScroll"
        }
    }	
});
require(['jquery', 'modules/util'],function($, util){
	console.log("geogebra_launcher_config");
	var sent = false;
	
	var postReady = function() {
		
		var winWidth = $(window).attr('innerWidth');
		var winHeight = $(window).attr('innerHeight');
		var wRation = winWidth / parameters.width;
		var hRation = winHeight / parameters.height;
		
		if (wRation > 1.0 && hRation > 1.0) {
			var minRatio = Math.min(wRation, hRation);
			var newWidth = minRatio * parameters.width;
			var newHeight = minRatio * parameters.height;
			newWidth = Math.floor(newWidth);
			newHeight = Math.floor(newHeight);
			
			var iframe = $('iframe');
			iframe.css("transform", "scale(" + minRatio + ")");
			iframe.css("-ms-transform", "scale(" + minRatio + ")");
			iframe.css("-webkit-transform", "scale(" + minRatio + ")");
			iframe.css("margin-top", Math.floor((winHeight - newHeight) / 2) + "px");
			iframe.css("margin-left", Math.floor((winWidth - newWidth) / 2) + "px");
		}
		else {
			var minRatio = Math.min(wRation, hRation);
			var maxRatio = Math.min(wRation, hRation);
			
			var newWidth = minRatio * parameters.width;
			var newHeight = minRatio * parameters.height;
			newWidth = Math.floor(newWidth);
			newHeight = Math.floor(newHeight);
			
			var iframe = $('iframe');
			iframe.css("transform", "none");
			iframe.css("-ms-transform", "none");
			iframe.css("-webkit-transform", "none");
			iframe.css("margin-top", Math.floor((winHeight - newHeight) / 2) + "px");
			iframe.css("margin-left", Math.floor((winWidth - newWidth) / 2) + "px");
		}
	};
	
	var reloadApplet = function() {
		if (sent == false) {
			sent = true;
			
			util.notifyEverythingWillBeLoaded();
			
			var iframe = $('iframe');
			iframe.attr('src', 'geogebra.html');
			
			postReady();
		}
	};
	
	$(document).ready(function() {
    	
		window.done = function() {
			util.notifyEverythingWasLoaded();
			sent = false;
		};
		
		reloadApplet();
		
		var timer;
		window.onorientationchange = function() {
			try {
				clearTimeout(timer);
			}
			catch (e) {}
			timer = setTimeout(function() {
				reloadApplet();
			}, 500);
		};
    });
});
