if (window.require === undefined) {
	window.require = {
		baseUrl: "js"
	}
}
window.devType = "IOS";
