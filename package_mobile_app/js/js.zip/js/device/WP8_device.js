if (window.require === undefined) {
	window.require = {
		baseUrl: "js"
	}
}
window.devType = "WP8";

var isTeacher = false;
var canPlay = false;

function SetIsTeacherWP8(is) {
    isTeacher = is;
}

function SetCanPlayVideoWP8(can) {
    canPlay = can;
}

window.isTeacherWP8 = function () {
    return isTeacher;
}

window.canPlayVideoWP8 = function (container, playermodule) {
    return canPlay;
}

function DecreaseSizeWP8() {
    window.decreaseSize();
}

function IncreaseSizeWP8() {
    window.increaseSize();
}

function UpdateSizeWP8() {
    window.updateSize();
}

function JumpToAnchorWP8(anchor) {
    window.jumpToAnchor(anchor);
}

function JumpToNoteWP8(noteId) {
    window.jumpToNote(noteId);
}

function CloseWindowWP8() {
    window.closeWindow();
}

function StartAddNote(shouldStringify) {
    window.startAddNote(shouldStringify);
}

function NoteCreateCallback(note, ntm) {
    window.noteCreateCallback(note, ntm);
}

function NoteEditCallback(note) {
    window.noteEditCallback(note);
}

function NoteDeleteCallback(noteId) {
    window.noteDeleteCallback(noteId);
}

function ShowNotes(notes) {
    window.showNotes(notes);
}

function ShowAllNotes() {
    notes.showAllNotes();
}