if (window.require === undefined) {
	window.require = {
		baseUrl: "js"
	}
}
window.devType = "WIN8";

var isTeacher = false;
var canPlay = false;

function SetIsTeacherWin8(is) {
    isTeacher = is;
}

function SetCanPlayVideoWin8(can) {
    canPlay = can;
}

window.isTeacherWin8 = function () {    
    return isTeacher;
}

window.canPlayVideoWin8 = function (container, playermodule) {
    return canPlay;    
}

function DecreaseSizeWin8() {
    window.decreaseSize();    
}

function IncreaseSizeWin8() {
    window.increaseSize();
}

function UpdateSizeWin8() {
    window.updateSize();
}

function JumpToAnchorWin8(anchor) {
    window.jumpToAnchor(anchor);
}

function JumpToNoteWin8(noteId) {
    window.jumpToNote(noteId);
}

function StopPlaybackWin8() {
    window.stopPlayback();
}

function CloseWindowWin8() {
    window.closeWindow();
}

function StartAddNote(shouldStringify) {
    window.startAddNote(shouldStringify);
}

function NoteCreateCallback(note, ntm) {
    window.noteCreateCallback(note, ntm);
}

function NoteEditCallback(note) {
    window.noteEditCallback(note);
}

function NoteDeleteCallback(noteId) {
    window.noteDeleteCallback(noteId);
}

function ShowNotes(notes) {
    window.showNotes(notes);
}

function ShowAllNotes() {
    notes.showAllNotes();
}



