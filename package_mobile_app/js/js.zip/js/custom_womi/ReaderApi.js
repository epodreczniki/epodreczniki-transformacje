define('reader.api', ['declare', 'jquery', 'backbone'], function (declare, $, Backbone) {
    return declare({
        instance: {
            constructor: function (requireContext) {
                this.require = requireContext;
                console.log("ReaderApi: constructor");
            },

            getFullPath: function (path) {
                console.log("ReaderApi: getFullPath");
            },
            setLocalUserVar: function (eventName, value) {
                console.log("ReaderApi: setLocalUserVar");
            },
            getLocalUserVar: function (varName, callback) {
                console.log("ReaderApi: getLocalUserVar");
            },
            setUserVar: function (varName, value) {
                console.log("ReaderApi: setUserVar");
            },
            setUserAnswer: function (value) {
                console.log("ReaderApi: setUserAnswer");
            },
            getUserVar: function (varName, callback) {
                console.log("ReaderApi: getUserVar");
            },
            getPosition: function (callback) {
            	console.log("ReaderApi: getPosition");
            },
            getTileSize: function (callbackDone, callbackError) {
                console.log("ReaderApi: getTileSize");
            },
            getAudioUrl: function (womiId, callback) {
                console.log("ReaderApi: getAudioUrl");
            },
            getVideoUrl: function (womiId, callback) {
                console.log("ReaderApi: getVideoUrl");
            },
            maximize: function () {
                console.log("ReaderApi: maximize");
            },
            closeMaximize: function () {
                console.log("ReaderApi: closeMaximize");
            },
            getModes: function(callback){
                console.log("ReaderApi: getModes");
            },
            getUserInfo: function(callback){
                console.log("ReaderApi: getUserInfo");
            },
            sendMail: function(data){
                console.log("ReaderApi: sendMail");
            },
            saveFile: function(filename, fileData, descriptor, callback){
                console.log("ReaderApi: saveFile");
            },
            saveImageFile: function(filename, fileData, descriptor, callback){
                console.log("ReaderApi: saveImageFile");
            },
            getFileUrl: function (descriptor, callback) {
                console.log("ReaderApi: getFileUrl");
            },
            
            // extended from womi.js
            updateContainerSize: function(height) {
            	console.log("ReaderApi: updateContainerSize");
            }
        }});
});
